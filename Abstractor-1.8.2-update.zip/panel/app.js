/* Abstractor Panel — app.js */

// ── Tooltip (fixed-position, works in CEP WebView) ─────────────────────────
(function () {
  var tip = document.getElementById('tooltip-el');
  if (!tip) return;
  var hideTimer = null;

  document.addEventListener('mouseover', function (e) {
    var target = e.target.closest('[data-tip]');
    if (!target) return;
    var text = target.getAttribute('data-tip');
    if (!text) return;
    if (hideTimer) { clearTimeout(hideTimer); hideTimer = null; }
    tip.textContent = text;
    tip.style.left = '-9999px';
    tip.style.top  = '-9999px';
    tip.classList.add('visible');
    requestAnimationFrame(function () {
      var r  = target.getBoundingClientRect();
      var tw = tip.offsetWidth;
      var th = tip.offsetHeight;
      var left = r.left + r.width / 2 - tw / 2;
      var top  = r.top - th - 8;
      if (top < 4) top = r.bottom + 8;
      left = Math.max(4, Math.min(left, window.innerWidth - tw - 4));
      tip.style.left = left + 'px';
      tip.style.top  = top  + 'px';
    });
  });

  document.addEventListener('mouseout', function (e) {
    if (!e.target.closest('[data-tip]')) return;
    hideTimer = setTimeout(function () {
      tip.classList.remove('visible');
    }, 80);
  });
})();

(function () {
  'use strict';

  var cs = new CSInterface();
  var extPath = cs.getSystemPath(SystemPath.EXTENSION).replace(/\\/g, '/');

  // ── First-run setup ───────────────────────────────────────────────────────
  // If remotion/node_modules is missing, show setup screen and run npm install
  // before loading the rest of the panel.
  var setupInProgress = (function checkFirstRun() {
    var path = require('path');
    var fs   = require('fs');
    var spawn = require('child_process').spawn;

    var remotionDir   = path.join(extPath, 'remotion');
    var nodeModulesDir = path.join(remotionDir, 'node_modules');
    if (fs.existsSync(nodeModulesDir)) return false; // already set up — continue normally

    // Show setup screen, hide main panel
    var setupScreen = document.getElementById('setup-screen');
    var mainPanel   = document.getElementById('main');
    var header      = document.getElementById('header');
    setupScreen.style.display = 'flex';
    if (mainPanel) mainPanel.style.display = 'none';
    if (header)    header.style.display    = 'none';

    var statusEl  = document.getElementById('setup-status');
    var barFill   = document.getElementById('setup-bar-fill');
    var logEl     = document.getElementById('setup-log');
    var doneEl    = document.getElementById('setup-done');
    var errorEl   = document.getElementById('setup-error');
    var errorMsg  = document.getElementById('setup-error-msg');

    function appendLog(line) {
      logEl.textContent += line + '\n';
      logEl.scrollTop = logEl.scrollHeight;
    }

    // Find npm binary
    var isWin = process.platform === 'win32';

    var npmBin = isWin ? 'npm.cmd' : 'npm';
    if (!isWin) {
      var macCandidates = ['/usr/local/bin/npm', '/opt/homebrew/bin/npm', '/usr/bin/npm'];
      macCandidates.forEach(function(p) {
        try { if (fs.statSync(p).isFile()) npmBin = p; } catch(e) {}
      });
      try {
        var found = require('child_process').execSync('which npm 2>/dev/null').toString().trim();
        if (found) npmBin = found;
      } catch(e) {}
    }

    statusEl.textContent = 'Installing render engine…';
    barFill.style.width = '5%';

    var winPath = [
      'C:\\Program Files\\nodejs',
      (process.env.APPDATA || '') + '\\npm',
      process.env.PATH || ''
    ].join(';');

    var proc = spawn(npmBin, ['install', '--prefer-offline', '--no-audit', '--no-fund'], {
      cwd: remotionDir,
      shell: isWin,
      env: Object.assign({}, process.env, {
        PATH: isWin ? winPath : [
          '/usr/local/bin', '/opt/homebrew/bin', '/usr/bin', '/bin',
          process.env.PATH || ''
        ].join(':')
      })
    });

    var progress = 5;
    proc.stdout.on('data', function(d) {
      var lines = d.toString().split('\n').filter(Boolean);
      lines.forEach(function(l) {
        appendLog(l);
        if (l.includes('added') || l.includes('packages')) progress = Math.min(90, progress + 2);
        barFill.style.width = progress + '%';
      });
    });
    proc.stderr.on('data', function(d) {
      d.toString().split('\n').filter(Boolean).forEach(appendLog);
    });

    proc.on('close', function(code) {
      if (code === 0) {
        barFill.style.width = '100%';
        statusEl.textContent = 'Done!';
        doneEl.style.display = 'flex';
        setTimeout(function() { window.location.reload(); }, 1800);
      } else {
        barFill.style.background = '#e05';
        errorMsg.textContent = 'npm install failed (exit ' + code + ')';
        errorEl.style.display = 'block';
        statusEl.textContent = 'Setup failed';
      }
    });

    proc.on('error', function(e) {
      errorMsg.textContent = 'Could not run npm: ' + e.message;
      errorEl.style.display = 'block';
      statusEl.textContent = 'Setup failed';
    });

    return true; // setup is running — caller should abort normal init
  }());

  if (setupInProgress) return; // stop the rest of app.js from initializing

  // ── Node.js modules ──────────────────────────────────────────────────────
  var os           = require('os');
  var path         = require('path');
  var fs           = require('fs');
  var spawn        = require('child_process').spawn;
  var exec         = require('child_process').exec;
  var historyManager = require(path.join(extPath, 'scripts', 'history-manager'));

  // ── Absolute node binary ──────────────────────────────────────────────────
  var NODE_BIN = (function () {
    var candidates = [
      '/usr/local/bin/node',
      '/opt/homebrew/bin/node',
      '/usr/bin/node',
      process.env.NODE || ''
    ];
    for (var i = 0; i < candidates.length; i++) {
      var p = candidates[i];
      if (p) {
        try { if (fs.statSync(p).isFile()) return p; } catch (e) {}
      }
    }
    return 'node';
  }());

  // ── Usable PATH for child processes ──────────────────────────────────────
  var CHILD_PATH = [
    os.homedir() + '/.local/bin',
    '/usr/local/bin', '/opt/homebrew/bin',
    '/opt/homebrew/opt/poppler/bin',
    '/usr/bin', '/bin', '/usr/sbin', '/sbin'
  ].join(':') + (process.env.PATH ? ':' + process.env.PATH : '');

  // ── LibreOffice binary ────────────────────────────────────────────────────
  var SOFFICE = (function () {
    var candidates = [
      // macOS
      '/Applications/LibreOffice.app/Contents/MacOS/soffice',
      // Linux
      '/usr/bin/soffice',
      '/usr/local/bin/soffice',
      // Windows — standard install locations
      'C:\\Program Files\\LibreOffice\\program\\soffice.exe',
      'C:\\Program Files (x86)\\LibreOffice\\program\\soffice.exe',
      // fallback — relies on PATH
      'soffice'
    ];
    for (var i = 0; i < candidates.length; i++) {
      if (candidates[i] === 'soffice') return 'soffice';
      try { if (fs.statSync(candidates[i]).isFile()) return candidates[i]; } catch (e) {}
    }
    return 'soffice';
  }());

  // ── State ─────────────────────────────────────────────────────────────────
  var state = {
    imagePath:       null,   // currently selected image (or null = text-only)
    isRunning:       false,
    childProcess:    null,   // the active bridge child process (for cancel)
    mediaType:       null,   // null | 'image' | 'deck'
    deckSlides:      [],     // array of PNG paths from last PPTX conversion
    doneSlidePaths:  {},     // set of slide paths that have been rendered
    pptxPath:        null,
    activeSlideThumb: null,  // the .slide-thumb DOM node for the running render
    lastImagePath:   null,   // for recreate
    lastText:        null,   // for recreate
    assets:          [],           // [{path, name, type}]
    lastRendersFolder: null,      // path to open on "Open Folder"
    slideNotes:      {},          // {slideIndex: "notes text"} — populated from PPTX
    activeSlideIndex: null,       // 1-based index of the currently selected slide
    primaryColor:    'rgb(118,185,0)', // selected brand color
    secondaryColor:  '',               // '' = auto (Claude picks)
    bgColor:         '',               // '' = transparent (default)
    quality4k:       false,            // render at 3840×2160 instead of 1920×1080
    detectedLayout:  null,             // mode/layout detected by Haiku
    modeOverride:    null,             // 'diagram' | 'creative' | null (auto)
    layoutOverride:  null,             // diagram sub-type override
    creativeBrief: { archetype: null, mood: null, motion: null, directorNote: '' },
    classifyProcess: null,             // classify-only child (runs in parallel with render)
    pendingLayoutChange: null,         // {mode, layout} — set by "Change Layout" to restart after kill
    lastCompPath:    null,   // path to AbstractorComp.tsx from last successful render
    lastOutputBase:  null,   // output filename base from last successful render
    lastVo:          null,   // VO text from last run (for recreate)
    lastConcept:     null,   // concept text from last run (for recreate)
    outputFolder:    null,   // null = default (Footage/Renders under AE project)
    lastSlideNum:    '00',   // slide number from last successful render (for fix naming)
    lastHistoryId:   null,   // history entry ID from last successful render (for fix linking)
    lastModel:       '',     // model used for the last/current render
    lastRenderTimeSec: 0    // wall-clock render time in seconds
  };

  // ── Element refs ──────────────────────────────────────────────────────────
  var mediaZone       = document.getElementById('media-zone');
  var mediaDrop       = document.getElementById('media-drop');
  var mediaInput      = document.getElementById('media-input');
  var imagePreview    = document.getElementById('image-preview');
  var clearMediaBtn   = document.getElementById('clear-media-btn');
  var mediaZoomBtn    = document.getElementById('media-zoom-btn');
  var deckLabel       = document.getElementById('deck-label');
  var slideGrid       = document.getElementById('slide-grid');
  var slideGridWrap   = document.getElementById('slide-grid-wrap');

  var contentTextarea = document.getElementById('content-textarea');
  var abstractBtn     = document.getElementById('abstract-btn');
  var cancelBtn       = document.getElementById('cancel-btn');
  var recreateBtn     = document.getElementById('recreate-btn');
  var resetBtn        = document.getElementById('reset-btn');

  var progressWrap    = document.getElementById('progress-wrap');
  var progressFill    = document.getElementById('progress-bar-fill');
  var progressMessage = document.getElementById('progress-message');
  var pixelCanvas     = document.getElementById('pixel-canvas');

  // preview section removed

  var statusLine      = document.getElementById('status-line');
  var openFolderBtn   = document.getElementById('open-folder-btn');
  var renderTimeEl    = document.getElementById('render-time');
  var renderTimeText  = document.getElementById('render-time-text');
  var progressStopwatch   = document.getElementById('progress-stopwatch');
  var progressModelChip   = document.getElementById('progress-model-chip');
  var modelSelect         = document.getElementById('model-select');
  var modelHint           = document.getElementById('model-hint');
  var lengthInput       = document.getElementById('length-input');

  var slideNotesWrap      = document.getElementById('slide-notes-wrap');
  var slideNotesTextarea  = document.getElementById('slide-notes-textarea');
  var conceptOptionalTag  = document.getElementById('concept-optional-tag');
  var noTextCb            = document.getElementById('no-text-cb');
  var quality4kCb         = document.getElementById('quality-4k-cb');
  var modeBtns             = document.querySelectorAll('.mode-btn');
  var layoutOverrideSelect = document.getElementById('layout-override-select');
  var colorSwatches       = document.querySelectorAll('.color-swatch');
  var secondarySwatches   = document.querySelectorAll('.secondary-swatch');
  var bgSwatches          = document.querySelectorAll('.bg-swatch');

  var assetsDropZone  = document.getElementById('assets-drop-zone');
  var assetsInput     = document.getElementById('assets-input');
  var assetsList      = document.getElementById('assets-list');

  var creativeBriefEl   = document.getElementById('creative-brief');
  var archetypeCards    = document.querySelectorAll('.archetype-card');
  var moodPills         = document.querySelectorAll('[data-mood]');
  var motionPills       = document.querySelectorAll('[data-motion]');
  var directorNoteInput = document.getElementById('director-note');
  var briefRandomizeBtn = document.getElementById('brief-randomize-btn');

  var optionsToggle   = document.getElementById('options-toggle');
  var optionsPanel    = document.getElementById('options-panel');

  var nameInput       = document.getElementById('name-input');

  var fixRow          = document.getElementById('fix-row');
  var fixChips        = document.querySelectorAll('.fix-chip');
  var fixTextarea     = document.getElementById('fix-textarea');
  var fixBtn          = document.getElementById('fix-btn');

  var outputFolderPathEl     = document.getElementById('output-folder-path');
  var outputFolderBrowseBtn  = document.getElementById('output-folder-browse-btn');
  var outputFolderResetBtn   = document.getElementById('output-folder-reset-btn');

  var helpBtn         = document.getElementById('help-btn');
  var helpOverlay     = document.getElementById('help-overlay');
  var helpClose       = document.getElementById('help-close');
  var updateBtn       = document.getElementById('update-btn');
  var updateOverlay   = document.getElementById('update-overlay');
  var updateClose     = document.getElementById('update-close');

  var logToggle       = document.getElementById('log-toggle');
  var logContent      = document.getElementById('log-content');
  var logCopyBtn      = document.getElementById('log-copy-btn');
  var logCopyLabel    = document.getElementById('log-copy-label');

  var historyToggle   = document.getElementById('history-toggle');
  var historyPanel    = document.getElementById('history-panel');
  var historyList     = document.getElementById('history-list');

  var wireframeOverlay  = document.getElementById('wireframe-overlay');
  var wireframeCardsEl  = document.getElementById('wireframe-cards');
  var wireframeSecondsEl = document.getElementById('wireframe-seconds');
  var wireframeSkipBtn  = document.getElementById('wireframe-skip');
  var wireframeRenderBtn = document.getElementById('wireframe-render');

  // Init pixel art animation
  PixelArt.init(pixelCanvas, progressMessage);
  updateAbstractBtn();

  // ── Preview Lightbox ──────────────────────────────────────────────────────
  var previewLightbox  = document.getElementById('preview-lightbox');
  var previewLbImg     = document.getElementById('preview-lb-img');
  var previewLbLabel   = document.getElementById('preview-lb-label');
  var previewLbCounter = document.getElementById('preview-lb-counter');
  var previewLbClose   = document.getElementById('preview-lb-close');
  var previewLbPrev    = document.getElementById('preview-lb-prev');
  var previewLbNext    = document.getElementById('preview-lb-next');
  var previewLbBack    = document.getElementById('preview-lb-backdrop');

  var previewItems  = [];  // [{src, label}]
  var previewIndex  = 0;

  function openPreview(items, idx) {
    previewItems = items;
    showPreviewAt(idx);
    previewLightbox.classList.add('open');
  }

  function showPreviewAt(idx) {
    previewIndex = Math.max(0, Math.min(idx, previewItems.length - 1));
    var item = previewItems[previewIndex];
    previewLbImg.src = item.src;
    previewLbLabel.textContent = item.label;
    var multi = previewItems.length > 1;
    previewLbCounter.textContent = multi ? (previewIndex + 1) + ' / ' + previewItems.length : '';
    previewLbPrev.classList.toggle('visible', multi);
    previewLbNext.classList.toggle('visible', multi);
  }

  function closePreview() {
    previewLightbox.classList.remove('open');
    previewLbImg.src = '';
  }

  previewLbClose.addEventListener('click', closePreview);
  previewLbBack.addEventListener('click', closePreview);
  previewLbPrev.addEventListener('click', function () { showPreviewAt(previewIndex - 1); });
  previewLbNext.addEventListener('click', function () { showPreviewAt(previewIndex + 1); });

  document.addEventListener('keydown', function (e) {
    if (!previewLightbox.classList.contains('open')) return;
    if (e.key === 'Escape') closePreview();
    else if (e.key === 'ArrowLeft')  showPreviewAt(previewIndex - 1);
    else if (e.key === 'ArrowRight') showPreviewAt(previewIndex + 1);
  });

  // Strip the "OK:" prefix that some CEP/AE versions prepend to evalScript results.
  function stripOK(s) { return (s && s.startsWith('OK:')) ? s.slice(3) : s; }

  // Sanitize a user-provided render name: keep alphanumeric + hyphen + underscore,
  // replace spaces with underscores, trim, truncate to 50 chars.
  function sanitizeName(raw) {
    return raw.trim()
      .replace(/\s+/g, '_')
      .replace(/[^A-Za-z0-9_-]/g, '')
      .slice(0, 50);
  }

  // ── Output folder helpers ─────────────────────────────────────────────────
  function updateOutputFolderDisplay() {
    if (state.outputFolder) {
      outputFolderPathEl.textContent = state.outputFolder;
      outputFolderPathEl.title = state.outputFolder;
    } else {
      outputFolderPathEl.textContent = 'Default (Footage/Renders)';
      outputFolderPathEl.title = 'Default: Footage/Renders under AE project folder';
    }
  }
  updateOutputFolderDisplay();

  outputFolderBrowseBtn.addEventListener('click', function () {
    cs.evalScript('Folder.selectDialog("Choose output folder for renders")', function (result) {
      if (result && result !== 'null' && result.trim().length > 0) {
        state.outputFolder = stripOK(result.trim());
        updateOutputFolderDisplay();
      }
    });
  });

  outputFolderResetBtn.addEventListener('click', function () {
    state.outputFolder = null;
    updateOutputFolderDisplay();
  });

  /** Scan folder for *_Abstractor_NNNNN*.mov, return next 5-digit serial string. */
  function nextSerial(folder) {
    var maxSerial = -1;
    try {
      var files = fs.readdirSync(folder);
      files.forEach(function (f) {
        var m = f.match(/_Abstractor_(\d{5})/i);
        if (m) {
          var n = parseInt(m[1], 10);
          if (n > maxSerial) maxSerial = n;
        }
      });
    } catch (e) {}
    return String(maxSerial + 1).padStart(5, '0');
  }

  /** Resolve the effective output folder (custom or default). Calls cb(folderPath). */
  function getEffectiveOutputFolder(cb) {
    if (state.outputFolder) {
      try { fs.mkdirSync(state.outputFolder, { recursive: true }); } catch (e) {}
      cb(state.outputFolder);
    } else {
      cs.evalScript('getProjectFolder()', function (projFolder) {
        var folder;
        if (projFolder && projFolder !== 'null' && projFolder.trim().length > 0) {
          folder = path.join(stripOK(projFolder.trim()), 'Footage', 'Renders');
        } else {
          folder = path.join(os.tmpdir(), 'abstractor_renders');
        }
        try { fs.mkdirSync(folder, { recursive: true }); } catch (e) {}
        cb(folder);
      });
    }
  }

  // ── Help overlay ──────────────────────────────────────────────────────────
  helpBtn.addEventListener('click', function () {
    helpOverlay.classList.add('visible');
  });

  updateBtn.addEventListener('click', function () {
    updateOverlay.classList.add('visible');
    // Auto-trigger an update check on overlay open so the user immediately sees
    // status (Up to date / Update to vX / Unreachable). Wrapped in typeof check
    // because checkForUpdate is defined later in the file.
    if (typeof checkForUpdate === 'function') {
      if (typeof _setAutoBtnState === 'function') _setAutoBtnState('checking');
      var st = document.getElementById('updStatus');
      if (st) {
        st.textContent = 'Checking for updates…';
        st.style.color = 'var(--text-muted)';
      }
      checkForUpdate({ manual: true });
    }
  });
  updateClose.addEventListener('click', function () {
    updateOverlay.classList.remove('visible');
  });

  helpClose.addEventListener('click', function () {
    helpOverlay.classList.remove('visible');
  });

  // ── Color swatches ────────────────────────────────────────────────────────
  colorSwatches.forEach(function (swatch) {
    swatch.addEventListener('click', function () {
      colorSwatches.forEach(function (s) { s.classList.remove('active'); });
      swatch.classList.add('active');
      state.primaryColor = swatch.dataset.color;
    });
  });

  // ── Secondary (Accent) swatches ───────────────────────────────────────────
  secondarySwatches.forEach(function (swatch) {
    swatch.addEventListener('click', function () {
      secondarySwatches.forEach(function (s) { s.classList.remove('active'); });
      swatch.classList.add('active');
      state.secondaryColor = swatch.dataset.color; // '' for Auto
    });
  });

  // ── Background color swatches ─────────────────────────────────────────────
  bgSwatches.forEach(function (swatch) {
    swatch.addEventListener('click', function () {
      bgSwatches.forEach(function (s) { s.classList.remove('bg-swatch--selected'); });
      swatch.classList.add('bg-swatch--selected');
      state.bgColor = swatch.dataset.color; // '' = transparent
    });
  });

  // ── Unified Media Zone ────────────────────────────────────────────────────
  mediaDrop.addEventListener('click', function () {
    // Use ExtendScript File.openDialog — HTML <input type="file"> greys out .pptx in CEP
    cs.evalScript('var f = File.openDialog("Select PPTX, PDF, or image"); f ? f.fsName : "";',
      function (result) {
        if (result && result.trim() && result.trim() !== 'null') {
          var p = stripOK(result.trim());
          routeMediaFile(p, p);
        }
      }
    );
  });

  mediaZone.addEventListener('dragover', function (e) {
    e.preventDefault();
    if (!state.mediaType) mediaZone.classList.add('drag-over');
  });

  mediaZone.addEventListener('dragleave', function () {
    mediaZone.classList.remove('drag-over');
  });

  mediaZone.addEventListener('drop', function (e) {
    e.preventDefault();
    mediaZone.classList.remove('drag-over');
    var files = e.dataTransfer.files;
    if (files && files[0]) routeMediaFile(files[0].path, files[0].name);
  });

  mediaInput.addEventListener('change', function () {
    if (mediaInput.files && mediaInput.files[0]) {
      routeMediaFile(mediaInput.files[0].path, mediaInput.files[0].name);
      mediaInput.value = '';
    }
  });

  clearMediaBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    clearMedia();
  });

  mediaZoomBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    if (state.imagePath) {
      openPreview([{ src: 'file://' + state.imagePath, label: path.basename(state.imagePath) }], 0);
    }
  });

  function clearMedia() {
    state.imagePath = null;
    state.pptxPath = null;
    state.deckSlides = [];
    state.doneSlidePaths = {};
    state.slideNotes = {};
    state.activeSlideIndex = null;
    state.mediaType = null;
    imagePreview.src = '';
    slideGrid.innerHTML = '';
    slideGridWrap.style.display = 'none';
    slideNotesWrap.style.display = 'none';
    slideNotesTextarea.value = '';
    mediaZone.classList.remove('has-media', 'has-image', 'has-deck');
    updateAbstractBtn();
  }

  function routeMediaFile(filePath, fileName) {
    var ext = (fileName || filePath).split('.').pop().toLowerCase();
    if (ext === 'pptx' || ext === 'ppt' || ext === 'pdf') {
      loadPptx(filePath);
    } else if (ext === 'json') {
      // Lottie animation — route to assets, not media zone
      var fakeFile = { path: filePath, name: path.basename(filePath || fileName) };
      addAssetFiles([fakeFile]);
    } else {
      loadImage(filePath);
    }
  }

  function loadImage(filePath) {
    if (!filePath) return;
    state.imagePath = filePath;
    state.mediaType = 'image';
    imagePreview.src = 'file://' + filePath;
    mediaZone.classList.add('has-media', 'has-image');
    updateAbstractBtn();
  }

  function loadPptx(filePath) {
    state.pptxPath = filePath;
    state.mediaType = 'deck';
    state.slideNotes = {};
    slideNotesTextarea.value = '';
    slideNotesWrap.style.display = 'none';
    deckLabel.textContent = path.basename(filePath);
    mediaZone.classList.add('has-media', 'has-deck');
    slideGrid.innerHTML = '';
    slideGridWrap.style.display = 'none';

    var ext = path.extname(filePath).toLowerCase();
    var isPdf = (ext === '.pdf');
    showProgress(0.05, isPdf ? 'Extracting PDF slides…' : 'Converting PPTX…');
    setStatus(isPdf ? 'Extracting PDF slides…' : 'Converting PPTX…', 'info');

    // Run notes extraction and conversion in parallel; render only when both complete.
    var pngPaths    = null;
    var notesInfo   = null;
    var pending     = isPdf ? 1 : 2;

    function tryMergeAndRender() {
      if (--pending > 0) return;
      hideProgress();
      var hidden     = notesInfo ? (notesInfo.hidden || []) : [];
      var notes      = notesInfo ? (notesInfo.notes  || {}) : {};
      var totalSlides = pngPaths.length + hidden.length;
      var allSlides  = [];
      var pngIdx     = 0;
      for (var n = 1; n <= totalSlides; n++) {
        if (hidden.indexOf(n) !== -1) {
          allSlides.push({ slideNum: n, pngPath: null, hidden: true });
        } else {
          allSlides.push({ slideNum: n, pngPath: pngPaths[pngIdx++], hidden: false });
        }
      }
      state.slideNotes = notes;
      renderSlideGrid(allSlides);
      var hiddenCount = hidden.length;
      setStatus(
        pngPaths.length + ' slides loaded' +
        (hiddenCount ? ' (' + hiddenCount + ' hidden)' : '') +
        '. Click a slide to animate.',
        'info'
      );
      slideNotesWrap.style.display = 'flex';
    }

    if (!isPdf) {
      extractPptxNotes(filePath, function (info) {
        notesInfo = info || { notes: {}, hidden: [] };
        tryMergeAndRender();
      });
    } else {
      notesInfo = { notes: {}, hidden: [] };
    }

    var convert = isPdf ? convertPdfToSlides : convertPptxToSlides;
    convert(filePath, function (err, paths) {
      if (err) {
        hideProgress();
        setStatus(err.message, 'error');
        clearMedia();
        return;
      }
      pngPaths = paths;
      tryMergeAndRender();
    });
  }

  // ── PPTX notes extraction (Python + zipfile) ──────────────────────────────
  // Returns { notes: {"1": "...", ...}, hidden: [3, 5, ...] }
  function extractPptxNotes(pptxPath, cb) {
    var pyScript = [
      'import sys, zipfile, json, re',
      'import xml.etree.ElementTree as ET',
      'pptx = sys.argv[1]',
      'A = "http://schemas.openxmlformats.org/drawingml/2006/main"',
      'P = "http://schemas.openxmlformats.org/presentationml/2006/main"',
      'notes = {}',
      'hidden = []',
      'try:',
      '    with zipfile.ZipFile(pptx) as z:',
      '        names = z.namelist()',
      '        slides = sorted([n for n in names if re.match(r"ppt/slides/slide\\d+\\.xml$", n)],',
      '                        key=lambda x: int(re.search(r"\\d+", x).group()))',
      '        for i, sf in enumerate(slides, 1):',
      '            sld_root = ET.fromstring(z.read(sf))',
      '            if sld_root.get("show") == "0": hidden.append(i)',
      '            sn = sf.split("/")[-1]',
      '            rp = "ppt/slides/_rels/" + sn + ".rels"',
      '            if rp not in names: continue',
      '            rels = ET.fromstring(z.read(rp))',
      '            nt = None',
      '            for r in rels:',
      '                tg = r.get("Target", "")',
      '                if "notesSlide" in tg:',
      '                    nt = "ppt/" + tg.replace("../", "")',
      '                    break',
      '            if not nt or nt not in names: continue',
      '            tree = ET.fromstring(z.read(nt))',
      '            texts = []',
      '            for sp in tree.findall(".//{%s}sp" % P):',
      '                ph = sp.find(".//{%s}ph" % P)',
      '                if ph is None: continue',
      '                idx = ph.get("idx", "0")',
      '                tp = ph.get("type", "")',
      '                if idx == "1" or tp == "body":',
      '                    for t in sp.iter("{%s}t" % A):',
      '                        if t.text and t.text.strip(): texts.append(t.text)',
      '            if texts: notes[str(i)] = " ".join(texts).strip()',
      'except Exception as e:',
      '    pass',
      'print(json.dumps({"notes": notes, "hidden": hidden}))'
    ].join('\n');

    function tryCmd(cmd) {
      var out = '';
      var proc = spawn(cmd, ['-c', pyScript, pptxPath]);
      proc.stdout.on('data', function (d) { out += d.toString(); });
      proc.on('close', function (code) {
        if (code !== 0 && cmd === 'python3') { tryCmd('python'); return; }
        try {
          var parsed = JSON.parse(out.trim());
          // Normalise: accept both new {notes,hidden} and legacy flat-notes format
          if (parsed && parsed.notes) { cb(parsed); }
          else { cb({ notes: parsed || {}, hidden: [] }); }
        } catch (e) { cb({ notes: {}, hidden: [] }); }
      });
      proc.on('error', function () {
        if (cmd === 'python3') { tryCmd('python'); } else { cb({ notes: {}, hidden: [] }); }
      });
    }
    tryCmd('python3');
  }

  // ── Slide grid ────────────────────────────────────────────────────────────
  // allSlides: [{ slideNum, pngPath, hidden }, ...]
  function renderSlideGrid(allSlides) {
    slideGrid.innerHTML = '';
    // deckSlides keeps only visible PNG paths (used by doneSlidePaths)
    state.deckSlides = allSlides.filter(function (s) { return !s.hidden; }).map(function (s) { return s.pngPath; });

    // Build preview items for lightbox (visible slides only)
    var previewableSlides = allSlides.filter(function (s) { return !s.hidden && s.pngPath; });

    allSlides.forEach(function (slide) {
      var thumb = document.createElement('div');
      var isDone = slide.pngPath && state.doneSlidePaths[slide.pngPath];
      thumb.className = 'slide-thumb' +
        (isDone ? ' done' : '') +
        (slide.hidden ? ' slide-hidden' : '');
      if (slide.pngPath) thumb.dataset.path = slide.pngPath;

      if (slide.pngPath) {
        var img = document.createElement('img');
        img.src = 'file://' + slide.pngPath;
        thumb.appendChild(img);
      }

      var numEl = document.createElement('div');
      numEl.className = 'slide-num';
      numEl.textContent = slide.slideNum;
      thumb.appendChild(numEl);

      if (slide.hidden) {
        var xEl = document.createElement('div');
        xEl.className = 'slide-hidden-x';
        xEl.textContent = '✕'; // ✕
        thumb.appendChild(xEl);
      } else {
        var badgeEl = document.createElement('div');
        badgeEl.className = 'slide-done-badge';
        badgeEl.innerHTML = '&#x2714;';
        thumb.appendChild(badgeEl);

        // Zoom button — opens lightbox at this slide
        if (slide.pngPath) {
          var zoomBtn = document.createElement('button');
          zoomBtn.className = 'slide-zoom-btn';
          zoomBtn.title = 'Preview slide';
          zoomBtn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>';
          zoomBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            var items = previewableSlides.map(function (s) {
              return { src: 'file://' + s.pngPath, label: 'Slide ' + s.slideNum };
            });
            var idx = previewableSlides.findIndex(function (s) { return s.slideNum === slide.slideNum; });
            openPreview(items, idx < 0 ? 0 : idx);
          });
          thumb.appendChild(zoomBtn);
        }

        thumb.addEventListener('click', function () {
          if (state.isRunning) return;
          state.imagePath = slide.pngPath;
          state.activeSlideIndex = slide.slideNum;
          var prev = slideGrid.querySelector('.slide-thumb.active');
          if (prev) prev.classList.remove('active');
          thumb.classList.add('active');
          var notes = state.slideNotes[String(slide.slideNum)] || '';
          slideNotesTextarea.value = notes;
          updateAbstractBtn();
          setStatus(
            notes.length
              ? 'Slide ' + slide.slideNum + ' selected — VO loaded. Click ABSTRACT to render.'
              : 'Slide ' + slide.slideNum + ' selected. Add a description and click ABSTRACT.',
            'info'
          );
        });
      }

      slideGrid.appendChild(thumb);
    });

    slideGridWrap.style.display = 'block';
  }

  // ── PPTX conversion: LibreOffice → PDF → PyMuPDF → PNGs ──────────────────
  function convertPptxToSlides(pptxPath, cb) {
    var tmpDir = path.join(os.tmpdir(), 'abstractor_slides_' + Date.now());
    try { fs.mkdirSync(tmpDir, { recursive: true }); } catch (e) {}

    var env = Object.assign({}, process.env, { PATH: CHILD_PATH });

    showProgress(0.15, 'Converting PPTX with LibreOffice…');

    // Step 1: LibreOffice → PDF
    var libreProc = spawn(SOFFICE, [
      '--headless', '--convert-to', 'pdf', '--outdir', tmpDir, pptxPath
    ], { env: env });

    libreProc.on('error', function (e) {
      cb(new Error('LibreOffice not found (' + e.message + '). Install from libreoffice.org'));
    });

    libreProc.on('close', function (code) {
      if (code !== 0) { cb(new Error('LibreOffice failed (exit ' + code + ')')); return; }

      var baseName = path.basename(pptxPath, path.extname(pptxPath));
      var pdfPath  = path.join(tmpDir, baseName + '.pdf');
      if (!fs.existsSync(pdfPath)) {
        cb(new Error('PDF not found after LibreOffice: ' + pdfPath));
        return;
      }

      showProgress(0.50, 'Extracting slide images…');
      // Step 2: PyMuPDF → PNGs
      pdfToPngs(pdfPath, tmpDir, cb);
    });
  }

  // ── PDF → PNGs directly (skip LibreOffice) ───────────────────────────────
  function convertPdfToSlides(pdfPath, cb) {
    var tmpDir = path.join(os.tmpdir(), 'abstractor_slides_' + Date.now());
    try { fs.mkdirSync(tmpDir, { recursive: true }); } catch (e) {}
    showProgress(0.30, 'Extracting slide images…');
    pdfToPngs(pdfPath, tmpDir, cb);
  }

  // ── PyMuPDF: PDF → PNGs ───────────────────────────────────────────────────
  function pdfToPngs(pdfPath, tmpDir, cb) {
    var pyScript = [
      'import sys, os, fitz',
      'doc = fitz.open(sys.argv[1])',
      'outDir = sys.argv[2]',
      'for i, page in enumerate(doc):',
      '    mat = fitz.Matrix(2, 2)',
      '    pix = page.get_pixmap(matrix=mat, alpha=False)',
      '    pix.save(os.path.join(outDir, "slide-%d.png" % (i + 1)))'
    ].join('\n');

    function collectPngs() {
      var pngs = fs.readdirSync(tmpDir)
        .filter(function (f) { return /^slide-\d+\.png$/.test(f); })
        .sort(function (a, b) {
          return parseInt(a.match(/\d+/)[0], 10) - parseInt(b.match(/\d+/)[0], 10);
        })
        .map(function (f) { return path.join(tmpDir, f); });
      if (pngs.length === 0) { cb(new Error('No pages extracted from PDF')); return; }
      showProgress(0.95, 'Loading slides…');
      cb(null, pngs);
    }

    function tryCmd(cmd) {
      var stderr = '';
      var proc = spawn(cmd, ['-c', pyScript, pdfPath, tmpDir]);
      proc.stderr.on('data', function (d) { stderr += d.toString(); });
      proc.on('error', function () {
        // Binary not found — try 'python' as Windows fallback, then give up
        if (cmd === 'python3') { tryCmd('python'); } else { notFound(); }
      });
      proc.on('close', function (code) {
        if (code !== 0) {
          if (cmd === 'python3') { tryCmd('python'); return; }
          notFound();
          return;
        }
        try { collectPngs(); } catch (e) { cb(e); }
      });
    }

    function notFound() {
      cb(new Error(
        'PDF conversion failed: Python not found or PyMuPDF not installed.\n' +
        'Install Python from python.org, then run: pip install pymupdf'
      ));
    }

    tryCmd('python3');
  }

  // ── Mode toggle ───────────────────────────────────────────────────────────
  modeBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      modeBtns.forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      state.modeOverride = btn.dataset.mode || null;
      // Show layout dropdown in Redesign mode (data-mode="")
      var showSubtype = (btn.dataset.mode === '');
      layoutOverrideSelect.classList.toggle('visible', showSubtype);
      if (!showSubtype) {
        layoutOverrideSelect.value = '';
        state.layoutOverride = null;
      }
      // Show Creative Brief only in Creative mode
      creativeBriefEl.classList.toggle('visible', btn.dataset.mode === 'creative');
    });
  });

  // Show layout dropdown on init if Redesign is the active mode
  (function () {
    var activeBtn = document.querySelector('.mode-btn.active');
    if (activeBtn && activeBtn.dataset.mode === '') {
      layoutOverrideSelect.classList.add('visible');
    }
  })();

  // ── Creative Brief interactions ──────────────────────────────────────────
  archetypeCards.forEach(function (card) {
    card.addEventListener('click', function () {
      var wasSelected = card.classList.contains('selected');
      archetypeCards.forEach(function (c) { c.classList.remove('selected'); });
      if (!wasSelected) {
        card.classList.add('selected');
        state.creativeBrief.archetype = card.dataset.archetype;
      } else {
        state.creativeBrief.archetype = null;
      }
    });
  });

  moodPills.forEach(function (pill) {
    pill.addEventListener('click', function () {
      var wasSelected = pill.classList.contains('selected');
      moodPills.forEach(function (p) { p.classList.remove('selected'); });
      if (!wasSelected) {
        pill.classList.add('selected');
        state.creativeBrief.mood = pill.dataset.mood;
      } else {
        state.creativeBrief.mood = null;
      }
    });
  });

  motionPills.forEach(function (pill) {
    pill.addEventListener('click', function () {
      var wasSelected = pill.classList.contains('selected');
      motionPills.forEach(function (p) { p.classList.remove('selected'); });
      if (!wasSelected) {
        pill.classList.add('selected');
        state.creativeBrief.motion = pill.dataset.motion;
      } else {
        state.creativeBrief.motion = null;
      }
    });
  });

  directorNoteInput.addEventListener('input', function () {
    state.creativeBrief.directorNote = this.value;
  });

  var ARCHETYPE_VALUES = ['data-story','system-map','concept-reveal','showcase','journey','versus'];
  var MOOD_VALUES      = ['sharp','organic','minimal','electric','dense'];
  var MOTION_VALUES    = ['assembled','revealed','emerged'];
  briefRandomizeBtn.addEventListener('click', function () {
    var rArch   = ARCHETYPE_VALUES[Math.floor(Math.random() * ARCHETYPE_VALUES.length)];
    var rMood   = MOOD_VALUES[Math.floor(Math.random() * MOOD_VALUES.length)];
    var rMotion = MOTION_VALUES[Math.floor(Math.random() * MOTION_VALUES.length)];
    archetypeCards.forEach(function (c) { c.classList.toggle('selected', c.dataset.archetype === rArch); });
    moodPills.forEach(function (p) { p.classList.toggle('selected', p.dataset.mood === rMood); });
    motionPills.forEach(function (p) { p.classList.toggle('selected', p.dataset.motion === rMotion); });
    state.creativeBrief.archetype = rArch;
    state.creativeBrief.mood      = rMood;
    state.creativeBrief.motion    = rMotion;
  });

  // ── Layout sub-type override ──────────────────────────────────────────────
  layoutOverrideSelect.addEventListener('change', function () {
    state.layoutOverride = this.value || null;
    // Redesign + specific layout → use diagram mode internally for structured output
    if (state.modeOverride === null || state.modeOverride === 'diagram') {
      state.modeOverride = state.layoutOverride ? 'diagram' : null;
    }
  });

  // ── Content textarea ──────────────────────────────────────────────────────
  contentTextarea.addEventListener('input', updateAbstractBtn);
  slideNotesTextarea.addEventListener('input', updateAbstractBtn);

  function updateAbstractBtn() {
    var busy = state.isRunning;
    var hasVO = slideNotesTextarea.value.trim().length > 0;
    // Show "optional" tag on concept box when VO is present
    conceptOptionalTag.style.display = hasVO ? '' : 'none';
    abstractBtn.disabled        = busy;
    cancelBtn.style.display     = busy ? '' : 'none';
    recreateBtn.style.display   = busy ? 'none' : '';
    recreateBtn.disabled        = !(state.lastText && !busy);
  }

  // ── Wireframe SVG templates ───────────────────────────────────────────────
  var WIREFRAME_SVGS = {
    comparison:   '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="8" width="50" height="64" rx="2" fill="#1a1a1a" stroke="#4a4a4a" stroke-width="1.5"/><rect x="8" y="13" width="42" height="6" rx="1" fill="#76b900" opacity="0.65"/><line x1="8" y1="24" x2="50" y2="24" stroke="#2a2a2a" stroke-width="0.8"/><rect x="8" y="28" width="8" height="5" rx="1" fill="#333"/><rect x="18" y="30" width="28" height="3" rx="1" fill="#2e2e2e"/><rect x="8" y="37" width="8" height="5" rx="1" fill="#333"/><rect x="18" y="39" width="22" height="3" rx="1" fill="#2e2e2e"/><rect x="8" y="46" width="8" height="5" rx="1" fill="#333"/><rect x="18" y="48" width="26" height="3" rx="1" fill="#2e2e2e"/><rect x="8" y="55" width="8" height="5" rx="1" fill="#333"/><rect x="18" y="57" width="20" height="3" rx="1" fill="#2e2e2e"/><rect x="66" y="8" width="50" height="64" rx="2" fill="#1a1a1a" stroke="#3a3a3a" stroke-width="1.5"/><rect x="70" y="13" width="42" height="6" rx="1" fill="#444" opacity="0.65"/><line x1="70" y1="24" x2="112" y2="24" stroke="#2a2a2a" stroke-width="0.8"/><rect x="70" y="28" width="8" height="5" rx="1" fill="#333"/><rect x="80" y="30" width="28" height="3" rx="1" fill="#2e2e2e"/><rect x="70" y="37" width="8" height="5" rx="1" fill="#333"/><rect x="80" y="39" width="22" height="3" rx="1" fill="#2e2e2e"/><rect x="70" y="46" width="8" height="5" rx="1" fill="#333"/><rect x="80" y="48" width="26" height="3" rx="1" fill="#2e2e2e"/><rect x="70" y="55" width="8" height="5" rx="1" fill="#333"/><rect x="80" y="57" width="20" height="3" rx="1" fill="#2e2e2e"/><circle cx="60" cy="40" r="4" fill="none" stroke="#555" stroke-width="1"/></svg>',
    list:         '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><circle cx="14" cy="17" r="5" fill="none" stroke="#76b900" stroke-width="1.5"/><rect x="25" y="13" width="50" height="4" rx="1" fill="#555"/><rect x="25" y="20" width="35" height="3" rx="1" fill="#3a3a3a"/><line x1="4" y1="30" x2="116" y2="30" stroke="#262626" stroke-width="0.8"/><circle cx="14" cy="39" r="5" fill="none" stroke="#3a3a3a" stroke-width="1.2"/><rect x="25" y="35" width="55" height="4" rx="1" fill="#3a3a3a"/><rect x="25" y="42" width="40" height="3" rx="1" fill="#2e2e2e"/><line x1="4" y1="51" x2="116" y2="51" stroke="#262626" stroke-width="0.8"/><circle cx="14" cy="60" r="5" fill="none" stroke="#3a3a3a" stroke-width="1.2"/><rect x="25" y="56" width="45" height="4" rx="1" fill="#3a3a3a"/><rect x="25" y="63" width="30" height="3" rx="1" fill="#2e2e2e"/></svg>',
    architecture: '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><rect x="40" y="4" width="40" height="20" rx="2" fill="#1a1a1a" stroke="#76b900" stroke-width="1.5"/><rect x="44" y="9" width="32" height="6" rx="1" fill="#76b900" opacity="0.5"/><line x1="60" y1="24" x2="60" y2="36" stroke="#444" stroke-width="1"/><line x1="22" y1="36" x2="98" y2="36" stroke="#444" stroke-width="1"/><line x1="22" y1="36" x2="22" y2="48" stroke="#444" stroke-width="1"/><line x1="60" y1="36" x2="60" y2="48" stroke="#444" stroke-width="1"/><line x1="98" y1="36" x2="98" y2="48" stroke="#444" stroke-width="1"/><rect x="4" y="48" width="36" height="24" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="8" y="54" width="28" height="4" rx="1" fill="#333"/><rect x="8" y="61" width="20" height="3" rx="1" fill="#2a2a2a"/><rect x="42" y="48" width="36" height="24" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="46" y="54" width="28" height="4" rx="1" fill="#333"/><rect x="46" y="61" width="20" height="3" rx="1" fill="#2a2a2a"/><rect x="80" y="48" width="36" height="24" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="84" y="54" width="28" height="4" rx="1" fill="#333"/><rect x="84" y="61" width="20" height="3" rx="1" fill="#2a2a2a"/></svg>',
    flow:         '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="28" width="28" height="24" rx="2" fill="#1a1a1a" stroke="#76b900" stroke-width="1.5"/><rect x="8" y="34" width="20" height="5" rx="1" fill="#76b900" opacity="0.55"/><rect x="8" y="42" width="14" height="3" rx="1" fill="#3a3a3a"/><line x1="32" y1="40" x2="43" y2="40" stroke="#555" stroke-width="1.2"/><polyline fill="none" stroke="#555" stroke-width="1.2" points="40,37 43,40 40,43"/><rect x="43" y="28" width="28" height="24" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="47" y="34" width="20" height="5" rx="1" fill="#3a3a3a"/><rect x="47" y="42" width="14" height="3" rx="1" fill="#2e2e2e"/><line x1="71" y1="40" x2="82" y2="40" stroke="#555" stroke-width="1.2"/><polyline fill="none" stroke="#555" stroke-width="1.2" points="79,37 82,40 79,43"/><rect x="82" y="28" width="28" height="24" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="86" y="34" width="20" height="5" rx="1" fill="#3a3a3a"/><rect x="86" y="42" width="14" height="3" rx="1" fill="#2e2e2e"/></svg>',
    metrics:      '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="10" width="33" height="60" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="8" y="18" width="25" height="20" rx="1" fill="#76b900" opacity="0.15"/><rect x="10" y="20" width="21" height="14" rx="1" fill="#76b900" opacity="0.45"/><rect x="8" y="42" width="25" height="4" rx="1" fill="#333"/><rect x="10" y="49" width="18" height="3" rx="1" fill="#2a2a2a"/><rect x="43" y="10" width="33" height="60" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="47" y="18" width="25" height="20" rx="1" fill="#76b900" opacity="0.15"/><rect x="49" y="20" width="21" height="14" rx="1" fill="#76b900" opacity="0.45"/><rect x="47" y="42" width="25" height="4" rx="1" fill="#333"/><rect x="49" y="49" width="18" height="3" rx="1" fill="#2a2a2a"/><rect x="82" y="10" width="33" height="60" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="86" y="18" width="25" height="20" rx="1" fill="#76b900" opacity="0.15"/><rect x="88" y="20" width="21" height="14" rx="1" fill="#76b900" opacity="0.45"/><rect x="86" y="42" width="25" height="4" rx="1" fill="#333"/><rect x="88" y="49" width="18" height="3" rx="1" fill="#2a2a2a"/></svg>',
    timeline:     '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><line x1="8" y1="46" x2="112" y2="46" stroke="#3a3a3a" stroke-width="1.5"/><circle cx="22" cy="46" r="5" fill="#1a1a1a" stroke="#76b900" stroke-width="1.5"/><rect x="14" y="14" width="16" height="24" rx="1" fill="#1a1a1a" stroke="#333" stroke-width="0.8"/><rect x="16" y="17" width="12" height="4" rx="1" fill="#555"/><rect x="16" y="24" width="9" height="3" rx="1" fill="#333"/><line x1="22" y1="38" x2="22" y2="41" stroke="#76b900" stroke-width="1"/><circle cx="48" cy="46" r="5" fill="#1a1a1a" stroke="#3a3a3a" stroke-width="1.2"/><rect x="40" y="52" width="16" height="20" rx="1" fill="#1a1a1a" stroke="#2a2a2a" stroke-width="0.8"/><rect x="42" y="55" width="12" height="4" rx="1" fill="#3a3a3a"/><rect x="42" y="62" width="9" height="3" rx="1" fill="#2e2e2e"/><line x1="48" y1="51" x2="48" y2="52" stroke="#3a3a3a" stroke-width="1"/><circle cx="74" cy="46" r="5" fill="#1a1a1a" stroke="#3a3a3a" stroke-width="1.2"/><rect x="66" y="14" width="16" height="24" rx="1" fill="#1a1a1a" stroke="#2a2a2a" stroke-width="0.8"/><rect x="68" y="17" width="12" height="4" rx="1" fill="#3a3a3a"/><rect x="68" y="24" width="9" height="3" rx="1" fill="#2e2e2e"/><line x1="74" y1="38" x2="74" y2="41" stroke="#3a3a3a" stroke-width="1"/><circle cx="100" cy="46" r="5" fill="#1a1a1a" stroke="#3a3a3a" stroke-width="1.2"/><rect x="92" y="52" width="16" height="20" rx="1" fill="#1a1a1a" stroke="#2a2a2a" stroke-width="0.8"/><rect x="94" y="55" width="12" height="4" rx="1" fill="#3a3a3a"/><rect x="94" y="62" width="9" height="3" rx="1" fill="#2e2e2e"/><line x1="100" y1="51" x2="100" y2="52" stroke="#3a3a3a" stroke-width="1"/></svg>',
    steps:        '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="22" width="24" height="36" rx="2" fill="#1a1a1a" stroke="#76b900" stroke-width="1.5"/><rect x="7" y="26" width="8" height="8" rx="1" fill="#76b900" opacity="0.65"/><rect x="7" y="38" width="18" height="4" rx="1" fill="#3a3a3a"/><rect x="7" y="44" width="13" height="3" rx="1" fill="#2e2e2e"/><line x1="28" y1="40" x2="35" y2="40" stroke="#444" stroke-width="1"/><polyline fill="none" stroke="#444" stroke-width="1" points="32,37.5 35,40 32,42.5"/><rect x="35" y="22" width="24" height="36" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="38" y="26" width="8" height="8" rx="1" fill="#333"/><rect x="38" y="38" width="18" height="4" rx="1" fill="#2e2e2e"/><rect x="38" y="44" width="13" height="3" rx="1" fill="#262626"/><line x1="59" y1="40" x2="66" y2="40" stroke="#444" stroke-width="1"/><polyline fill="none" stroke="#444" stroke-width="1" points="63,37.5 66,40 63,42.5"/><rect x="66" y="22" width="24" height="36" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="69" y="26" width="8" height="8" rx="1" fill="#333"/><rect x="69" y="38" width="18" height="4" rx="1" fill="#2e2e2e"/><rect x="69" y="44" width="13" height="3" rx="1" fill="#262626"/><line x1="90" y1="40" x2="97" y2="40" stroke="#444" stroke-width="1"/><polyline fill="none" stroke="#444" stroke-width="1" points="94,37.5 97,40 94,42.5"/><rect x="97" y="22" width="24" height="36" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="100" y="26" width="8" height="8" rx="1" fill="#333"/><rect x="100" y="38" width="18" height="4" rx="1" fill="#2e2e2e"/><rect x="100" y="44" width="13" height="3" rx="1" fill="#262626"/></svg>',
    hierarchy:    '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><rect x="40" y="4" width="40" height="18" rx="2" fill="#1a1a1a" stroke="#76b900" stroke-width="1.5"/><rect x="44" y="9" width="32" height="5" rx="1" fill="#76b900" opacity="0.55"/><line x1="60" y1="22" x2="60" y2="34" stroke="#444" stroke-width="1"/><line x1="20" y1="34" x2="100" y2="34" stroke="#444" stroke-width="1"/><line x1="20" y1="34" x2="20" y2="46" stroke="#444" stroke-width="1"/><line x1="60" y1="34" x2="60" y2="46" stroke="#444" stroke-width="1"/><line x1="100" y1="34" x2="100" y2="46" stroke="#444" stroke-width="1"/><rect x="4" y="46" width="32" height="22" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="8" y="52" width="24" height="4" rx="1" fill="#333"/><rect x="8" y="59" width="16" height="3" rx="1" fill="#2a2a2a"/><rect x="44" y="46" width="32" height="22" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="48" y="52" width="24" height="4" rx="1" fill="#333"/><rect x="48" y="59" width="16" height="3" rx="1" fill="#2a2a2a"/><rect x="84" y="46" width="32" height="22" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="88" y="52" width="24" height="4" rx="1" fill="#333"/><rect x="88" y="59" width="16" height="3" rx="1" fill="#2a2a2a"/></svg>',
    'free-diagram': '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="6" width="52" height="30" rx="2" fill="#1a1a1a" stroke="#76b900" stroke-width="1.5"/><rect x="8" y="12" width="44" height="6" rx="1" fill="#76b900" opacity="0.55"/><rect x="8" y="22" width="36" height="3" rx="1" fill="#333"/><rect x="8" y="27" width="28" height="3" rx="1" fill="#2a2a2a"/><rect x="64" y="6" width="52" height="30" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="68" y="12" width="44" height="6" rx="1" fill="#333"/><rect x="68" y="22" width="36" height="3" rx="1" fill="#2a2a2a"/><rect x="68" y="27" width="28" height="3" rx="1" fill="#222"/><line x1="56" y1="21" x2="64" y2="21" stroke="#444" stroke-width="1"/><rect x="4" y="44" width="112" height="30" rx="2" fill="#1a1a1a" stroke="#333" stroke-width="1"/><rect x="8" y="50" width="55" height="5" rx="1" fill="#333"/><rect x="8" y="59" width="44" height="3" rx="1" fill="#2a2a2a"/><rect x="72" y="50" width="36" height="5" rx="1" fill="#2a2a2a"/><rect x="72" y="59" width="28" height="3" rx="1" fill="#222"/></svg>',
    creative:     '<svg viewBox="0 0 120 80" xmlns="http://www.w3.org/2000/svg"><rect x="16" y="18" width="52" height="40" rx="20" fill="none" stroke="#76b900" stroke-width="1.5" stroke-dasharray="5 3"/><circle cx="86" cy="30" r="16" fill="none" stroke="#3a3a3a" stroke-width="1.2"/><circle cx="36" cy="54" r="9" fill="#76b900" opacity="0.2"/><rect x="68" y="46" width="44" height="26" rx="2" fill="#1a1a1a" stroke="#2a2a2a" stroke-width="1"/><rect x="72" y="53" width="36" height="4" rx="1" fill="#3a3a3a"/><rect x="72" y="60" width="24" height="3" rx="1" fill="#2e2e2e"/><line x1="8" y1="14" x2="28" y2="28" stroke="#76b900" stroke-width="1" opacity="0.4"/><line x1="92" y1="8" x2="112" y2="22" stroke="#333" stroke-width="1" opacity="0.5"/></svg>'
  };

  // ── Wireframe picker state ─────────────────────────────────────────────────
  var wireframeCountdownTimer = null;
  var wireframeSecondsLeft = 30;
  var wireframeSelectedIndex = 0;

  function showWireframePicker(wireframes) {
    wireframeCardsEl.innerHTML = '';
    wireframeSelectedIndex = 0;

    wireframes.forEach(function(wf, i) {
      var card = document.createElement('div');
      card.className = 'wireframe-card' + (i === 0 ? ' selected' : '');

      var svgKey = wf.layoutType || wf.mode;
      var svgHtml = WIREFRAME_SVGS[svgKey] || WIREFRAME_SVGS['free-diagram'];
      card.innerHTML = svgHtml + '<div class="wireframe-card-label">' + (wf.label || 'Auto') + '</div>';

      // Confidence pips (5 total)
      var pipsDiv = document.createElement('div');
      pipsDiv.className = 'wireframe-confidence';
      var numFilled = Math.max(1, Math.round((wf.confidence || 0.5) * 5));
      for (var p = 0; p < 5; p++) {
        var pip = document.createElement('div');
        pip.className = 'wireframe-confidence-pip' + (p < numFilled ? ' filled' : '');
        pipsDiv.appendChild(pip);
      }
      card.appendChild(pipsDiv);

      (function(idx) {
        card.addEventListener('click', function() {
          wireframeCardsEl.querySelectorAll('.wireframe-card').forEach(function(c) { c.classList.remove('selected'); });
          card.classList.add('selected');
          wireframeSelectedIndex = idx;
        });
      }(i));

      wireframeCardsEl.appendChild(card);
    });

    wireframeSecondsLeft = 10;
    wireframeSecondsEl.textContent = '10';
    wireframeOverlay.classList.add('visible');

    if (wireframeCountdownTimer) clearInterval(wireframeCountdownTimer);
    wireframeCountdownTimer = setInterval(function() {
      wireframeSecondsLeft--;
      wireframeSecondsEl.textContent = String(wireframeSecondsLeft);
      if (wireframeSecondsLeft <= 0) {
        clearInterval(wireframeCountdownTimer);
        wireframeCountdownTimer = null;
        dismissWireframePicker(); // render continues as-is
      }
    }, 1000);

    // "Change Layout" — kill current render and restart with picked layout
    wireframeRenderBtn.onclick = function() {
      if (wireframeCountdownTimer) { clearInterval(wireframeCountdownTimer); wireframeCountdownTimer = null; }
      var picked = wireframes[wireframeSelectedIndex] || wireframes[0];
      var pickedMode = (picked.mode === 'creative') ? 'creative'
                     : (picked.mode === 'free-diagram') ? null
                     : 'diagram';
      dismissWireframePicker();
      state.pendingLayoutChange = { mode: pickedMode, layout: picked.layoutType || null };
      if (state.childProcess) {
        try { state.childProcess.kill(); } catch (e) {}
      }
    };

    // "Keep current" — dismiss, render continues
    wireframeSkipBtn.onclick = function() {
      if (wireframeCountdownTimer) { clearInterval(wireframeCountdownTimer); wireframeCountdownTimer = null; }
      dismissWireframePicker();
    };
  }

  function dismissWireframePicker() {
    wireframeOverlay.classList.remove('visible');
    if (wireframeCountdownTimer) { clearInterval(wireframeCountdownTimer); wireframeCountdownTimer = null; }
  }

  // ── runClassify: parallel Haiku classify — shows picker overlay if render is still running ──
  function runClassify(imagePath, textContent) {
    var remotionDir  = path.join(extPath, 'remotion');
    var bridgeScript = path.join(extPath, 'scripts', 'abstractor-bridge.js');

    var classifyArgs = [bridgeScript, '--classify-only', '1', '--remotion', remotionDir];
    if (imagePath) classifyArgs.push('--image', imagePath);
    if (textContent) classifyArgs.push('--text', textContent);
    if (state.modeOverride) classifyArgs.push('--render-mode', state.modeOverride);
    if (state.layoutOverride) classifyArgs.push('--layout-override', state.layoutOverride);

    var childEnv = Object.assign({}, process.env, { PATH: CHILD_PATH });
    var classifyChild = spawn(NODE_BIN, classifyArgs, { env: childEnv });
    state.classifyProcess = classifyChild;

    var wireframes = null;

    classifyChild.stderr.on('data', function(data) {
      data.toString().split('\n').forEach(function(line) {
        line = line.trim();
        if (!line) return;
        try {
          var evt = JSON.parse(line);
          if (evt.wireframes) wireframes = evt.wireframes;
        } catch (e) {}
      });
    });

    classifyChild.on('close', function() {
      state.classifyProcess = null;
      // Only show picker if the render is still in progress
      if (state.isRunning && wireframes && wireframes.length > 0) {
        showWireframePicker(wireframes);
      }
    });
  }

  // ── Abstract button ───────────────────────────────────────────────────────
  abstractBtn.addEventListener('click', function () {
    if (state.isRunning) return;
    var vo      = slideNotesTextarea.value.trim();
    var concept = contentTextarea.value.trim();
    // VO takes priority; concept is additional context
    var combinedText = vo
      ? (concept ? vo + '\n\n[Additional context]: ' + concept : vo)
      : concept;
    state.lastImagePath = state.imagePath;
    state.lastText      = combinedText;
    state.lastVo        = vo;
    state.lastConcept   = concept;
    // Track which slide thumb corresponds to this render (for done-badge)
    state.activeSlideThumb = slideGrid.querySelector('.slide-thumb.active') || null;

    runAbstractor(state.imagePath, combinedText);
  });

  // ── Cancel button ─────────────────────────────────────────────────────────
  cancelBtn.addEventListener('click', function () {
    if (!state.isRunning) return;
    state.pendingLayoutChange = null; // prevent auto-restart on kill
    if (state.classifyProcess) {
      try { state.classifyProcess.kill(); } catch (e) {}
      state.classifyProcess = null;
    }
    if (state.childProcess) {
      try { state.childProcess.kill(); } catch (e) {}
      state.childProcess = null;
    }
    state.isRunning = false;
    state.activeSlideThumb = null;
    dismissWireframePicker();
    updateAbstractBtn();
    hideProgress();
    setStatus('Cancelled.', 'info');
    stopTimer();
  });

  // ── Recreate button ───────────────────────────────────────────────────────
  recreateBtn.addEventListener('click', function () {
    if (state.isRunning || !state.lastText) return;
    runAbstractor(state.lastImagePath, state.lastText);
  });

  // ── Reset ─────────────────────────────────────────────────────────────────
  resetBtn.addEventListener('click', function () {
    if (state.isRunning) return;
    // Clear media
    clearMedia();
    // Clear text fields
    contentTextarea.value = '';
    if (typeof fixTextarea !== 'undefined') fixTextarea.value = '';
    // Clear length
    lengthInput.value = '';
    // Reset primary color to NVIDIA Green
    colorSwatches.forEach(function (s) { s.classList.remove('active'); });
    var defaultSwatch = document.querySelector('.color-swatch[data-color="rgb(118,185,0)"]');
    if (defaultSwatch) defaultSwatch.classList.add('active');
    state.primaryColor = 'rgb(118,185,0)';
    // Reset accent to Auto
    secondarySwatches.forEach(function (s) { s.classList.remove('active'); });
    var autoSwatch = document.querySelector('.secondary-swatch[data-color=""]');
    if (autoSwatch) autoSwatch.classList.add('active');
    state.secondaryColor = '';
    // Reset bg to transparent
    bgSwatches.forEach(function (s) { s.classList.remove('bg-swatch--selected'); });
    var transSwatch = document.querySelector('.bg-swatch[data-color=""]');
    if (transSwatch) transSwatch.classList.add('bg-swatch--selected');
    state.bgColor = '';
    // Clear name input
    if (nameInput) nameInput.value = '';
    // Clear log
    logContent.innerHTML = '';
    // Hide fix row and progress bar
    fixRow.classList.remove('visible');
    fixRow.classList.remove('fix-complete');
    if (typeof fixTextarea !== 'undefined') fixTextarea.value = '';
    fixChips.forEach(function (c) { c.classList.remove('selected'); });
    progressWrap.classList.remove('visible');
    progressFill.style.width = '0%';
    // Reset last render state
    state.lastText = null;
    state.lastImagePath = null;
    state.lastCompPath = null;
    state.lastOutputBase = null;
    // Reset Creative Brief
    state.creativeBrief = { archetype: null, mood: null, motion: null, directorNote: '' };
    archetypeCards.forEach(function (c) { c.classList.remove('selected'); });
    moodPills.forEach(function (p) { p.classList.remove('selected'); });
    motionPills.forEach(function (p) { p.classList.remove('selected'); });
    directorNoteInput.value = '';
    updateUI();
  });

  // ── Fix / Tweak ───────────────────────────────────────────────────────────
  function updateFixBtn() {
    var hasChip = Array.from(fixChips).some(function (c) { return c.classList.contains('selected'); });
    var hasText = fixTextarea.value.trim().length > 0;
    fixBtn.disabled = (!hasChip && !hasText) || state.isRunning;
  }

  fixChips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      chip.classList.toggle('selected');
      updateFixBtn();
    });
  });

  fixTextarea.addEventListener('input', function () {
    updateFixBtn();
  });

  fixBtn.addEventListener('click', function () {
    var chipParts = Array.from(fixChips)
      .filter(function (c) { return c.classList.contains('selected'); })
      .map(function (c) { return c.dataset.fix; });
    var custom = fixTextarea.value.trim();
    var parts = chipParts.slice();
    if (custom) parts.push(custom);
    var request = parts.join(' ');
    if (!request || state.isRunning || !state.lastCompPath) return;
    runFix(request);
  });

  function runFix(fixRequest) {
    state.isRunning = true;
    updateAbstractBtn();
    fixBtn.disabled = true;

    var slideNum     = state.lastSlideNum || '00';
    var remotionDir  = path.join(extPath, 'remotion');
    var bridgeScript = path.join(extPath, 'scripts', 'abstractor-bridge.js');

    clearLog();
    showProgress(0, 'Starting fix…');
    setStatus('', 'info');
    startTimer();

    getEffectiveOutputFolder(function (outputFolder) {
      var serial     = nextSerial(outputFolder);
      var outputBase = 'Slide_' + slideNum + '_Abstractor_' + serial + '_Fix';
      var outputPath = path.join(outputFolder, outputBase + '.mov');

      var args = [
        bridgeScript,
        '--fix-request', fixRequest,
        '--output',      outputPath,
        '--remotion',    remotionDir
      ];
      args.push('--primary-color', state.primaryColor);
      if (state.secondaryColor) args.push('--secondary-color', state.secondaryColor);
      if (state.bgColor) args.push('--bg-color', state.bgColor);
      args.push('--model', getSelectedModelId());
      var lengthSec = parseInt(lengthInput.value, 10);
      if (lengthSec >= 1 && lengthSec <= 60) args.push('--length', String(lengthSec));
      if (quality4kCb.checked) args.push('--quality-4k', '1');

      var childEnv = Object.assign({}, process.env, { PATH: CHILD_PATH });
      appendLog('Fix mode: ' + fixRequest, '');
      appendLog('output: ' + outputPath, '');

      var child = spawn(NODE_BIN, args, { env: childEnv });
      state.childProcess = child;

      child.stdout.on('data', function (data) { appendLog(data.toString(), 'ok'); });

      child.stderr.on('data', function (data) {
        data.toString().split('\n').forEach(function (line) {
          line = line.trim();
          if (!line) return;
          try {
            var evt = JSON.parse(line);
            if (typeof evt.progress === 'number') showProgress(evt.progress, evt.message || '');
            if (evt.log) appendLog(evt.log, evt.type || '');
          } catch (e) { appendLog(line, ''); }
        });
      });

      child.on('close', function (code) {
        state.isRunning = false;
        state.childProcess = null;
        updateAbstractBtn();
        updateFixBtn();
        stopTimer();
        hideProgress();

        if (code === 0) {
          setStatus('Importing fixed render into After Effects…', 'info');
          var escaped = outputPath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
          cs.evalScript('importToAE("' + escaped + '")', function (result) {
            if (!result || result.indexOf('error') === 0) {
              setStatus((result || 'AE import failed — is After Effects open?'), 'error');
            } else {
              var noComp = result.indexOf('ok-no-comp:') === 0;
              var payload = result.replace(/^ok(-no-comp)?:/, '');
              var pipeIdx = payload.indexOf('|');
              var folderPart = pipeIdx >= 0 ? payload.slice(0, pipeIdx) : payload;
              state.lastRendersFolder = folderPart || outputFolder;
              setStatus(noComp ? 'Fix rendered! No open comp — footage added to Project panel.' : 'Fix applied! Saved as ' + outputBase + '.mov', noComp ? 'warn' : 'success');
              fixRow.classList.add('fix-complete');
              fixTextarea.value = '';
              fixChips.forEach(function (c) { c.classList.remove('selected'); });
              fixBtn.disabled = true;
              if (state.lastHistoryId) {
                historyManager.addFix(state.lastHistoryId, {
                  request:    fixRequest,
                  outputName: outputBase + '.mov',
                  outputPath: outputPath,
                });
                renderHistorySection();
              }
            }
          });
        } else {
          setStatus('Fix failed (exit ' + code + '). Check log.', 'error');
        }
      });

      child.on('error', function (err) {
        state.isRunning = false;
        state.childProcess = null;
        updateAbstractBtn();
        updateFixBtn();
        hideProgress();
        setStatus('Could not start Node: ' + err.message, 'error');
      });
    });
  }

  // ── Open Renders Folder ───────────────────────────────────────────────────
  openFolderBtn.addEventListener('click', function () {
    if (state.lastRendersFolder) {
      exec('open "' + state.lastRendersFolder.replace(/"/g, '\\"') + '"');
    } else {
      // Try AE ExtendScript as fallback (only works when project is saved)
      cs.evalScript('openRendersFolder()', function (result) {
        if (result && result.indexOf('error') === 0) {
          setStatus('Save your AE project first, then renders will open here.', 'info');
        }
      });
    }
  });

  // ── Log accordion ─────────────────────────────────────────────────────────
  logToggle.addEventListener('click', function () {
    logToggle.classList.toggle('open');
    logContent.classList.toggle('open');
  });

  logCopyBtn.addEventListener('click', function () {
    var text = logContent.innerText || logContent.textContent || '';
    if (!text.trim()) return;
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity  = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    logCopyLabel.textContent = 'Copied!';
    logCopyBtn.classList.add('copied');
    setTimeout(function () {
      logCopyLabel.textContent = 'Copy';
      logCopyBtn.classList.remove('copied');
    }, 2000);
  });

  // ── Options panel ────────────────────────────────────────────────────────
  optionsToggle.addEventListener('click', function () {
    optionsToggle.classList.toggle('open');
    optionsPanel.classList.toggle('open');
  });

  assetsDropZone.addEventListener('click', function () { assetsInput.click(); });

  assetsDropZone.addEventListener('dragover', function (e) {
    e.preventDefault();
    assetsDropZone.classList.add('drag-over');
  });

  assetsDropZone.addEventListener('dragleave', function () {
    assetsDropZone.classList.remove('drag-over');
  });

  assetsDropZone.addEventListener('drop', function (e) {
    e.preventDefault();
    assetsDropZone.classList.remove('drag-over');
    addAssetFiles(e.dataTransfer.files);
  });

  assetsInput.addEventListener('change', function () {
    if (assetsInput.files && assetsInput.files.length) {
      addAssetFiles(assetsInput.files);
      assetsInput.value = '';
    }
  });

  function assetTypeFromExt(ext) {
    if (ext === '.svg')  return 'svg';
    if (ext === '.png')  return 'png';
    if (ext === '.ai')   return 'ai';
    if (ext === '.json') return 'lottie';
    return 'file';
  }

  function addAssetFiles(files) {
    for (var i = 0; i < files.length; i++) {
      var f = files[i];
      var filePath = f.path || f.name;
      var name = f.name || path.basename(filePath);
      var ext  = path.extname(name).toLowerCase();
      var type = assetTypeFromExt(ext);
      // Skip duplicates by name
      var exists = state.assets.some(function (a) { return a.name === name; });
      if (!exists) {
        state.assets.push({ path: filePath, name: name, type: type });
      }
    }
    renderAssetsList();
    // Auto-open Advanced panel so dropped assets are visible
    if (!optionsPanel.classList.contains('open')) {
      optionsToggle.classList.add('open');
      optionsPanel.classList.add('open');
    }
  }

  function renderAssetsList() {
    assetsList.innerHTML = '';
    state.assets.forEach(function (asset, idx) {
      var item = document.createElement('div');
      item.className = 'asset-item';

      var nameEl = document.createElement('div');
      nameEl.className = 'asset-item-name';
      nameEl.textContent = asset.name;
      nameEl.title = asset.path;
      item.appendChild(nameEl);

      var badge = document.createElement('span');
      badge.className = 'asset-type-badge ' + asset.type;
      badge.textContent = asset.type;
      item.appendChild(badge);

      var removeBtn = document.createElement('button');
      removeBtn.className = 'asset-remove-btn';
      removeBtn.innerHTML = '&#x2715;';
      removeBtn.title = 'Remove';
      removeBtn.addEventListener('click', function () {
        state.assets.splice(idx, 1);
        renderAssetsList();
      });
      item.appendChild(removeBtn);

      assetsList.appendChild(item);
    });
  }

  // ── Render timer ──────────────────────────────────────────────────────────
  var renderStart = null;
  var stopwatchInterval = null;

  function startTimer() {
    renderStart = Date.now();
    renderTimeEl.classList.remove('visible');
    progressStopwatch.textContent = '0:00';
    if (stopwatchInterval) clearInterval(stopwatchInterval);
    stopwatchInterval = setInterval(function () {
      var elapsed = Math.floor((Date.now() - renderStart) / 1000);
      var m = Math.floor(elapsed / 60);
      var s = elapsed % 60;
      progressStopwatch.textContent = m + ':' + (s < 10 ? '0' : '') + s;
    }, 1000);
  }

  function stopTimer() {
    if (stopwatchInterval) { clearInterval(stopwatchInterval); stopwatchInterval = null; }
    if (!renderStart) return;
    var elapsed = Math.round((Date.now() - renderStart) / 1000);
    state.lastRenderTimeSec = elapsed;
    var m = Math.floor(elapsed / 60);
    var s = elapsed % 60;
    renderTimeText.textContent = m + ':' + (s < 10 ? '0' : '') + s;
    renderTimeEl.classList.add('visible');
    renderStart = null;
  }

  // ── Run orchestrator ──────────────────────────────────────────────────────
  function runAbstractor(imagePath, textContent, modeOverrideArg, layoutOverrideArg) {
    state.isRunning = true;
    state.lastModel = '';
    state.lastRenderTimeSec = 0;
    state.detectedLayout = null;
    if (progressModelChip) { progressModelChip.textContent = ''; progressModelChip.classList.remove('visible'); }
    updateAbstractBtn();

    var slideNum = (state.activeSlideIndex)
      ? String(state.activeSlideIndex).padStart(2, '0')
      : '00';

    var remotionDir  = path.join(extPath, 'remotion');
    var bridgeScript = path.join(extPath, 'scripts', 'abstractor-bridge.js');

    clearLog();
    showProgress(0, 'Starting…');
    setStatus('', 'info');
    startTimer();

    getEffectiveOutputFolder(function (outputFolder) {
      var serial        = nextSerial(outputFolder);
      var customName    = nameInput ? sanitizeName(nameInput.value) : '';
      var outputBase    = customName
        ? customName + '_Abstractor_' + serial
        : 'Slide_' + slideNum + '_Abstractor_' + serial;
      var outputPath    = path.join(outputFolder, outputBase + '.mov');
      var autoTitle     = ''; // filled by { title: ... } stderr event from bridge

      var args = [
        bridgeScript,
        '--text',     textContent,
        '--output',   outputPath,
        '--remotion', remotionDir
      ];
      if (imagePath) {
        args.push('--image', imagePath);
      }
      if (state.assets.length > 0) {
        var assetsFilePath = path.join(os.tmpdir(), 'abstractor_assets_' + Date.now() + '.json');
        fs.writeFileSync(assetsFilePath, JSON.stringify(state.assets));
        args.push('--assets-file', assetsFilePath);
      }
      if (noTextCb.checked)    args.push('--no-text', '1');
      if (quality4kCb.checked) args.push('--quality-4k', '1');
      var effectiveModeOverride   = (modeOverrideArg   !== undefined) ? modeOverrideArg   : state.modeOverride;
      var effectiveLayoutOverride = (layoutOverrideArg !== undefined) ? layoutOverrideArg : state.layoutOverride;
      if (effectiveModeOverride)   args.push('--render-mode',     effectiveModeOverride);
      if (effectiveLayoutOverride) args.push('--layout-override', effectiveLayoutOverride);
      args.push('--primary-color', state.primaryColor);
      if (state.secondaryColor) args.push('--secondary-color', state.secondaryColor);
      if (state.bgColor) args.push('--bg-color', state.bgColor);
      args.push('--model', getSelectedModelId());
      var lengthSec = parseInt(lengthInput.value, 10);
      if (lengthSec >= 1 && lengthSec <= 60) args.push('--length', String(lengthSec));
      if (effectiveModeOverride === 'creative') {
        var cb = state.creativeBrief;
        if (cb.archetype || cb.mood || cb.motion || cb.directorNote) {
          args.push('--creative-brief', JSON.stringify({
            archetype:    cb.archetype    || null,
            mood:         cb.mood         || null,
            motion:       cb.motion       || null,
            directorNote: cb.directorNote || ''
          }));
        }
      }

      var childEnv = Object.assign({}, process.env, { PATH: CHILD_PATH });
      appendLog('node: ' + NODE_BIN, '');
      appendLog('bridge: ' + bridgeScript, '');
      appendLog('output: ' + outputPath, '');

      var child = spawn(NODE_BIN, args, { env: childEnv });
      state.childProcess = child;

      child.stdout.on('data', function (data) {
        appendLog(data.toString(), 'ok');
      });

      child.stderr.on('data', function (data) {
        data.toString().split('\n').forEach(function (line) {
          line = line.trim();
          if (!line) return;
          try {
            var evt = JSON.parse(line);
            if (typeof evt.progress === 'number') showProgress(evt.progress, evt.message || '');
            if (evt.log) appendLog(evt.log, evt.type || '');
            if (evt.title && !customName) autoTitle = evt.title; // only use if user didn't provide a name
            if (evt.model) {
              state.lastModel = evt.model;
              if (progressModelChip) { progressModelChip.textContent = shortenModelName(evt.model); progressModelChip.classList.add('visible'); }
            }
            if (evt.layout) {
              state.detectedLayout = evt.layout;
            }
          } catch (e) {
            appendLog(line, '');
          }
        });
      });

      child.on('close', function (code) {
        state.isRunning = false;
        state.childProcess = null;
        updateAbstractBtn();
        stopTimer();
        hideProgress();
        dismissWireframePicker();

        // "Change Layout" was clicked — restart with new layout
        if (state.pendingLayoutChange) {
          var pending = state.pendingLayoutChange;
          state.pendingLayoutChange = null;
          runAbstractor(state.lastImagePath, state.lastText, pending.mode, pending.layout);
          return;
        }

        if (code === 0) {
          setStatus('Importing into After Effects…', 'info');
          var thumbToMark = state.activeSlideThumb;
          state.activeSlideThumb = null;

          // ── Rename file if auto-title received from bridge ─────────────────
          var finalOutputPath = outputPath;
          var finalOutputBase = outputBase;
          if (autoTitle && !customName) {
            var slidePrefix = state.activeSlideIndex ? 'Slide_' + slideNum + '_' : '';
            var titledBase = slidePrefix + autoTitle + '_Abstractor_' + serial;
            var titledPath = path.join(outputFolder, titledBase + '.mov');
            try {
              fs.renameSync(outputPath, titledPath);
              finalOutputPath = titledPath;
              finalOutputBase = titledBase;
              // Rename TSX snapshot to match
              var origTsx = outputPath.replace(/\.mov$/i, '.tsx');
              var titledTsx = path.join(outputFolder, titledBase + '.tsx');
              if (fs.existsSync(origTsx)) fs.renameSync(origTsx, titledTsx);
            } catch (renameErr) {
              appendLog('Rename failed, keeping serial name: ' + renameErr.message, '');
            }
          }
          if (nameInput) nameInput.value = ''; // clear name field after use

          var escapedPath = finalOutputPath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
          var escapedName = finalOutputBase.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
          cs.evalScript('importToAE("' + escapedPath + '","' + escapedName + '")', function (result) {
            if (!result || result.indexOf('error') === 0) {
              setStatus((result || 'AE import failed — is After Effects open?'), 'error');
            } else {
              var noComp = result.indexOf('ok-no-comp:') === 0;
              // Extract folder path (before optional |compName suffix)
              var payload = result.replace(/^ok(-no-comp)?:/, '');
              var pipeIdx = payload.indexOf('|');
              var folderPart = pipeIdx >= 0 ? payload.slice(0, pipeIdx) : payload;
              var compPart   = pipeIdx >= 0 ? payload.slice(pipeIdx + 1) : '';
              state.lastRendersFolder = folderPart || outputFolder;
              var statusMsg = noComp
                ? 'Rendered! No open comp found — footage was added to your Project panel.'
                : ('Done! Added to comp' + (compPart ? ' "' + compPart + '"' : '') + ' — ' + finalOutputBase + '.mov');
              setStatus(statusMsg, noComp ? 'warn' : 'success');
              state.lastCompPath   = path.join(extPath, 'remotion', 'src', 'generated', 'AbstractorComp.tsx');
              state.lastOutputBase = finalOutputBase;
              state.lastSlideNum   = slideNum;
              fixRow.classList.remove('visible');
              fixRow.classList.remove('fix-complete');
              void fixRow.offsetWidth;
              fixRow.classList.add('visible');
              fixTextarea.value = '';
              fixBtn.disabled = true;
              if (thumbToMark) {
                thumbToMark.classList.add('done');
                state.doneSlidePaths[thumbToMark.dataset.path] = true;
              }
              // ── Save render to history ─────────────────────────────────────
              var histId = historyManager.addEntry({
                prompt:       textContent,
                outputPath:   finalOutputPath,
                outputName:   finalOutputBase + '.mov',
                compPath:     finalOutputPath.replace(/\.mov$/i, '.tsx'),
                imagePath:    imagePath || '',
                primaryColor: state.primaryColor,
                accentColor:  state.secondaryColor || '',
                bgColor:      state.bgColor || '',
                clipSec:      lengthSec >= 1 ? lengthSec : 15,
                renderTimeSec: state.lastRenderTimeSec || 0,
                model:        state.lastModel || '',
              });
              state.lastHistoryId = histId;
              historyManager.extractThumbnail(histId, finalOutputPath, path.join(extPath, 'remotion'), function (thumbPath) {
                if (thumbPath) historyManager.setThumbnailPath(histId, thumbPath);
                renderHistorySection();
              });
              renderHistorySection();
            }
          });
        } else if (code === 6) {
          setStatus('Claude API error — wait a moment and try again.', 'error');
        } else if (code === 4) {
          setStatus('Claude returned text instead of code. Try rephrasing your prompt.', 'error');
        } else if (code === 5) {
          setStatus('Render crashed (exit 5). Check log above.', 'error');
        } else {
          setStatus('Failed (exit ' + code + '). Check log above.', 'error');
        }
      });

      child.on('error', function (err) {
        state.isRunning = false;
        state.childProcess = null;
        updateAbstractBtn();
        hideProgress();
        setStatus('Could not start Node: ' + err.message, 'error');
      });
    });
  }

  // ── Preview helpers ───────────────────────────────────────────────────────
  function showPreview() { /* preview removed */ }

  // ── Progress helpers ──────────────────────────────────────────────────────
  function showProgress(fraction, msg) {
    var wasHidden = !progressWrap.classList.contains('visible');
    progressWrap.classList.add('visible');
    document.body.classList.add('rendering');
    progressFill.style.width = Math.round(fraction * 100) + '%';
    if (msg) progressMessage.textContent = msg;
    if (wasHidden) PixelArt.start();
  }

  function hideProgress() {
    PixelArt.stop();
    progressWrap.classList.remove('visible');
    document.body.classList.remove('rendering');
    progressFill.style.width = '0%';
  }

  // ── Status helpers ────────────────────────────────────────────────────────
  function setStatus(msg, type) {
    statusLine.textContent = msg;
    statusLine.className   = type || 'info';
  }

  // ── Log helpers ───────────────────────────────────────────────────────────
  function appendLog(text, cls) {
    var line = document.createElement('div');
    line.className = 'log-line' + (cls ? ' ' + cls : '');
    line.textContent = text;
    logContent.appendChild(line);
    logContent.scrollTop = logContent.scrollHeight;
    if (!logToggle.classList.contains('open')) {
      logToggle.classList.add('open');
      logContent.classList.add('open');
    }
  }

  function clearLog() {
    logContent.innerHTML = '';
  }

  // ── Render history ────────────────────────────────────────────────────────
  function shortenModelName(m) {
    return m.replace(/^claude-/, '').replace(/-(\d+)-(\d+)$/, ' $1.$2');
  }

  function renderHistorySection() {
    var data = historyManager.load();
    var entries = data.entries || [];
    historyList.innerHTML = '';

    if (!entries.length) {
      var empty = document.createElement('div');
      empty.className = 'history-empty';
      empty.textContent = 'No renders yet';
      historyList.appendChild(empty);
      return;
    }

    entries.forEach(function (entry) {
      var card = document.createElement('div');
      card.className = 'history-card';

      // Thumbnail: try (1) extracted video frame, (2) source slide image, (3) "PROMPT" label
      var thumbOk = false;
      if (entry.thumbnailPath && fs.existsSync(entry.thumbnailPath)) {
        try {
          var thumbData = fs.readFileSync(entry.thumbnailPath);
          var img = document.createElement('img');
          img.className = 'history-thumb';
          img.src = 'data:image/jpeg;base64,' + thumbData.toString('base64');
          img.alt = '';
          card.appendChild(img);
          thumbOk = true;
        } catch (e) {}
      }
      if (!thumbOk && entry.imagePath && fs.existsSync(entry.imagePath)) {
        try {
          var srcData = fs.readFileSync(entry.imagePath);
          var srcExt = path.extname(entry.imagePath).toLowerCase();
          var srcMime = (srcExt === '.jpg' || srcExt === '.jpeg') ? 'image/jpeg' : 'image/png';
          var srcImg = document.createElement('img');
          srcImg.className = 'history-thumb';
          srcImg.src = 'data:' + srcMime + ';base64,' + srcData.toString('base64');
          srcImg.alt = '';
          card.appendChild(srcImg);
          thumbOk = true;
        } catch (e) {}
      }
      if (!thumbOk) {
        var ph = document.createElement('div');
        ph.className = 'history-thumb-placeholder';
        var phLabel = document.createElement('span');
        phLabel.className = 'history-thumb-label';
        phLabel.textContent = 'PROMPT';
        ph.appendChild(phLabel);
        card.appendChild(ph);
      }

      // Info block
      var info = document.createElement('div');
      info.className = 'history-info';

      var name = document.createElement('div');
      name.className = 'history-name';
      name.title = entry.outputName || '';
      name.textContent = entry.outputName || 'Render';
      info.appendChild(name);

      var prompt = document.createElement('div');
      prompt.className = 'history-prompt';
      var promptText = (entry.prompt || '').replace(/\n/g, ' ').slice(0, 120);
      prompt.title = entry.prompt || '';
      prompt.textContent = promptText;
      info.appendChild(prompt);

      var meta = document.createElement('div');
      meta.className = 'history-meta';
      var d = new Date(entry.timestamp);
      var dateStr = d.getMonth() + 1 + '/' + d.getDate() + '/' + d.getFullYear().toString().slice(-2) +
                    ' ' + d.getHours() + ':' + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
      var fixCount = (entry.fixes && entry.fixes.length) ? ' · ' + entry.fixes.length + ' fix' + (entry.fixes.length > 1 ? 'es' : '') : '';
      var renderTimeStr = '';
      if (entry.renderTimeSec > 0) {
        var rm = Math.floor(entry.renderTimeSec / 60), rs = entry.renderTimeSec % 60;
        renderTimeStr = ' · ' + rm + ':' + (rs < 10 ? '0' : '') + rs;
      } else if (entry.durationSec) {
        renderTimeStr = ' · ' + entry.durationSec + 's clip';
      }
      meta.textContent = dateStr + renderTimeStr + fixCount;
      if (entry.model) {
        var modelChip = document.createElement('span');
        modelChip.className = 'model-chip';
        modelChip.textContent = shortenModelName(entry.model);
        meta.appendChild(modelChip);
      }
      info.appendChild(meta);

      card.appendChild(info);

      // Actions
      var actions = document.createElement('div');
      actions.className = 'history-actions';

      // Like / Dislike
      var rating = document.createElement('div');
      rating.className = 'history-rating';

      var likeBtn = document.createElement('button');
      likeBtn.className = 'history-like-btn' + (entry.rating === 'like' ? ' active' : '');
      likeBtn.title = 'Like';
      likeBtn.innerHTML = '&#x1F44D;';
      likeBtn.addEventListener('click', function () {
        historyManager.setRating(entry.id, 'like');
        renderHistorySection();
      });

      var dislikeBtn = document.createElement('button');
      dislikeBtn.className = 'history-dislike-btn' + (entry.rating === 'dislike' ? ' active' : '');
      dislikeBtn.title = 'Dislike';
      dislikeBtn.innerHTML = '&#x1F44E;';
      dislikeBtn.addEventListener('click', function () {
        historyManager.setRating(entry.id, 'dislike');
        renderHistorySection();
      });

      rating.appendChild(likeBtn);
      rating.appendChild(dislikeBtn);
      actions.appendChild(rating);

      // Open folder
      if (entry.outputPath) {
        var folderBtn = document.createElement('button');
        folderBtn.className = 'history-folder-btn';
        folderBtn.title = 'Open output folder';
        folderBtn.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>';
        (function (outPath) {
          folderBtn.addEventListener('click', function () {
            var dir = path.dirname(outPath).replace(/"/g, '\\"');
            var cmd = process.platform === 'win32' ? 'explorer "' + dir + '"' : 'open "' + dir + '"';
            exec(cmd);
          });
        }(entry.outputPath));
        actions.appendChild(folderBtn);
      }

      // Use again
      var useBtn = document.createElement('button');
      useBtn.className = 'history-use-btn';
      useBtn.title = 'Load this prompt';
      useBtn.textContent = 'Use again';
      (function (e) {
        useBtn.addEventListener('click', function () {
          if (contentTextarea) contentTextarea.value = e.prompt || '';
          if (e.primaryColor) {
            state.primaryColor = e.primaryColor;
            colorSwatches.forEach(function (s) {
              s.classList.toggle('active', s.dataset.color === e.primaryColor);
            });
          }
          if (e.bgColor !== undefined) {
            state.bgColor = e.bgColor;
            bgSwatches.forEach(function (s) {
              s.classList.toggle('bg-swatch--selected', s.dataset.color === e.bgColor);
            });
          }
          if (e.durationSec && lengthInput) lengthInput.value = e.durationSec;
          // Scroll to top
          document.getElementById('main').scrollTop = 0;
        });
      }(entry));

      actions.appendChild(useBtn);

      // Fix from history
      var hasSnapshot = !!(entry.compPath && fs.existsSync(entry.compPath));
      var histFixBtn = document.createElement('button');
      histFixBtn.className = 'history-fix-btn' + (hasSnapshot ? '' : ' disabled');
      histFixBtn.title = hasSnapshot ? 'Fix this render' : 'No snapshot (rendered before history fix was added)';
      histFixBtn.textContent = 'Fix';
      if (hasSnapshot) {
        (function (e) {
          histFixBtn.addEventListener('click', function () {
            var destComp = path.join(extPath, 'remotion', 'src', 'generated', 'AbstractorComp.tsx');
            try {
              fs.copyFileSync(e.compPath, destComp);
            } catch (err) {
              setStatus('Could not restore snapshot: ' + err.message, 'error');
              return;
            }
            var slideMatch = (e.outputName || '').match(/Slide_(\d+)_/);
            state.lastCompPath  = destComp;
            state.lastHistoryId = e.id;
            state.lastSlideNum  = slideMatch ? slideMatch[1] : '00';
            fixRow.classList.add('visible');
            fixTextarea.value = '';
            fixBtn.disabled = true;
            fixRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
          });
        }(entry));
      }
      actions.appendChild(histFixBtn);

      card.appendChild(actions);

      historyList.appendChild(card);
    });
  }

  // History accordion toggle
  historyToggle.addEventListener('click', function () {
    historyToggle.classList.toggle('open');
    historyPanel.classList.toggle('open');
    if (historyPanel.classList.contains('open')) renderHistorySection();
  });

  // Initial render (in case panel was open from before)
  renderHistorySection();

  // ── Model picker ──────────────────────────────────────────────────────────
  var MODEL_IDS = {
    opus:   'claude-opus-4-7',
    sonnet: 'claude-sonnet-4-6',
    haiku:  'claude-haiku-4-5',
  };
  var MODEL_HINTS = {
    opus:   'Highest quality · slowest · best for finals',
    sonnet: 'Balanced · fast iteration, strong results',
    haiku:  'Fastest · quick drafts & simple layouts',
  };
  function getSelectedModelId() {
    return MODEL_IDS[modelSelect.value] || modelSelect.value;
  }
  function updateModelHint() {
    if (modelHint) modelHint.textContent = MODEL_HINTS[modelSelect.value] || '';
  }
  modelSelect.addEventListener('change', updateModelHint);
  updateModelHint();

  // ── Update Panel ──────────────────────────────────────────────────────────
  var updDropZone      = document.getElementById('updDropZone');
  var updFileInput     = document.getElementById('updFileInput');
  var updDropLabel     = document.getElementById('updDropLabel');
  var updStatus        = document.getElementById('updStatus');
  var installUpdateBtn = document.getElementById('installUpdateBtn');
  var reloadPanelBtn   = document.getElementById('reloadPanelBtn');
  var _updZipPath      = null;

  function updSetFile(filePath) {
    _updZipPath = filePath;
    var name = filePath ? filePath.split(/[\\/]/).pop() : '';
    updDropLabel.textContent = name || 'Drop .zip here or click to browse';
    updDropZone.classList.toggle('has-file', !!filePath);
    updStatus.textContent = '';
    updStatus.style.color = 'var(--text-muted)';
    installUpdateBtn.disabled = !filePath;
    reloadPanelBtn.style.display = 'none';
  }

  updDropZone.addEventListener('click', function () { updFileInput.click(); });

  updFileInput.addEventListener('change', function () {
    var f = this.files && this.files[0];
    if (f && f.name.toLowerCase().endsWith('.zip')) {
      updSetFile(f.path);
    } else if (f) {
      updStatus.textContent = 'Please select a .zip file.';
      updStatus.style.color = 'var(--danger)';
    }
  });

  updDropZone.addEventListener('dragover', function (e) {
    e.preventDefault();
    updDropZone.classList.add('drag-over');
  });
  updDropZone.addEventListener('dragleave', function () {
    updDropZone.classList.remove('drag-over');
  });
  updDropZone.addEventListener('drop', function (e) {
    e.preventDefault();
    updDropZone.classList.remove('drag-over');
    var f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (f && f.name.toLowerCase().endsWith('.zip')) {
      updSetFile(f.path);
    } else {
      updStatus.textContent = 'Please drop a .zip file.';
      updStatus.style.color = 'var(--danger)';
    }
  });

  installUpdateBtn.addEventListener('click', function () {
    if (!_updZipPath) return;
    var extRoot = cs.getSystemPath(SystemPath.EXTENSION);
    updStatus.textContent = 'Installing…';
    updStatus.style.color = 'var(--text-muted)';
    installUpdateBtn.disabled = true;
    var cmd;
    if (process.platform === 'win32') {
      // Try Expand-Archive (PS 5+, Win10+); fall back to Shell.Application COM (all Windows)
      var zipPS  = _updZipPath.replace(/\\/g, '\\\\').replace(/'/g, "''");
      var extPS  = extRoot.replace(/\\/g, '\\\\').replace(/'/g, "''");
      cmd = "powershell -NoProfile -Command \""
          + "if ($PSVersionTable.PSVersion.Major -ge 5) {"
          + "  Expand-Archive -Force -Path '" + zipPS + "' -DestinationPath '" + extPS + "'"
          + "} else {"
          + "  $sh = New-Object -ComObject Shell.Application;"
          + "  $zip = $sh.NameSpace('" + zipPS + "');"
          + "  $dst = $sh.NameSpace('" + extPS + "');"
          + "  $dst.CopyHere($zip.Items(), 0x14)"
          + "}\"";
    } else {
      cmd = 'unzip -o ' + JSON.stringify(_updZipPath) + ' -d ' + JSON.stringify(extRoot);
    }
    exec(cmd, { env: Object.assign({}, process.env, { PATH: CHILD_PATH }) }, function (err, stdout, stderr) {
      // Auto-update path sets data-installing on the auto button to prevent
      // the state machine from clobbering "Installing v…" while the unzip runs.
      // Clear it here so subsequent checks can repaint the button.
      var updAutoBtnEl = document.getElementById('updAutoBtn');
      if (updAutoBtnEl) delete updAutoBtnEl.dataset.installing;
      var ver = (updateBanner && updateBanner.dataset.version) || '';
      if (err) {
        updStatus.textContent = 'Error: ' + (stderr || err.message || String(err));
        updStatus.style.color = 'var(--danger)';
        installUpdateBtn.disabled = false;
        if (updAutoBtnEl) {
          updAutoBtnEl.disabled = false;
          updAutoBtnEl.textContent = ver ? 'Update to v' + ver : 'Try again';
        }
      } else {
        var verSuffix = ver ? ' (v' + ver + ')' : '';
        updStatus.textContent = 'Installed' + verSuffix + '! Reload the panel to apply.';
        updStatus.style.color = 'var(--accent)';
        reloadPanelBtn.style.display = 'block';
        if (updAutoBtnEl) {
          updAutoBtnEl.disabled = true;
          updAutoBtnEl.textContent = ver ? 'Installed v' + ver : 'Installed';
        }
      }
    });
  });

  reloadPanelBtn.addEventListener('click', function () { window.location.reload(); });

  // ── Auto-update check (boot + every 30 min) ───────────────────────────────
  // Multi-host fallback chain — corporate networks (especially Windows) sometimes
  // block one CDN via SmartScreen / proxy / AV. We try each in order; first one
  // that returns valid JSON wins. Order:
  //   1. raw.githubusercontent.com — canonical, always fresh
  //   2. cdn.jsdelivr.net          — widely allowlisted CDN (may briefly cache)
  //   3. api.github.com/contents   — REST API; always fresh, no CDN cache,
  //                                  returns base64-encoded content (we decode)
  var ABSTRACTOR_LATEST_URLS = [
    'https://raw.githubusercontent.com/amitnvda/abstractor-releases/main/latest.json',
    'https://cdn.jsdelivr.net/gh/amitnvda/abstractor-releases@main/latest.json',
    'https://api.github.com/repos/amitnvda/abstractor-releases/contents/latest.json?ref=main'
  ];
  var ABSTRACTOR_DISMISS_KEY = 'abstractor_update_dismissed';
  var ABSTRACTOR_VERSION = (function () {
    try {
      var manifestPath = path.join(cs.getSystemPath(SystemPath.EXTENSION), 'CSXS', 'manifest.xml');
      var xml = fs.readFileSync(manifestPath, 'utf8');
      var m = xml.match(/ExtensionBundleVersion="([^"]+)"/);
      return m ? m[1] : '0.0.0';
    } catch (_) { return '0.0.0'; }
  })();

  var updateBanner          = document.getElementById('updateBanner');
  var updateBannerVersion   = document.getElementById('updateBannerVersion');
  var updateBannerBtn       = document.getElementById('updateBannerBtn');
  var updateBannerDismiss   = document.getElementById('updateBannerDismiss');
  var updAutoBox            = document.getElementById('updAutoBox');
  var updAutoVersion        = document.getElementById('updAutoVersion');
  var updAutoBtn            = document.getElementById('updAutoBtn');

  function _verCmp(a, b) {
    var pa = String(a).split('.').map(function (n) { return parseInt(n, 10) || 0; });
    var pb = String(b).split('.').map(function (n) { return parseInt(n, 10) || 0; });
    for (var i = 0; i < 3; i++) {
      if ((pa[i] || 0) > (pb[i] || 0)) return 1;
      if ((pa[i] || 0) < (pb[i] || 0)) return -1;
    }
    return 0;
  }

  // Tries each manifest URL in order; resolves with { data, host } on first success
  // or { error } if every host fails. Logs every attempt to console for diagnostics.
  // The GitHub Contents API URL is special-cased: response is base64-encoded inside
  // a JSON envelope, so we decode it before returning.
  function _fetchLatestJson() {
    var cacheBust = '?t=' + Date.now() + '-' + Math.random().toString(36).slice(2);
    return ABSTRACTOR_LATEST_URLS.reduce(function (promise, baseUrl) {
      return promise.then(function (prev) {
        if (prev && prev.data) return prev; // already succeeded — short-circuit
        var isGitHubApi = /^https:\/\/api\.github\.com\//.test(baseUrl);
        var url = isGitHubApi ? baseUrl : (baseUrl + (baseUrl.indexOf('?') >= 0 ? '&' : '?') + cacheBust.slice(1));
        var hostMatch = baseUrl.match(/^https?:\/\/([^/]+)/);
        var host = hostMatch ? hostMatch[1] : baseUrl;
        var headers = { 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache' };
        if (isGitHubApi) headers['Accept'] = 'application/vnd.github.v3+json';
        return fetch(url, { cache: 'no-store', headers: headers }).then(function (res) {
          if (!res.ok) {
            var err = host + ' → HTTP ' + res.status;
            console.warn('[Abstractor] manifest fetch failed:', err);
            return { error: err };
          }
          if (isGitHubApi) {
            return res.json().then(function (envelope) {
              if (!envelope || envelope.encoding !== 'base64' || !envelope.content) {
                var err = host + ' → unexpected API response shape';
                console.warn('[Abstractor] manifest fetch failed:', err);
                return { error: err };
              }
              try {
                var json = atob(envelope.content.replace(/\s/g, ''));
                var data = JSON.parse(json);
                console.log('[Abstractor] manifest fetched from ' + host + ' → v' + (data && data.version));
                return { data: data, host: host };
              } catch (e) {
                var err2 = host + ' → ' + (e && e.message ? e.message : String(e));
                console.warn('[Abstractor] manifest fetch failed:', err2);
                return { error: err2 };
              }
            });
          }
          return res.json().then(function (data) {
            console.log('[Abstractor] manifest fetched from ' + host + ' → v' + (data && data.version));
            return { data: data, host: host };
          }, function (e) {
            var err = host + ' → ' + (e && e.message ? e.message : 'invalid JSON');
            console.warn('[Abstractor] manifest fetch failed:', err);
            return { error: err };
          });
        }, function (e) {
          var err = host + ' → ' + (e && e.message ? e.message : String(e));
          console.warn('[Abstractor] manifest fetch failed:', err);
          return { error: err };
        });
      });
    }, Promise.resolve(null)).then(function (final) {
      return final && final.data ? final : { error: (final && final.error) || 'all manifest hosts unreachable' };
    });
  }

  // Paint the "Update Now" auto-update button to match current state. Skips
  // the paint while an install is in flight (data-installing flag set) so the
  // state machine never clobbers the "Installing v…" label.
  function _setAutoBtnState(state, version) {
    if (!updAutoBtn) return;
    if (updAutoBtn.dataset.installing === '1') return;
    switch (state) {
      case 'available':
        updAutoBtn.disabled = false;
        updAutoBtn.textContent = 'Update to v' + version;
        if (updAutoVersion) updAutoVersion.textContent = 'v' + version;
        if (updAutoBox) updAutoBox.style.display = 'flex';
        break;
      case 'uptodate':
        updAutoBtn.disabled = true;
        updAutoBtn.textContent = 'Up to date (v' + version + ')';
        if (updAutoVersion) updAutoVersion.textContent = 'v' + version;
        if (updAutoBox) updAutoBox.style.display = 'flex';
        break;
      case 'unreachable':
        updAutoBtn.disabled = true;
        updAutoBtn.textContent = 'Update server unreachable';
        if (updAutoBox) updAutoBox.style.display = 'flex';
        break;
      case 'checking':
        updAutoBtn.disabled = true;
        updAutoBtn.textContent = 'Checking…';
        if (updAutoBox) updAutoBox.style.display = 'flex';
        break;
    }
  }

  // checkForUpdate(opts) — set opts.manual=true for user-triggered checks so
  // a visible result is surfaced (success / no-update / error) rather than
  // failing silently.
  function checkForUpdate(opts) {
    var manual = !!(opts && opts.manual);
    return _fetchLatestJson().then(function (result) {
      if (!result || result.error || !result.data || !result.data.version) {
        var msg = (result && result.error) || 'manifest missing version field';
        console.warn('[Abstractor] update check failed:', msg);
        if (manual && updStatus) {
          updStatus.textContent = "Couldn't reach update server (" + msg + "). Use the drop-zone below.";
          updStatus.style.color = 'var(--danger)';
        }
        _setAutoBtnState('unreachable');
        return;
      }
      var data = result.data;
      var remote = String(data.version).trim();
      if (_verCmp(remote, ABSTRACTOR_VERSION) <= 0) {
        if (manual && updStatus) {
          updStatus.textContent = "You're up to date — running v" + ABSTRACTOR_VERSION + ".";
          updStatus.style.color = 'var(--text-muted)';
        }
        _setAutoBtnState('uptodate', ABSTRACTOR_VERSION);
        return;
      }
      // Manual checks override the dismiss flag — the user explicitly asked.
      if (!manual && localStorage.getItem(ABSTRACTOR_DISMISS_KEY) === remote) {
        // Reflect the available update on the install button anyway so it
        // stays actionable from the gear icon even if the top banner is dismissed.
        _setAutoBtnState('available', remote);
        if (updAutoBox) updAutoBox.dataset.updateUrl = data.updateUrl || '';
        return;
      }
      if (!updateBanner) return;
      updateBannerVersion.textContent = 'v' + remote;
      updateBanner.dataset.version = remote;
      updateBanner.dataset.updateUrl = data.updateUrl || '';
      updateBannerBtn.disabled = false;
      updateBannerBtn.textContent = 'Update';
      updateBanner.classList.add('show');
      if (updAutoBox) updAutoBox.dataset.updateUrl = data.updateUrl || '';
      _setAutoBtnState('available', remote);
      console.log('[Abstractor] Update available: v' + remote + ' (installed v' + ABSTRACTOR_VERSION + ')');
      if (manual && updStatus) {
        updStatus.textContent = 'Update v' + remote + ' available — banner shown at top.';
        updStatus.style.color = 'var(--accent)';
      }
    });
  }

  // Banner: Update button → opens the existing update overlay
  if (updateBannerBtn) {
    updateBannerBtn.addEventListener('click', function () {
      updateOverlay.classList.add('visible');
      updateBanner.classList.remove('show');
    });
  }

  // Banner: Dismiss button → suppress this version until a newer one ships
  if (updateBannerDismiss) {
    updateBannerDismiss.addEventListener('click', function () {
      var v = updateBanner.dataset.version;
      if (v) localStorage.setItem(ABSTRACTOR_DISMISS_KEY, v);
      updateBanner.classList.remove('show');
    });
  }

  // Multi-host zip fetch — same idea as the manifest. If the manifest's
  // updateUrl points at raw.githubusercontent.com we try jsDelivr as a backup.
  // (Versioned zips are immutable, so jsDelivr's cache is fine for them.)
  function _zipUrlCandidates(updateUrl) {
    if (!updateUrl) return [];
    var m = updateUrl.match(/^https?:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/);
    if (!m) return [updateUrl];
    return [
      updateUrl,
      'https://cdn.jsdelivr.net/gh/' + m[1] + '/' + m[2] + '@' + m[3] + '/' + m[4]
    ];
  }

  // Auto-update button (inside overlay) → fetch ZIP from URL → install in-place
  if (updAutoBtn) {
    updAutoBtn.addEventListener('click', function () {
      if (updAutoBtn.disabled) return;
      var url = (updateBanner && updateBanner.dataset.updateUrl) ||
                (updAutoBox && updAutoBox.dataset.updateUrl) || '';
      var ver = (updateBanner && updateBanner.dataset.version) || '';
      if (!url) {
        updStatus.textContent = "You're already on the latest version (v" + ABSTRACTOR_VERSION + ").";
        updStatus.style.color = 'var(--text-muted)';
        return;
      }
      updAutoBtn.dataset.installing = '1';
      updAutoBtn.disabled = true;
      var verLabel = ver ? 'v' + ver : 'update';
      updAutoBtn.textContent = ver ? 'Installing v' + ver + '…' : 'Installing…';
      updStatus.textContent = 'Downloading ' + verLabel + '…';
      updStatus.style.color = 'var(--text-muted)';

      var tmpZip = path.join(os.tmpdir(), 'abstractor_update_' + Date.now() + '.zip');
      var candidates = _zipUrlCandidates(url);
      var lastErr = '';
      var chain = Promise.resolve(null);
      candidates.forEach(function (candidateUrl) {
        chain = chain.then(function (buf) {
          if (buf) return buf;
          var hostMatch = candidateUrl.match(/^https?:\/\/([^/]+)/);
          var host = hostMatch ? hostMatch[1] : candidateUrl;
          return fetch(candidateUrl, { cache: 'no-store' }).then(function (res) {
            if (!res.ok) {
              lastErr = host + ' → HTTP ' + res.status;
              console.warn('[Abstractor] zip fetch failed:', lastErr);
              return null;
            }
            return res.arrayBuffer().then(function (ab) {
              var b = Buffer.from(ab);
              console.log('[Abstractor] zip downloaded from ' + host + ' (' + b.length + ' bytes)');
              return b;
            });
          }, function (e) {
            lastErr = host + ' → ' + (e && e.message ? e.message : String(e));
            console.warn('[Abstractor] zip fetch failed:', lastErr);
            return null;
          });
        });
      });
      chain.then(function (buf) {
        if (!buf) throw new Error(lastErr || 'all mirrors unreachable');
        fs.writeFileSync(tmpZip, Buffer.from(buf));
        // Reuse the existing install flow by setting the path + clicking
        updSetFile(tmpZip);
        updAutoBtn.textContent = ver ? 'Installing v' + ver + '…' : 'Installing…';
        installUpdateBtn.click();
      }).catch(function (e) {
        updStatus.textContent = 'Update to ' + verLabel + ' failed: ' + e.message;
        updStatus.style.color = 'var(--danger)';
        delete updAutoBtn.dataset.installing;
        updAutoBtn.disabled = false;
        updAutoBtn.textContent = ver ? 'Update to v' + ver : 'Try again';
      });
    });
  }

  // Manual "Check for updates" link in the overlay — surfaces visible status
  // (success / up-to-date / network error) so users can self-diagnose.
  var updCheckBtn = document.getElementById('updCheckBtn');
  if (updCheckBtn) {
    updCheckBtn.addEventListener('click', function () {
      updCheckBtn.disabled = true;
      var oldLabel = updCheckBtn.textContent;
      updCheckBtn.textContent = 'Checking…';
      if (updStatus) {
        updStatus.textContent = 'Checking for updates…';
        updStatus.style.color = 'var(--text-muted)';
      }
      _setAutoBtnState('checking');
      checkForUpdate({ manual: true }).then(function () {
        updCheckBtn.disabled = false;
        updCheckBtn.textContent = oldLabel;
      });
    });
  }

  // Diagnostic helper — callable from DevTools console
  window.abstractorDiag = {
    check: checkForUpdate,
    clear: function () { localStorage.removeItem(ABSTRACTOR_DISMISS_KEY); },
    state: function () {
      return {
        installed: ABSTRACTOR_VERSION,
        dismissed: localStorage.getItem(ABSTRACTOR_DISMISS_KEY),
        banner: updateBanner ? updateBanner.classList.contains('show') : 'missing'
      };
    }
  };

  // Boot check after 1.5s, then every 30 minutes while the panel is open
  setTimeout(checkForUpdate, 1500);
  setInterval(checkForUpdate, 30 * 60 * 1000);

  // ── AI Service Status Check ───────────────────────────────────────────────
  var CLAUDE_BIN = (function () {
    var candidates = [
      path.join(os.homedir(), '.local', 'bin', 'claude'),
      '/usr/local/bin/claude',
      '/opt/homebrew/bin/claude',
      '/usr/bin/claude',
      'claude'
    ];
    for (var i = 0; i < candidates.length; i++) {
      try {
        if (candidates[i] !== 'claude' && fs.existsSync(candidates[i])) return candidates[i];
      } catch (e) {}
    }
    return 'claude';
  }());

  var dotClaude    = document.getElementById('dotClaude');
  var dotNode      = document.getElementById('dotNode');
  var aiServiceBar = document.getElementById('aiServiceBar');

  function checkAIStatus() {
    var env = Object.assign({}, process.env, { PATH: CHILD_PATH });
    dotClaude.className = 'ai-service-dot checking';
    dotNode.className   = 'ai-service-dot checking';
    exec(JSON.stringify(CLAUDE_BIN) + ' --version', { env: env, timeout: 6000 }, function (err, stdout) {
      dotClaude.className = err ? 'ai-service-dot err' : 'ai-service-dot ok';
      dotClaude.title     = err ? 'Claude CLI not found' : (stdout || '').trim().split('\n')[0];
    });
    exec('node --version', { env: env, timeout: 4000 }, function (err, stdout) {
      dotNode.className = err ? 'ai-service-dot err' : 'ai-service-dot ok';
      dotNode.title     = err ? 'Node.js not found on PATH' : (stdout || '').trim();
    });
  }

  aiServiceBar.addEventListener('click', checkAIStatus);
  checkAIStatus();

}());
