'use strict';

/**
 * abstractor-bridge.js
 * Node.js orchestrator spawned by the CEP panel.
 * Uses the local `claude` CLI (already authenticated) — no API key needed.
 *
 * Usage:
 *   node abstractor-bridge.js \
 *     --image   /path/to/snapshot.png \
 *     --text    "Describe the concept..." \
 *     --output  /tmp/abstractor_123.mov \
 *     --remotion /path/to/abstractor/remotion
 */

const fs   = require('fs');
const path = require('path');
const os   = require('os');
const { spawn } = require('child_process');
const historyManager = require('./history-manager');

const MAIN_MODEL = 'claude-opus-4-7';
let modelOverride = null; // set in main() from --model arg

// ── Helpers ──────────────────────────────────────────────────────────────────

/** Emit a JSON progress event to stderr (parsed by the CEP panel). */
function progress(fraction, message) {
  process.stderr.write(JSON.stringify({ progress: fraction, message }) + '\n');
}

/** Emit a log line to stderr. */
function log(text, type) {
  process.stderr.write(JSON.stringify({ log: text, type: type || '' }) + '\n');
}

/** Parse --key value CLI args into a plain object. */
function parseArgs(argv) {
  const args = {};
  for (let i = 2; i < argv.length; i += 2) {
    const key = argv[i].replace(/^--/, '');
    args[key] = argv[i + 1];
  }
  return args;
}

/** Return the platform-appropriate bundled Remotion ffmpeg binary path. */
function getCompositorFfmpeg(remotionDir) {
  const plat = process.platform;
  const arch = process.arch;
  let pkg;
  if (plat === 'darwin') {
    pkg = arch === 'arm64' ? 'compositor-darwin-arm64' : 'compositor-darwin-x64';
  } else if (plat === 'win32') {
    pkg = 'compositor-win32-x64-msvc';
  } else {
    pkg = 'compositor-linux-x64-gnu';
  }
  const bin = plat === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';
  return path.join(remotionDir, 'node_modules', '@remotion', pkg, bin);
}

/**
 * Extract the TSX/TS code from an LLM response that may include
 * preamble prose, markdown tables, or multiple fenced blocks.
 *
 * Strategy (in priority order):
 * 1. Find a fenced block that contains Remotion-specific code (DURATION_FRAMES / useCurrentFrame)
 * 2. Find the LAST fenced tsx/ts/js block (the final answer is usually last)
 * 3. Find the first line that is unambiguously TypeScript/JSX code
 */
function extractCode(text) {
  // Collect ALL fenced code blocks
  const fenceRe = /```(?:tsx?|typescript|jsx?|js)?\s*([\s\S]+?)```/gi;
  const blocks = [];
  let m;
  while ((m = fenceRe.exec(text)) !== null) {
    blocks.push(m[1].trim());
  }

  if (blocks.length > 0) {
    // Prefer a block containing Remotion code
    const remotionBlock = blocks.find(
      (b) => b.includes('useCurrentFrame') || b.includes('DURATION_FRAMES') || b.includes('AbsoluteFill')
    );
    if (remotionBlock) return remotionBlock;
    // Fall back to last block (Claude tends to put the final answer last)
    return blocks[blocks.length - 1];
  }

  // No fenced blocks — scan for first unambiguous TS/JSX line
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const t = lines[i].trim();
    if (
      t.startsWith('import ') ||
      t.startsWith('export const DURATION_FRAMES') ||
      t.startsWith('export default') ||
      t.startsWith('export function')
    ) {
      return lines.slice(i).join('\n').trim();
    }
  }
  return text.trim();
}

/** Convert a filename to a safe JS identifier (strip extension, replace non-alphanumeric). */
function safeName(filename) {
  return path.basename(filename, path.extname(filename)).replace(/[^a-zA-Z0-9_]/g, '_');
}

/** Read a skill rule file and return its content (ignore if missing). */
function readRule(rulesDir, filename) {
  const p = path.join(rulesDir, filename);
  try { return fs.readFileSync(p, 'utf8'); } catch (e) { return ''; }
}

/**
 * Call the local `claude` CLI with multimodal input via stream-json.
 * Unsets CLAUDECODE env var to allow nested invocation.
 */
function callClaude(systemPrompt, imageBase64, imageMediaType, userMessage, model) {
  return new Promise((resolve, reject) => {

    // Build the stream-json input message
    const messageContent = [];
    if (imageBase64) {
      messageContent.push({
        type: 'image',
        source: { type: 'base64', media_type: imageMediaType, data: imageBase64 },
      });
    }
    messageContent.push({ type: 'text', text: userMessage });

    const streamJsonInput =
      JSON.stringify({ type: 'user', message: { role: 'user', content: messageContent } }) + '\n';

    const claudeArgs = [
      '--print',
      '--verbose',
      '--effort',              'medium',
      '--disallowedTools',     'Write,Edit,MultiEdit,Bash,Read,Glob,Grep,WebFetch,WebSearch,Agent,Task,NotebookRead,NotebookEdit,TodoRead,TodoWrite',
      '--input-format',        'stream-json',
      '--output-format',       'stream-json',
      '--model',               model || modelOverride || MAIN_MODEL,
      '--no-session-persistence',
    ];

    // Unset CLAUDECODE so nested invocation is allowed
    const childEnv = Object.assign({}, process.env);
    delete childEnv.CLAUDECODE;

    // Extend PATH so claude can be found in user-local bin dirs
    const isWin = process.platform === 'win32';
    const homedir = require('os').homedir();
    if (isWin) {
      const winExtra = [
        homedir + '\\AppData\\Local\\Programs\\claude',
        homedir + '\\AppData\\Roaming\\npm',
        'C:\\Program Files\\nodejs',
      ].join(';');
      childEnv.PATH = winExtra + (childEnv.PATH ? ';' + childEnv.PATH : '');
    } else {
      const extraPaths = [homedir + '/.local/bin', '/usr/local/bin', '/opt/homebrew/bin'].join(':');
      childEnv.PATH = extraPaths + (childEnv.PATH ? ':' + childEnv.PATH : '');
    }

    // Resolve absolute path to claude binary
    const { execFileSync } = require('child_process');
    let claudeBin = 'claude';
    try {
      const whichCmd = isWin ? 'where' : 'which';
      claudeBin = execFileSync(whichCmd, ['claude'], { env: childEnv }).toString().split('\n')[0].trim();
      log('claude binary: ' + claudeBin);
    } catch (e) {
      log('Warning: could not resolve claude path via which, using "claude"');
    }

    // Always pass the system prompt via --system-prompt-file (file-based, all platforms).
    // Why unified: on Windows, --system-prompt as a CLI arg can exceed CreateProcess's
    // 32 767-char command-line limit once the prompt grows past a few KB (ENAMETOOLONG).
    // Earlier we tried to keep --system-prompt on Mac and only file on Windows, but the
    // platform split is a maintenance hazard — every system-prompt edit risks reintroducing
    // a Windows-only bug. File approach has negligible overhead (one ~10 KB write per
    // render) and gives identical behavior on every OS.
    const os2 = require('os');
    const sysFile = path.join(os2.tmpdir(), 'abs_sys_' + Date.now() + '_' + Math.random().toString(36).slice(2) + '.txt');
    fs.writeFileSync(sysFile, systemPrompt, 'utf8');
    let spawnBin = claudeBin;
    let spawnArgs = [...claudeArgs, '--system-prompt-file', sysFile];
    let _sysFile = sysFile; // closed-over for cleanup

    const cleanupSysFile = () => {
      if (_sysFile) { try { fs.unlinkSync(_sysFile); } catch (_) {} _sysFile = null; }
    };

    log('Invoking claude CLI (opus, vision)…');
    log('Args: ' + claudeArgs.slice(0, 6).join(' ') + '…');

    const child = spawn(spawnBin, spawnArgs, {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: childEnv,
      cwd: require('os').tmpdir(),
    });

    let stdout = '';
    let stderr = '';

    child.stdin.write(streamJsonInput);
    child.stdin.end();

    child.stdout.on('data', (d) => { stdout += d.toString(); });
    child.stderr.on('data', (d) => {
      const txt = d.toString().trim();
      if (txt) { stderr += txt + '\n'; log(txt); }
    });

    child.on('close', (code) => {
      cleanupSysFile();
      log(`claude exited with code ${code}. stdout length: ${stdout.length}`);
      if (code === 0) {
        // Parse stream-json output.
        // Claude may use tool calls before answering, so we track:
        //   resultText  — the `result` event's final answer (most reliable)
        //   lastAssistant — text from the LAST assistant message block
        //   deltaText   — accumulated streaming text (may include pre-tool reasoning)
        let deltaText = '';
        let lastAssistantText = '';
        let resultText = '';

        stdout.split('\n').forEach((line) => {
          line = line.trim();
          if (!line) return;
          try {
            const evt = JSON.parse(line);
            // Streaming text deltas (accumulated across all blocks)
            if (evt.type === 'content_block_delta' && evt.delta && evt.delta.type === 'text_delta') {
              deltaText += evt.delta.text;
            }
            // Complete assistant message — overwrite with the latest (post-tool-calls) text
            if (evt.type === 'assistant' && evt.message && Array.isArray(evt.message.content)) {
              const t = evt.message.content.filter((b) => b.type === 'text').map((b) => b.text).join('');
              if (t) lastAssistantText = t;
            }
            // Final result event — the definitive answer text
            if (evt.type === 'result' && evt.result) {
              resultText = evt.result;
            }
          } catch (e) { /* skip non-JSON lines */ }
        });

        // Priority: result event > last assistant message > raw delta accumulation
        const text = (resultText || lastAssistantText || deltaText).trim();

        if (text) {
          log('claude stdout: ' + text.slice(0, 300));
          resolve(text);
        } else {
          reject(new Error(`claude CLI returned no text. stdout: ${stdout.slice(0, 200)}`));
        }
      } else {
        reject(new Error(
          `claude CLI exited with code ${code}. stderr: ${stderr || '(none)'} stdout: ${stdout.slice(0, 3000) || '(none)'}`
        ));
      }
    });

    child.on('error', (e) => {
      cleanupSysFile();
      reject(new Error('Failed to spawn claude: ' + e.message));
    });
  });
}

/** Retry wrapper for callClaude — retries on transient API failures with exponential backoff. */
async function callClaudeWithRetry(systemPrompt, imageBase64, imageMediaType, userMessage, model) {
  const MAX_RETRIES = 3;
  const BACKOFF_MS = [8000, 20000, 45000]; // 8s, 20s, 45s
  let lastErr;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      return await callClaude(systemPrompt, imageBase64, imageMediaType, userMessage, model);
    } catch (e) {
      lastErr = e;
      const msg = e.message || '';
      // Transient conditions worth retrying:
      //  • 529 API overload
      //  • exit code 1 with synthetic stop (mid-stream API interruption, "<synthetic>" model)
      //  • connection/timeout errors
      const is529         = msg.includes('529') || msg.toLowerCase().includes('overload');
      const isSynthetic   = msg.includes('<synthetic>') || msg.includes('"stop_sequence":""');
      const isTransient   = is529 || isSynthetic || msg.includes('ECONNRESET') || msg.includes('ETIMEDOUT');
      if (isTransient && attempt < MAX_RETRIES) {
        const wait = BACKOFF_MS[attempt];
        const reason = is529 ? 'overloaded (529)' : 'interrupted — transient API error';
        log(`Claude API ${reason}. Retry ${attempt + 1}/${MAX_RETRIES} in ${wait / 1000}s…`, 'warn');
        progress(null, `Claude API issue — retrying in ${wait / 1000}s (${attempt + 1}/${MAX_RETRIES})…`);
        await new Promise(r => setTimeout(r, wait));
      } else {
        throw e;
      }
    }
  }
  throw lastErr;
}


// ── Mode-based auto-classification ───────────────────────────────────────────
//
//  Two axes:
//    fidelity: does the source have specific named elements to reproduce? (image / structured list)
//              or is it a concept / idea?
//    form:     should the output be a diagram/infographic, or expressive motion design?
//
//  Results in 4 render modes:
//    diagram            — structured source + diagram form. Inject tight layout constraints.
//    free-diagram       — concept/abstract source + diagram form. Claude picks diagram type freely.
//    structured-creative — structured source + creative form. Animate the content expressively.
//    creative           — abstract concept + creative form. Full expressive freedom, no constraints.
//
//  In creative / free-diagram modes: NO layout directive is injected.
//  In diagram mode: a MANDATORY LAYOUT DIRECTIVE is injected with the exact layout sub-type.

const MODE_LABELS = {
  'diagram':             'Diagram',
  'free-diagram':        'Free Diagram',
  'structured-creative': 'Creative',
  'creative':            'Creative',
  'faithful':            'Faithful',
};

const LAYOUT_LABELS = {
  comparison:   'Comparison',
  list:         'Item List',
  architecture: 'Architecture',
  flow:         'Flow Diagram',
  metrics:      'Metrics / Stats',
  timeline:     'Timeline',
  steps:        'Process Steps',
  hierarchy:    'Hierarchy',
};

async function classifyRender(textContent, imageBase64, imageMediaType, modeOverride, layoutOverride) {

  // If user explicitly forced a mode, skip Haiku entirely
  if (modeOverride === 'creative') return { mode: 'creative' };
  if (modeOverride === 'faithful') return { mode: 'faithful' };
  if (modeOverride === 'diagram' && layoutOverride) return { mode: 'diagram', layoutType: layoutOverride };

  const sysPrompt = `You are a motion graphics brief analyzer. Reply with ONLY a raw JSON object — no markdown, no explanation.

Determine two things:

1. FORM — should this be a diagram/infographic or expressive motion design?
   - "diagram": the content has specific named elements, components, or data that must be shown clearly (component lists, architecture, metrics, comparisons, flows, timelines)
   - "creative": the content is a concept, idea, theme, brand message, or abstract subject with no strict elements to enumerate

2. LAYOUT TYPE — only if form is "diagram", choose the sub-type:
   - "comparison": two groups side-by-side (before/after, A vs B, two racks, pros/cons)
   - "list": single flat list of named items or components
   - "architecture": named nodes/boxes connected by lines (infrastructure, system topology)
   - "flow": ordered pipeline with clear direction (start → process → end)
   - "metrics": key numbers, percentages, KPIs
   - "timeline": chronological sequence (events, versions, phases)
   - "steps": numbered process steps (3–8 items)
   - "hierarchy": tree / org chart (parent → children)

Response format (JSON only):
{"form":"diagram","layoutType":"comparison","leftCount":6,"rightCount":4,"hasConnector":true}
or
{"form":"creative"}

leftCount/rightCount: only for comparison. hasConnector: only if a bridge element exists between the two panels.`;

  const userMsg = imageBase64
    ? 'Analyze the attached image and classify it.'
    : textContent
    ? `Analyze this content and classify it:\n\n${textContent.slice(0, 700)}`
    : '{"form":"creative"}';

  let result = null;
  try {
    const raw = await callClaude(sysPrompt, imageBase64, imageMediaType, userMsg, 'haiku');
    const cleaned = raw.trim().replace(/```json\n?|\n?```/g, '').trim();
    result = JSON.parse(cleaned);
  } catch (e) {
    log('Classification failed (' + e.message + ') — using free-diagram fallback', 'warn');
    return { mode: 'free-diagram' };
  }

  // Apply user overrides on top of detected values
  const form = (modeOverride === 'diagram') ? 'diagram'
             : (modeOverride === 'creative') ? 'creative'
             : result.form;

  if (form !== 'diagram') {
    return { mode: 'creative' };
  }

  const layoutType = layoutOverride || result.layoutType;

  if (!layoutType) return { mode: 'free-diagram' };

  return {
    mode: 'diagram',
    layoutType,
    leftCount:    result.leftCount,
    rightCount:   result.rightCount,
    hasConnector: result.hasConnector,
  };
}

function buildRenderDirective(cls) {
  if (!cls) {
    return (
      '\n\n\u2550\u2550\u2550 RENDER MODE: AUTO \u2550\u2550\u2550\n' +
      'The reference image is your CONTENT SOURCE \u2014 not a slide to reproduce.\n' +
      'YOUR JOB: REDESIGN this content as a polished professional motion graphic.\n\n' +
      'STEP 1 \u2014 EXTRACT: identify every named element, group, connection, and count from the image.\n' +
      'STEP 2 \u2014 CHOOSE: pick the single most effective layout archetype for this content:\n' +
      '  comparison | list | architecture | flow | metrics | timeline | steps | hierarchy\n' +
      'STEP 3 \u2014 BUILD: construct a clean diagram using that archetype with full NVIDIA polish and 4-phase animation.\n\n' +
      '\u2022 DO NOT mirror the slide\u2019s visual layout \u2014 design the best version of this content.\n' +
      '\u2022 All item labels verbatim from the image. Counts match exactly.\n' +
      '\u2022 No main slide title.\n'
    );
  }

  // Creative / free-diagram: no structural constraints — let Claude express freely
  if (cls.mode === 'creative') {
    return (
      '\n\n\u2550\u2550\u2550 RENDER MODE: CREATIVE \u2550\u2550\u2550\n' +
      'This is a CREATIVE BRIEF, not a diagram request. Do NOT produce a box-and-line infographic.\n' +
      'Express the concept visually: use kinetic metaphors, bold typography, abstract shapes, particle motion,\n' +
      'morphing geometry, or any technique that communicates the idea with impact.\n' +
      'Ask yourself: what is the ONE visual idea that makes this concept unforgettable?\n' +
      'Build the entire composition around that idea. Be bold.\n'
    );
  }

  if (cls.mode === 'faithful') {
    return (
      '\n\n\u2550\u2550\u2550 RENDER MODE: FAITHFUL \u2550\u2550\u2550\n' +
      'The user chose Faithful mode. Your job is to ANIMATE the slide as-is \u2014 not redesign it.\n' +
      '\n' +
      'STEP 1 \u2014 CLASSIFY THE SOURCE SLIDE (do this before writing any code):\n' +
      '  A) VISUAL SLIDE: has explicit graphical elements \u2014 boxes, panels, diagrams, icons, shapes, arrows, columns, color-coded sections.\n' +
      '     \u2192 Preserve the existing visual structure exactly. Keep all borders, containers, and layout geometry.\n' +
      '  B) TEXT SLIDE: primarily text content \u2014 bullet points, numbered lists, section headers with plain text underneath, minimal or no graphical shapes.\n' +
      '     \u2192 Elevate to proper visual framing: create a bordered container for each section, with the section title as a bold header and items as structured rows inside. Never render floating unstyled text.\n' +
      '\n' +
      'RULES THAT APPLY TO BOTH TYPES:\n' +
      '\u2022 TEXT VERBATIM (EXCEPT THE HEADLINE): include every label AND every description word-for-word — EXCEPT the slide’s main title and subtitle, which are NEVER rendered (see ABSOLUTE BAN ON HEADLINES at top). Never shorten, cut, or drop a description. If a bullet has a label and a description, both appear.\n' +
      '\u2022 LAYOUT AXIS: vertical source stays vertical. Side-by-side source stays side-by-side. Never rearrange or split a vertical layout into columns.\n' +
      '\u2022 ONE COLOR: use ONLY primaryColor for all borders, headers, accents, and label text. The reference may show multiple colors \u2014 IGNORE THEM. Every element uses the same single primaryColor.\n' +
      '\u2022 CANVAS CENTERING: content must be centered horizontally on the canvas. Never push content to the left edge.\n' +
      '\u2022 NO INTRO TEXT: do not render any body sentence that floats above the main content groups (e.g. "Validation is broken down into..."). Only render group headers and their items.\n' +
      '\u2022 NO BACKGROUND FILLS: containers are borders-only on a transparent canvas. No tints, no fills.\n' +
      '\u2022 PANEL HEIGHT TO CONTENT: size containers to fit their content exactly. No empty space below last item.\n' +
      '\u2022 NO INVENTED DECORATIONS: do not add any shape, icon, or element not present in the source.\n' +
      '\u2022 ANIMATION QUALITY: full professional motion design regardless of slide type \u2014 spring entrances, stagger, mask reveals, opacity+translate. Every element has its own entrance.\n'
    );
  }

  if (cls.mode === 'free-diagram') {
    return (
      '\n\n\u2550\u2550\u2550 RENDER MODE: DIAGRAM \u2550\u2550\u2550\n' +
      'This content requires a clear diagram. Choose the most appropriate layout type from your archetype recipes.\n' +
      'All layout rules (margins, spacing, alignment, connector placement) apply in full.\n'
    );
  }

  // diagram mode — inject tight constraints
  const lt = cls.layoutType;
  const directives = {
    comparison:
      'USE THIS EXACT CODE SCAFFOLD — change ONLY the values marked FILL IN. Do not restructure, reposition, or adjust heights.\n' +
      'COLOR RULE — NON-NEGOTIABLE: BOTH panels use primaryColor for all borders, header backgrounds, and accent bars. NEVER assign a different color to the left vs right panel. The reference image may use two colors — IGNORE IT. One primaryColor for everything.\n' +
      '\n' +
      '```tsx\n' +
      '// ── FILL IN ONLY THESE VALUES ─────────────────────────────────────\n' +
      'const LEFT_TITLE = "…";  const LEFT_SUB = "…";\n' +
      'const RIGHT_TITLE = "…"; const RIGHT_SUB = "…";\n' +
      'const leftItems  = [{ label:"…", desc:"…", icon:"server.svg" }];  // one per item from image\n' +
      'const rightItems = [{ label:"…", desc:"…", icon:"network.svg" }]; // one per item from image\n' +
      '// ─────────────────────────────────────────────────────────────────\n' +
      '\n' +
      '// LAYOUT CONSTANTS — ABSOLUTE, DO NOT CHANGE ANY OF THESE\n' +
      'const IH = 88;   // row height in px\n' +
      'const HH = 80;   // header height in px\n' +
      'const PW = 880;  // panel width in px\n' +
      'const panelH = (items: any[]) => HH + items.length * IH;\n' +
      '\n' +
      'const lP = spring({ frame,         fps, config:{damping:200}, durationInFrames:28 });\n' +
      'const rP = spring({ frame:frame-10, fps, config:{damping:200}, durationInFrames:28 });\n' +
      '\n' +
      'const Panel = ({ left, title, sub, items, prog }: any) => {\n' +
      '  const x   = left ? 64 : 976;\n' +
      '  const tx  = interpolate(prog, [0,1], [left ? -50 : 50, 0]);\n' +
      '  const pH  = panelH(items);\n' +
      '  const top = Math.round((1080 - pH) / 2);\n' +
      '  return (\n' +
      '    <div style={{\n' +
      '      position:"absolute", left:x, top, width:PW, height:pH,\n' +
      '      border:`2px solid ${primaryColor}`, borderRadius:2,\n' +
      '      opacity:prog, transform:`translateX(${tx}px)`,\n' +
      '      overflow:"hidden", boxSizing:"border-box"\n' +
      '    }}>\n' +
      '      {/* HEADER — absolute, height:HH, background:primaryColor kept by post-processor */}\n' +
      '      <div style={{\n' +
      '        position:"absolute", top:0, left:0, right:0, height:HH,\n' +
      '        background:primaryColor,\n' +
      '        display:"flex", flexDirection:"column", justifyContent:"center", padding:"0 24px"\n' +
      '      }}>\n' +
      '        <div style={{fontSize:22,fontWeight:700,color:"#111",fontFamily:"NVIDIASans"}}>{title}</div>\n' +
      '        <div style={{fontSize:15,color:"#222",fontFamily:"NVIDIASans",marginTop:2}}>{sub}</div>\n' +
      '      </div>\n' +
      '      {/* ROWS — absolute at top:HH+i*IH — pixel-locked, cannot drift */}\n' +
      '      {items.map((item: any, i: number) => {\n' +
      '        const rP2 = spring({frame:frame-(28+i*10), fps, config:{damping:200}, durationInFrames:22});\n' +
      '        const iP  = spring({frame:frame-(34+i*10), fps, config:{damping:20,stiffness:200}, durationInFrames:16});\n' +
      '        return (\n' +
      '          <div key={i} style={{\n' +
      '            position:"absolute", top:HH+i*IH, left:0, right:0, height:IH,\n' +
      '            display:"flex", alignItems:"center", gap:12,\n' +
      '            borderTop:`1px solid rgba(0,0,0,0.08)`,\n' +
      '            borderLeft:`3px solid ${primaryColor}`,\n' +
      '            paddingLeft:16, paddingRight:20, boxSizing:"border-box",\n' +
      '            opacity:rP2, transform:`translateY(${interpolate(rP2,[0,1],[18,0])}px)`\n' +
      '          }}>\n' +
      '            <div style={{ width:36, height:36, flexShrink:0,\n' +
      '              backgroundImage:`url(${staticFile(\`assets/icons/${item.icon}\`)})`, backgroundSize:"contain", backgroundRepeat:"no-repeat", backgroundPosition:"center",\n' +
      '              opacity:iP, transform:`scale(${interpolate(iP,[0,1],[0,1])})`\n' +
      '            }}/>\n' +
      '            <div style={{flex:1,minWidth:0}}>\n' +
      '              <div style={{fontSize:18,fontWeight:700,color:"#111",fontFamily:"NVIDIASans"}}>{item.label}</div>\n' +
      '              <div style={{fontSize:15,color:"#444",fontFamily:"NVIDIASans",marginTop:2}}>{item.desc}</div>\n' +
      '            </div>\n' +
      '          </div>\n' +
      '        );\n' +
      '      })}\n' +
      '    </div>\n' +
      '  );\n' +
      '};\n' +
      '\n' +
      'return (\n' +
      '  <AbsoluteFill>\n' +
      '    <Panel left={true}  title={LEFT_TITLE}  sub={LEFT_SUB}  items={leftItems}  prog={lP}/>\n' +
      '    <Panel left={false} title={RIGHT_TITLE} sub={RIGHT_SUB} items={rightItems} prog={rP}/>\n' +
      '  </AbsoluteFill>\n' +
      ');\n' +
      '```\n' +
      (cls.leftCount  ? `Left panel: exactly ${cls.leftCount} items.\n` : '') +
      (cls.rightCount ? `Right panel: exactly ${cls.rightCount} items.\n` : ''),
    list:
      'USE THIS EXACT CODE SCAFFOLD — fill in content only:\n' +
      '\n' +
      '```tsx\n' +
      'const primary = primaryColor;\n' +
      'const COL_X = 80, COL_W = 1760, IH = 88;\n' +
      '\n' +
      '// ── FILL IN CONTENT HERE ──────────────────────────────────────────\n' +
      'const items = [\n' +
      '  { label: "…", desc: "…", icon: "server.svg" }, // one per list item from image\n' +
      '];\n' +
      '// ─────────────────────────────────────────────────────────────────\n' +
      '\n' +
      'const totalH = items.length * IH;\n' +
      'const startY = (1080 - totalH) / 2;\n' +
      '\n' +
      'return (\n' +
      '  <AbsoluteFill style={{ background:"transparent" }}>\n' +
      '    {items.map((item, i) => {\n' +
      '      const rP = spring({ frame: frame - i * 12, fps, config: { damping: 200 }, durationInFrames: 22 });\n' +
      '      const iP = spring({ frame: frame - (6 + i * 12), fps, config: { damping: 20, stiffness: 200 }, durationInFrames: 16 });\n' +
      '      const rowY = startY + i * IH;\n' +
      '      const bg = i % 2 === 0 ? "transparent" : `rgba(${primary.replace(/[^\\d,]/g,"")},0.04)`;\n' +
      '      return (\n' +
      '        <div key={i} style={{ position:"absolute", left:COL_X, top:rowY, width:COL_W, height:IH,\n' +
      '                              background:bg, borderLeft:`3px solid ${primary}`,\n' +
      '                              display:"flex", alignItems:"center", gap:16, padding:"0 20px",\n' +
      '                              borderBottom:"1px solid rgba(0,0,0,0.07)",\n' +
      '                              opacity:rP, transform:`translateY(${interpolate(rP,[0,1],[20,0])}px)` }}>\n' +
      '          <div style={{ width:40, height:40, flexShrink:0,\n' +
      '               backgroundImage:`url(${staticFile(\`assets/icons/${item.icon}\`)})`, backgroundSize:"contain", backgroundRepeat:"no-repeat", backgroundPosition:"center",\n' +
      '               opacity:iP, transform:`scale(${interpolate(iP,[0,1],[0,1])})` }}/>\n' +
      '            <div style={{ fontSize:20, fontWeight:700, color:primary, fontFamily:"NVIDIASans" }}>{item.label}</div>\n' +
      '            <div style={{ fontSize:17, color:"#444", fontFamily:"NVIDIASans", marginTop:2 }}>{item.desc}</div>\n' +
      '          </div>\n' +
      '        </div>\n' +
      '      );\n' +
      '    })}\n' +
      '  </AbsoluteFill>\n' +
      ');\n' +
      '```\n' +
      '\n' +
      'Choose icon filenames from the available NVIDIA icon library. No floating text, every item must be in a row.',
    architecture:
      'ARCHITECTURE / NETWORK DIAGRAM \u2014 named boxes connected by lines:\n' +
      '  LAYOUT: Arrange nodes in 2\u20133 horizontal tiers (top = input/source, middle = processing, bottom = output).\n' +
      '  Each node: rect with 2px border in primary color, border-radius 2px, 160\u2013220px wide, 64\u201380px tall.\n' +
      '  Node interior: NVIDIA icon (24px) top-left + bold label (20px) centered or left-aligned.\n' +
      '  nodeX/nodeY: compute explicit pixel positions. Nodes in the same tier share the same Y.\n' +
      '  LINES: SVG <line> or <polyline> from box EDGE to box EDGE only \u2014 never through a box.\n' +
      '  Arrowheads: open <polyline> V-shape (fill="none"), NOT <polygon> or marker-end.\n' +
      '  ZERO overlaps: every node and line must be fully clear of every other node.\n' +
      '  ANIMATION: nodes fade+scale in tier by tier (tier 1 first, then tier 2 after 10f, etc.).\n' +
      '  Lines draw on (strokeDashoffset) after both endpoint nodes have appeared.\n' +
      '  FORBIDDEN: nodes without labels, lines that pass through boxes, overlapping elements.',
    flow:
      'HORIZONTAL FLOW DIAGRAM \u2014 ordered pipeline with draw-on arrows:\n' +
      '  n = number of steps (3\u20135). boxW = (1760 - (n-1)*60) / n. boxH = 120\u2013160px.\n' +
      '  All boxes same size, same Y = (1080 - boxH) / 2. First box X = 80.\n' +
      '  Each box: 2px border in primary color, primary-color header bar 36px tall at top.\n' +
      '  Header bar: bold white step label. Below bar: 18\u201320px description text in #333.\n' +
      '  ARROWS between boxes: animated draw-on open <polyline> arrowhead, primaryColor stroke 2px.\n' +
      '  ANIMATION: Box 1 slides in from left (translateX -30\u21920 + opacity, spring damping:200, 20f).\n' +
      '  Then arrow 1 draws on (strokeDashoffset, 14f). Then box 2 enters (same pattern). Continue sequentially.\n' +
      '  FORBIDDEN: static arrows at frame 0, boxes without header bars, unequal box sizes.',
    metrics:
      'METRICS / STATS DISPLAY \u2014 large numbers as the hero:\n' +
      '  n = number of metrics (2\u20134). tileW = (1760) / n. Each tile centered in its zone.\n' +
      '  Each tile: large number 96\u2013120px bold in primary color + unit label 28px in #555 inline.\n' +
      '  Below number: supporting label 20\u201322px bold in #222 + optional description 18px in #555.\n' +
      '  Optional: thin 2px primary-color horizontal rule above the number.\n' +
      '  Tiles separated by 1px vertical dividers in rgba(0,0,0,0.1).\n' +
      '  COUNT-UP ANIMATION (MANDATORY for every number): interpolate from 0 to final value over 40\u201360 frames.\n' +
      '  Use Math.round(interpolate(frame, [startF, startF+50], [0, finalValue], {extrapolateRight:"clamp"})).\n' +
      '  ENTRANCE: each tile translateY(24\u21920) + opacity staggered 10f apart, Easing.out(Easing.ease), 20f.\n' +
      '  FORBIDDEN: static numbers that do not count up, numbers without labels, all tiles identical size.',
    timeline:
      'HORIZONTAL TIMELINE \u2014 spine line with sequenced nodes:\n' +
      '  spineY = height * 0.52. spineX1 = 80. spineX2 = width - 80.\n' +
      '  n = number of events. nodeX[i] = spineX1 + i * (spineX2 - spineX1) / (n - 1).\n' +
      '  SPINE: SVG <line> that draws on left\u2192right (strokeDashoffset animation, 30f, Easing.out(Easing.quad)).\n' +
      '  Each NODE: circle r=10 in primary color + inner circle r=4 in white, centered on spine.\n' +
      '  LABELS alternate above/below spine to prevent overlap: even index above (y = spineY - 60), odd below (y = spineY + 60).\n' +
      '  Each label block: bold event title (20px, #111) + date/year (18px, #555) below/above.\n' +
      '  Connector tick: 1px vertical line from spine to label, 20\u201340px long.\n' +
      '  ANIMATION: spine draws first (0\u201330f). Then nodes pop in sequentially: scale(0\u21921) + opacity, 6f apart.\n' +
      '  Labels fade+translateY(12\u21920) 4f after their node appears.\n' +
      '  FORBIDDEN: all labels on the same side (causes overlap), nodes not on the spine line.',
    steps:
      'NUMBERED PROCESS STEPS \u2014 sequential boxes with connectors:\n' +
      '  COUNT RULE (pick layout before writing any code):\n' +
      '    3\u20134 steps \u2192 single horizontal row. boxW = (1760 - (n-1)*40) / n. centerY = 540.\n' +
      '    5\u20136 steps \u2192 two-row grid, 3 per row. boxW = 560. Row1 top = 200, Row2 top = 530.\n' +
      '  First box in each row: x = 80. Boxes spaced: x[i] = 80 + i * (boxW + 40).\n' +
      '  boxH: SIZE TO CONTENT \u2014 number(48px) + title(24px) + desc(18px x2 lines) + padding(56px). Target 180px. NEVER exceed 200px. NEVER use a fixed large height with empty space.\n' +
      '  Each box: 2px border primaryColor, borderRadius 2, padding 24px, boxSizing border-box.\n' +
      '  Step number: 46px bold primaryColor, top-left.\n' +
      '  Step title: 22px bold #111, marginTop 8px.\n' +
      '  Step description: 17px #555, marginTop 6px, maxWidth boxW-48px.\n' +
      '  HORIZONTAL CONNECTORS (same row): open <polyline> V-shape arrowhead pointing right, primaryColor stroke 2px. Mid-Y = box centerY.\n' +
      '  WRAP CONNECTOR (last step of row 1 \u2192 first step of row 2, 6-step grid only):\n' +
      '    L-shaped SVG path: right from box3.right+8 \u2192 corner at (box3.right+28, row1.centerY) \u2192 down to (box3.right+28, row2.centerY) \u2192 left to box4.left-8.\n' +
      '    Arrowhead: open V-shape pointing LEFT at endpoint (box4 entry). primaryColor stroke 2px.\n' +
      '    Animate: strokeDashoffset draw-on 24f after step 3 has entered.\n' +
      '  ANIMATION: row by row, left\u2192right: translateY(20\u21920) + opacity, spring damping:200, durationInFrames:20, 12f stagger.\n' +
      '  Row 2 starts entering 20f after Row 1 is complete.\n' +
      '  Horizontal connectors draw on (strokeDashoffset 10f) after their left box has entered.\n' +
      '  FORBIDDEN: step numbers inside circles, empty space inside cards, fixed heights >200px, all steps in one row when n>4.',
    hierarchy:
      'HIERARCHY / TREE \u2014 root at top, children cascade below:\n' +
      '  Root node: centered at x = width/2. nodeW = 200\u2013240px, nodeH = 64\u201380px.\n' +
      '  Level 1 children: evenly spaced across canvas width, y = rootY + nodeH + 80.\n' +
      '  Level 2 children (if any): distributed under their parent, y = level1Y + nodeH + 80.\n' +
      '  childX[i] = parentX - (siblingCount-1)*spacing/2 + i*spacing.\n' +
      '  Each node: 2px border in primary color, bold label (20px) centered, optional NVIDIA icon top-left.\n' +
      '  Root node has solid primary-color fill with white text (emphasizes hierarchy).\n' +
      '  CONNECTORS: vertical line from parent bottom-center to horizontal bar, then down to child top-center.\n' +
      '  ANIMATION: root scales in first (scale 0.9\u21921 + opacity, spring damping:200, 20f).\n' +
      '  Level 1 nodes enter 12f after root: translateY(20\u21920) + opacity, spring, staggered 8f each.\n' +
      '  Connector lines draw on (strokeDashoffset) after parent node has entered.\n' +
      '  Level 2 nodes enter 12f after their parent: same pattern.\n' +
      '  FORBIDDEN: all nodes same visual weight (root must be distinct), lines that skip levels.',
  };

  const dir = directives[lt];
  if (!dir) {
    return (
      '\n\n\u2550\u2550\u2550 RENDER MODE: DIAGRAM \u2550\u2550\u2550\n' +
      'This content requires a clear diagram. Choose the most appropriate archetype.\n'
    );
  }

  return (
    '\n\n\u2550\u2550\u2550 MANDATORY LAYOUT DIRECTIVE \u2550\u2550\u2550\n' +
    'Detected: ' + (LAYOUT_LABELS[lt] || lt) + '\n' +
    dir + '\n' +
    'Use this layout exactly. Do NOT substitute a different layout type.\n'
  );
}

// ── Main ─────────────────────────────────────────────────────────────────────

// ── Wireframe classification (classify-only path) ────────────────────────────

async function classifyForWireframes(textContent, imageBase64, imageMediaType, modeOverride, layoutOverride) {
  if (modeOverride === 'creative') {
    return [{ mode: 'creative', layoutType: null, label: 'Creative', confidence: 1.0 }];
  }
  if (modeOverride === 'diagram' && layoutOverride) {
    return [{ mode: 'diagram', layoutType: layoutOverride, label: LAYOUT_LABELS[layoutOverride] || layoutOverride, confidence: 1.0 }];
  }

  const sysPrompt =
    'You are a layout classifier for motion graphics. Reply ONLY with a raw JSON array — no markdown, no explanation.\n'
    + '\nReturn the top 3 best layout types for this content, ranked by fit. Score each 0.0-1.0.\n'
    + '\nLayout types: comparison, list, architecture, flow, metrics, timeline, steps, hierarchy, creative\n'
    + '\n- comparison: two groups side-by-side (A vs B, before/after, pros/cons)\n'
    + '- list: flat list of named items or components\n'
    + '- architecture: named nodes/boxes connected by lines (topology, infrastructure)\n'
    + '- flow: ordered pipeline with clear direction (start to end)\n'
    + '- metrics: numbers, percentages, KPIs, benchmark data\n'
    + '- timeline: chronological sequence (events, phases, versions)\n'
    + '- steps: numbered process steps (3-8 items)\n'
    + '- hierarchy: tree or org chart (parent to children)\n'
    + '- creative: abstract concept, brand message, or theme — no strict named elements\n'
    + '\nResponse format: [{"type":"flow","confidence":0.88},{"type":"steps","confidence":0.62},{"type":"list","confidence":0.35}]';

  const userMsg = imageBase64
    ? 'Classify the attached image. Return top 3 layout types as JSON.'
    : textContent
    ? 'Classify this content and return top 3 layout types as JSON:\n\n' + textContent.slice(0, 700)
    : '[{"type":"list","confidence":0.5}]';

  let suggestions = [];
  try {
    const raw = await callClaude(sysPrompt, imageBase64, imageMediaType, userMsg, 'haiku');
    const cleaned = raw.trim().replace(/```json\n?|\n?```/g, '').trim();
    const parsed = JSON.parse(cleaned);
    suggestions = parsed.slice(0, 3).map(function(s) {
      const isCreative = s.type === 'creative' || s.type === 'free-diagram';
      return {
        mode: isCreative ? (s.type === 'creative' ? 'creative' : 'free-diagram') : 'diagram',
        layoutType: isCreative ? null : s.type,
        label: isCreative ? 'Creative' : (LAYOUT_LABELS[s.type] || s.type),
        confidence: Math.min(1, Math.max(0, typeof s.confidence === 'number' ? s.confidence : 0.5)),
      };
    }).filter(function(s) { return s.mode && s.label; });
  } catch (e) {
    log('Wireframe classify failed (' + e.message + ') — using fallback', 'warn');
    suggestions = [
      { mode: 'free-diagram', layoutType: null, label: 'Auto', confidence: 0.6 },
      { mode: 'diagram', layoutType: 'flow', label: 'Flow', confidence: 0.4 },
      { mode: 'diagram', layoutType: 'list', label: 'Item List', confidence: 0.3 },
    ];
  }

  return suggestions.length > 0 ? suggestions : [{ mode: 'free-diagram', layoutType: null, label: 'Auto', confidence: 0.5 }];
}

async function main() {
  const args = parseArgs(process.argv);

  const imagePath    = args.image;
  const textContent  = args.text;
  const outputPath   = args.output;
  const remotionDir  = args.remotion;
  const assetsFile     = args['assets-file'];
  const noText         = args['no-text'] === '1';
  modelOverride        = args['model'] || null;
  const bgColor        = args['bg-color'] || '';   // '' = transparent (default)
  const primaryColor   = args['primary-color'] || 'rgb(118,185,0)';
  const secondaryColor = args['secondary-color'] || '';
  const fixRequest     = args['fix-request'] || null; // fix/tweak mode
  const userLengthSec   = args['length'] ? Math.max(1, Math.min(60, parseInt(args['length'], 10))) : null;
  const userLengthFrames = userLengthSec ? Math.round(userLengthSec * 30) : null;
  const quality4k        = args['quality-4k'] === '1';
  const modeOverride     = args['render-mode'] || null;   // 'diagram' | 'creative' | null (auto)
  const layoutOverride   = args['layout-override'] || null;
  const classifyOnly     = args['classify-only'] === '1';
  const creativeBriefRaw = args['creative-brief'] ? (() => { try { return JSON.parse(args['creative-brief']); } catch(e) { return null; } })() : null;

  const ARCHETYPE_PARAMS = {
    'data-story':     'VISUALIZATION ARCHETYPE: DATA STORY\nLead with 1–2 hero metric values at 96–160px, semibold weight. Support with horizontal bar charts or sparklines. Maximum 4 data points per chart group. Reserve 280px on the right for trailing labels (never clip them). Layout: metric hero top-center, chart below, vertically centered in canvas.',
    'system-map':     'VISUALIZATION ARCHETYPE: SYSTEM MAP\nNetwork topology: one central hub, 3–6 satellite nodes at even radial angles. Hub: labeled circle 80–100px radius. Spokes draw themselves using strokeDashoffset animation. Nodes arrive after their spoke completes. All labels inside or directly beside their node. No crossing spokes.',
    'concept-reveal': 'VISUALIZATION ARCHETYPE: CONCEPT REVEAL\nOne dominant visual idea — no multi-panel grid. An abstract shape or metaphor establishes itself first (4–8 seconds), then text materializes last. 50–60% of canvas is intentional negative space. This is a cinematic statement, not an informational diagram.',
    'showcase':       'VISUALIZATION ARCHETYPE: SHOWCASE\n2–4 equal-height cards in a horizontal row (never 5+). Each card: accent-bordered rect + icon (top) + bold title + 1-line description. All card tops aligned, all card bottoms aligned. Cards enter with staggered spring translateY. No card is visually dominant over the others.',
    'journey':        'VISUALIZATION ARCHETYPE: JOURNEY\n3–6 numbered steps left-to-right. Open polyline connector arrows between steps. Step 1 full accent color; remaining steps progressively lighter. Steps enter left-to-right; arrow draws on between each pair after both neighbors have appeared.',
    'versus':         'VISUALIZATION ARCHETYPE: VERSUS\nTwo-column comparison. LEFT panel: full accent-color border, full opacity. RIGHT panel: muted dashed border, 0.5 opacity. A centered ‘VS’ marker between them. Identical information density on each side — same row count, same visual weight. Leading side enters first.'
  };

  const MOOD_PARAMS = {
    'sharp':   'VISUAL MOOD: SHARP\nAll border-radius: 0px for containers, ≤2px for small elements. Colors at 100% opacity — no tints. Layout snapped to 32px grid. letterSpacing: \'0.04em\'. Motion: ease-in-out only, no spring physics, no overshoot. High contrast — primaryColor against #111.',
    'organic': 'VISUAL MOOD: ORGANIC\nAll containers border-radius ≥12px (prefer 20–32px for large elements). Entrances use spring({ damping: 14, stiffness: 90 }). At least one element has idle float: translateY += Math.sin(frame * 0.025) * 5. Colors at ≤0.85 opacity. Gaps: 24–32px (loose and airy).',
    'minimal': 'VISUAL MOOD: MINIMAL\n≤5 visual elements total (text nodes count). At least 40% of canvas is empty negative space. Primary message at 72–96px bold. One accent-color element maximum. No decorative lines, no background shapes, no borders. Motion: single smooth fade+translate per element, no cascading sequence.',
    'electric': 'VISUAL MOOD: ELECTRIC\nAt least one element uses a glow: style={{ filter: \'drop-shadow(0 0 16px <primaryColor>)\' }}. Entrance animations: 8–14 frames using spring({ damping: 220, stiffness: 280 }). Bold text letterSpacing: \'0.06em\'. Full-opacity fills. Include one thin 1px accent line that draw-animates in 10–16 frames.',
    'dense':   'VISUAL MOOD: DENSE\n6–9 labeled elements minimum. 8–12px gaps between items. Labels: 11–13px. Values: 14–18px bold. Alternating row backgrounds: rgba(r,g,b, 0.05) on even rows. Compact hierarchy per row: label + value. No wasted canvas space.'
  };

  const MOTION_PARAMS = {
    'assembled': 'ANIMATION STYLE: ASSEMBLED\nspring({ frame, fps, config: { damping: 200, stiffness: 220 }, durationInFrames: 18 }) for every entrance. Translate only ±20px from final position. Damping MUST be ≥180 — zero elastic overshoot. Stagger: 6–8 frames between siblings. Containers arrive 10 frames before their children. Feel: parts clicking precisely into place.',
    'revealed':  'ANIMATION STYLE: REVEALED\nReveal via clipPath inset wipe: from \'inset(0 100% 0 0)\' to \'inset(0 0% 0 0)\' over 22–28 frames using interpolate + Easing.inOut(Easing.ease). Stagger 10–14 frames. Container arrives first (opacity 0→1 in 10 frames), then content is revealed inside it. No scale, no translate.',
    'emerged':   'ANIMATION STYLE: EMERGED\nspring({ frame, fps, config: { damping: 14, stiffness: 120 }, durationInFrames: 22 }) for scale (0→1) + opacity — springy overshoot is intentional. After frame 60, add idle loops: hero element: translateY += Math.sin(frame * 0.03) * 4 continuously. Secondary: Math.sin(frame * 0.025 + phaseOffset) * 3.'
  };


  if (!classifyOnly && (!outputPath || !remotionDir)) {
    process.stderr.write(
      'Usage: node abstractor-bridge.js --text ... --output ... --remotion ... [--image ...]\n' +
      '       node abstractor-bridge.js --fix-request "..." --output ... --remotion ...\n'
    );
    process.exit(1);
  }

  // ── FIX MODE: targeted edit on the last generated component ───────────────
  if (fixRequest) {
    progress(0.05, 'Reading last component…');
    const compPath = path.join(remotionDir, 'src', 'generated', 'AbstractorComp.tsx');
    let existingCode;
    try {
      existingCode = fs.readFileSync(compPath, 'utf8');
    } catch (e) {
      log('Error: no previous render found at ' + compPath, 'err');
      process.exit(1);
    }
    log('Fix mode: loaded ' + existingCode.split('\n').length + ' lines from last render');

    progress(0.10, 'Asking Claude to apply the fix…');
    const fixSystemPrompt = `You are a Remotion TSX code editor. The user has an existing animation component and wants a specific targeted change.

RULES (apply to ALL edits):
• Return the COMPLETE modified TypeScript JSX file — no truncation, no "..." placeholders, no explanations.
• Change ONLY what the fix request asks. Do NOT restructure, redesign, rename variables, or change anything else.
• Acronyms (GPU, CPU, RAM, LLM, DGX, DGXC, AI, ML, API, etc.) must always be ALL CAPS in string literals.
• borderRadius: 0 for all containers/cards/frames. Max 2px for small elements (badges, pills).
• NEVER use textTransform: 'uppercase' anywhere.
• NEVER use SVG <marker> or marker-end for arrowheads — use explicit <polyline> elements with fill="none".
• Lines/arrows must start invisible (strokeDashoffset = totalLength at frame 0) before their draw-on animation.
• NEVER use delayRender() or continueRender() — they cause render timeouts. All animation must be driven purely by useCurrentFrame().
• NEVER output markdown fences, only raw TypeScript code.
${!bgColor ? '• TRANSPARENT CANVAS: This video composites as an alpha-channel overlay in AE. NEVER set background or backgroundColor on AbsoluteFill or any wrapper div — leave them unset. Only explicit content shapes (SVG <rect>/<circle>/<path>, header bars) may have fills.' : '• Background color will be set on the outermost AbsoluteFill automatically — do not set it yourself.'}`;

    const fixUserMessage = `Here is the current component code:\n\n${existingCode}\n\n---\nFIX REQUEST: ${fixRequest}\n\nApply the fix and return the complete modified component.`;

    progress(0.15, 'Claude is applying the fix…');
    let fixedCode;
    try {
      fixedCode = await callClaudeWithRetry(fixSystemPrompt, null, null, fixUserMessage);
    } catch (e) {
      log('Claude fix error: ' + e.message, 'err');
      process.exit(1);
    }

    // Apply same post-processing as normal generation (but NO background stripping —
    // fix renders are standalone full-color animations imported as new AE layers)
    fixedCode = extractCode(fixedCode);

    // ── Prose-rejection guard (same as normal generation path) ─────────────────
    // If Claude returned prose instead of TSX, abort before writing to the file.
    {
      const fixHasImport  = /\bimport\b/.test(fixedCode);
      const fixHasExport  = /export\s+(default\s+function|default\s+class|const\s+\w)/.test(fixedCode);
      const fixProseStart = /^(I\s+(need|will|want|should|can|would|am)|Let\s+me|First[,\s]|To\s+(create|generate|build|design)|Looking\s+at|The\s+(reference|image|slide|content)|Based\s+on|It\s+seems)/i.test(fixedCode.trim());
      if (!fixHasImport || !fixHasExport || fixProseStart) {
        log('Fix failed: Claude returned prose instead of TSX code. First 300 chars: ' + fixedCode.slice(0, 300), 'err');
        log('Hint: Try rephrasing the fix request. The existing component was NOT modified.', 'err');
        process.exit(4);
      }
    }

    // Enforce BG transparency in fix mode (same as normal generation path)
    if (!bgColor) {
      const SAFE_FIX_BG = new Set(['primaryColor','bg','bgColor','headerBg','rowBg','cardBg','fillColor','accentColor']);
      const isSafeBgVal = v => { const s = v.replace(/['"]/g,'').trim().toLowerCase(); return s==='transparent'||s==='none'||s==='unset'; };
      let fixStripped = 0;
      fixedCode = fixedCode.replace(/\b(background(?:Color)?)\s*:\s*('[^']*'|"[^"]*")/gi, (m,p,v) => isSafeBgVal(v)?m:(fixStripped++,`${p}: 'transparent'`));
      fixedCode = fixedCode.replace(/\b(background(?:Color)?)\s*:\s*([A-Za-z_$][A-Za-z0-9_$]*|#[0-9a-fA-F]{3,8})\b/gi, (m,p,v) => (isSafeBgVal(v)||SAFE_FIX_BG.has(v))?m:(fixStripped++,`${p}: 'transparent'`));
      fixedCode = fixedCode.replace(/\b(background(?:Color)?)\s*:\s*(rgba?\([^)]*\))/gi, (m,p) => (fixStripped++,`${p}: 'transparent'`));
      if (fixStripped > 0) log(`Fix: stripped ${fixStripped} non-transparent background(s)`, 'ok');
    }
    const upperCount = (fixedCode.match(/textTransform\s*:\s*['"`]uppercase['"`]/gi) || []).length;
    if (upperCount > 0) {
      fixedCode = fixedCode.replace(/textTransform\s*:\s*(['"`])uppercase\1(\s*as\s+const)?/gi, "textTransform: 'none'");
    }
    const markerCount = (fixedCode.match(/marker-(?:end|start)/gi) || []).length;
    if (markerCount > 0) {
      fixedCode = fixedCode
        .replace(/\s*marker-(?:end|start)\s*=\s*\{?["'][^"']*["']\}?/g, '')
        .replace(/<defs>[\s\S]*?<\/defs>/g, (block) => block.includes('<marker') ? '' : block);
    }

    progress(0.40, 'Writing fixed component…');
    fs.writeFileSync(compPath, fixedCode, 'utf8');
    log('Fixed component written → ' + compPath, 'ok');

    // Extract durationFrames for chunked-render decision
    const fixDfFinal = fixedCode.match(/export\s+const\s+DURATION_FRAMES\s*=\s*(\d+)/);
    const fixDurationFrames = fixDfFinal ? Math.min(480, Math.max(90, parseInt(fixDfFinal[1], 10))) : 360;

    // Jump straight to render (step 7 logic inlined) — uses chunked render for long clips
    const fixChunkLabel = fixDurationFrames > 750
      ? `${Math.ceil(fixDurationFrames / 350)} chunks × 350 frames (OOM-safe)`
      : 'single pass';
    progress(0.50, `Re-rendering with fix applied (${fixDurationFrames} frames, ${fixChunkLabel})…`);
    log(`Starting Remotion render — ${fixDurationFrames} frames, ${fixChunkLabel}`);
    const remotionCliScript = path.join(remotionDir, 'node_modules', '@remotion', 'cli', 'remotion-cli.js');
    const nodeBin = process.execPath;
    let fixRenderErr = null;
    await renderComposition({
      outputPath, bgColor, durationFrames: fixDurationFrames,
      remotionDir, remotionCliScript, nodeBin, quality4k,
      log, progress,
      progressStart: 0.50, progressEnd: 0.97,
    }).catch((e) => { fixRenderErr = e; });

    if (fixRenderErr) {
      const errText = fixRenderErr.remotionErrorLine || fixRenderErr.message || '';
      const isFixable = ['inputRange must contain only numbers','strictly monotonically increasing','ReferenceError','TypeError','is not defined','Cannot read propert','outputRange must contain only numbers','Expected identifier','Transform failed','Module build failed','SyntaxError','Unexpected token','is not a function','Cannot destructure','delayRender','was called but not cleared'].some(p => errText.includes(p));
      if (isFixable) {
        log(`Render crashed: "${errText}" — attempting auto-fix…`, 'warn');
        const brokenCode = fs.readFileSync(compPath, 'utf8');
        const crashFixPrompt = `You are a Remotion TSX code editor. The component below crashed at render time with this error:\n\n${errText}\n\nFix ONLY the code that causes this runtime error. If the error mentions delayRender or timeout: remove ALL delayRender()/continueRender() calls — replace any image loading or async logic with synchronous staticFile() references. All animation must be driven purely by useCurrentFrame(). IMPORTANT: Return the COMPLETE corrected TypeScript JSX file — every single line, nothing omitted. Do not output a diff or just the changed lines. Output the entire file. No markdown fences, no explanations.`;
        try {
          let crashFixed = await callClaudeWithRetry(crashFixPrompt, null, null, `Here is the component:\n\n${brokenCode}`);
          crashFixed = extractCode(crashFixed);
          const hasDefault = /export\s+default\s+function/.test(crashFixed);
          const isComplete = crashFixed.length >= brokenCode.length * 0.6;
          if (hasDefault && isComplete) {
            fs.writeFileSync(compPath, crashFixed, 'utf8');
            log('Render-crash auto-fix applied — retrying…', 'ok');
            await renderComposition({
              outputPath, bgColor, durationFrames: fixDurationFrames,
              remotionDir, remotionCliScript, nodeBin, quality4k,
              log, progress,
              progressStart: 0.55, progressEnd: 0.97,
            }).catch((e2) => {
              log('Fatal: Remotion render exited with code 1', 'err');
              process.exit(5);
            });
          } else {
            log('Render-crash fix incomplete — aborting', 'err');
            process.exit(5);
          }
        } catch (fixErr) {
          log('Render-crash auto-fix failed: ' + fixErr.message, 'err');
          process.exit(5);
        }
      } else {
        log('Fatal: Remotion render exited with code 1', 'err');
        process.exit(5);
      }
    }

    progress(1.0, 'Fix done!');
    log('Fix render complete → ' + outputPath, 'ok');
    process.exit(0);
  }
  // ── END FIX MODE ──────────────────────────────────────────────────────────

  // ── 0a. Build NVIDIA icon library section ─────────────────────────────────
  let iconLibrarySection = '';
  let validIconNames = new Set();
  const iconsDir = path.join(remotionDir, 'public', 'assets', 'icons');
  try {
    const iconFiles = fs.readdirSync(iconsDir)
      .filter(f => f.endsWith('.svg'))
      .map(f => f.replace(/\.svg$/, ''))
      .sort();
    if (iconFiles.length > 0) {
      iconLibrarySection = `\n\n\u2550\u2550\u2550 NVIDIA BRAND ICON LIBRARY \u2550\u2550\u2550
${iconFiles.length} NVIDIA brand SVG icons are available in public/assets/icons/. Use them to add visual context to diagram nodes, cards, and flow steps.

HOW TO USE:
import { staticFile } from 'remotion'; // NO <Img> — use CSS background-image
<div style={{ width:48, height:48, backgroundImage:\`url(\${staticFile('assets/icons/FILENAME.svg')})\`, backgroundSize:'contain', backgroundRepeat:'no-repeat', backgroundPosition:'center' }} />

ICON RULES:
\u2022 ICON ENTRANCE SEQUENCING (CRITICAL): Icons inside a box MUST appear AFTER the box. Always animate icon opacity: 0 at frame 0 \u2014 fade in only after the parent box is drawn. Pattern: const iconOp = interpolate(frame, [boxFadeEnd, boxFadeEnd + 12], [0, 1], ease); then style={{ opacity: iconOp }} on the background-image div wrapper. NEVER render an icon at opacity:1 from frame 0.
\u2022 ALWAYS USE NVIDIA ICONS — NEVER DRAW CUSTOM SVG SHAPES FOR KNOWN CONCEPTS (MANDATORY): If a concept has a matching NVIDIA icon in the library, use a CSS background-image div (see HOW TO USE above). NEVER hand-draw SVG circles as person silhouettes, gear paths as settings, grid patterns as GPUs, or any other custom shape when an NVIDIA icon already represents that concept. Check the icon list first before drawing anything.
  Common concept → icon keyword mapping (search the AVAILABLE ICONS list for these terms):
  User / person / account → search "user" or "account"
  Settings / config / admin → search "settings" or "gear" or "config"
  GPU / chip / accelerator → search "gpu" or "chip"
  Server / node / compute → search "server" or "node"
  Network / cluster / fabric → search "network" or "cluster" or "fabric"
  Cloud / storage / data → search "cloud" or "storage"
  AI / ML / model → search "ai" or "neural" or "model"
  Team / department / org → search "team" or "org" or "department"
\u2022 Choose the icon whose filename most closely matches the concept being represented
\u2022 Use icons INSIDE cards/nodes alongside their text label — never as floating standalone elements
\u2022 Size: 40\u201364px for card icons, 80\u2013120px for large hero nodes
\u2022 Apply the primary color as a CSS filter tint OR render as-is (the SVGs already use NVIDIA green/dark by default)
\u2022 Animate with fade-in + subtle scale tied to the card\u2019s entrance timing
\u2022 Prefer the m48-* icons (official NVIDIA brand set)

AVAILABLE ICONS (use exact filename + .svg):
${iconFiles.join(' | ')}`;
      log(`Icon library: ${iconFiles.length} icons available`);
      iconFiles.forEach(name => validIconNames.add(name + '.svg'));
    }
  } catch (e) {
    log('Note: no icon library found at ' + iconsDir);
  }


  // ── 0b. Build Lottie animation library section ────────────────────────────
  let lottieLibrarySection = '';
  const lottieCatalogPath = path.join(remotionDir, 'src', 'lottie', '_catalog.json');
  try {
    const lottieCatalog = JSON.parse(fs.readFileSync(lottieCatalogPath, 'utf8'));
    if (lottieCatalog.length > 0) {
      const lottieLines = lottieCatalog.map(e => `${e.file} [${e.tags.join(', ')}]`).join('\n');
      lottieLibrarySection = `\n\n\u2550\u2550\u2550 LOTTIE ANIMATION LIBRARY \u2550\u2550\u2550
${lottieCatalog.length} pre-built Lottie animations are available at remotion/src/lottie/. Use them for animated illustrations inside cards, as hero visuals, or as icon-level accents.

HOW TO USE:
import { Lottie } from '@remotion/lottie';
import gpuData from '../lottie/gpu.json';
// In JSX (wrap with opacity fade-in):
const op = interpolate(frame, [0, 8], [0, 1], { extrapolateRight: 'clamp' });
<div style={{ opacity: op }}><Lottie animationData={gpuData} style={{ width: 120, height: 120 }} /></div>

RULES:
\u2022 ALWAYS wrap every <Lottie> in an opacity fade-in div (0\u21921 over frames 0-8).
\u2022 Lottie files loop automatically. Soften the hard snap by cross-fading: fade out over last 8 frames of each cycle, fade in over first 5 frames of the next.
\u2022 Size: 80-160px for card illustrations, 200-280px for hero/solo animations.
\u2022 Prefer a matching Lottie over a hand-drawn SVG shape when a concept matches the library.
\u2022 Do NOT use delayRender() or continueRender() with Lottie — frame-driven automatically.

FIND BY CONCEPT — search tags to pick the right file:
${lottieLines}`;
      log('Lottie library: ' + lottieCatalog.length + ' animations available');
    }
  } catch (e) {
    // No catalog found — silently skip
  }

  // ── 0c. Build user animation preferences section ──────────────────────────
  // Parsed from --animations CLI arg. Format: "entrance:fade,trim-path|text:reveal|loop:pulse|easing:bouncy"
  // Empty / missing → empty string (no prompt change). Additive only.
  let animationPrefsSection = '';
  const animationsArg = args.animations || '';
  if (animationsArg.trim()) {
    const ANIM_LABELS = {
      // Entrances
      'fade':         'fade in (opacity 0→1 over 12-18 frames)',
      'slide':        'slide in from offset (translateX/Y, 16-32px distance)',
      'scale':        'scale-pop entrance (scale 0.8→1.0 with opacity fade)',
      'mask':         'mask reveal (clip-path or wipe sweep unveiling content)',
      'trim-path':    'trim-path line drawing for SVG strokes (strokeDashoffset animation)',
      'stagger':      'stagger sequential entrances 6-12 frames apart per element',
      // Text
      'word-reveal':  'word-by-word reveal (each word fades in with 4-6 frame delay)',
      'char-stagger': 'character-by-character stagger entrance',
      'typewriter':   'typewriter effect with progressive substring (use Math.floor(progress) on text.length)',
      'counter':      'animated number counter ticking up from 0 to final value',
      // Loops
      'pulse':        'subtle pulse loop on accent elements (scale 1.0→1.05→1.0, 60-frame cycle)',
      'float':        'gentle vertical float ±2-4px on hero elements (90-frame cycle)',
      'rotate':       'slow continuous rotation on circular icons (360deg over 600 frames)',
      'breathing':    'organic breathing scale 1.0→1.03→1.0 over 90 frames',
      // Connectors
      'draw':         'connector lines draw themselves via trim-path (strokeDashoffset)',
      'pulse-path':   'animated dot/pulse traveling along connector paths',
      'gradient-flow':'animated gradient flowing along connector strokes (data-flow feel)',
      // Easing
      'smooth':       'Easing.inOut(Easing.ease) — refined, professional pacing',
      'snappy':       'Easing.out(Easing.cubic) — fast settle, decisive feel',
      'bouncy':       'spring physics with slight overshoot (use spring() with damping ~12, mass ~0.6)'
    };
    const GROUP_LABELS = {
      'entrance':  'ELEMENT ENTRANCES',
      'text':      'TEXT ANIMATIONS',
      'loop':      'IDLE LOOPS (post-entrance)',
      'connector': 'CONNECTOR ANIMATIONS',
      'easing':    'EASING / PACING'
    };
    const lines = [];
    animationsArg.split('|').forEach(group => {
      const [key, val] = group.split(':');
      if (!key || !val) return;
      const items = val.split(',').map(t => t.trim()).filter(Boolean);
      if (!items.length) return;
      const label = GROUP_LABELS[key] || key.toUpperCase();
      const expanded = items.map(it => '  • ' + (ANIM_LABELS[it] || it)).join('\n');
      lines.push(label + ':\n' + expanded);
    });
    if (lines.length) {
      animationPrefsSection = `\n\n═══ USER ANIMATION PREFERENCES (HIGH PRIORITY) ═══
The user has explicitly selected these animation techniques. Give them prominent visual treatment in your design — build the visual language AROUND these preferences. Use them on the most important elements first. If a preference doesn't apply to a specific element, that's fine, but the overall render must clearly express the selected styles. Ignoring these is a failure mode.

${lines.join('\n\n')}`;
      log('Animation prefs: ' + animationsArg);
    }
  }

  // ── 0. Load and copy assets ────────────────────────────────────────────────
  let assets = [];
  if (assetsFile) {
    try { assets = JSON.parse(fs.readFileSync(assetsFile, 'utf8')); } catch (e) {
      log('Warning: could not read assets file: ' + e.message);
    }
  }

  let assetPromptSection = '';

  if (assets.length > 0) {
    progress(0.03, 'Packing the asset suitcase…');
    const publicAssetsDir = path.join(remotionDir, 'public', 'assets');
    const lottieAssetsDir = path.join(remotionDir, 'src', 'lottie');
    fs.mkdirSync(publicAssetsDir, { recursive: true });
    fs.mkdirSync(lottieAssetsDir, { recursive: true });

    const assetLines = [];
    for (const a of assets) {
      const isLottie = a.type === 'lottie';
      const dest = isLottie
        ? path.join(lottieAssetsDir, a.name)
        : path.join(publicAssetsDir, a.name);
      try {
        fs.copyFileSync(a.path, dest);
        log('Asset copied: ' + a.name, 'ok');
        let usage;
        if (isLottie) {
          const importAlias = a.name.replace(/[^a-zA-Z0-9]/g, '_').replace(/^_+/, '');
          usage = `import ${importAlias} from '../lottie/${a.name}'; — then: <Lottie animationData={${importAlias}} style={{ width: ..., height: ... }} />`;
        } else if (a.type === 'svg' || a.type === 'png') {
          usage = `<Img src={staticFile('assets/${a.name}')} style={{ width: ..., height: ... }} />`;
        } else {
          usage = `staticFile('assets/${a.name}')`;
        }
        assetLines.push(`• ${a.name}  [${a.type.toUpperCase()}]  ${usage}`);
      } catch (e) {
        log('Warning: could not copy asset ' + a.name + ': ' + e.message);
      }
    }

    const hasLottie = assets.some(a => a.type === 'lottie');
    const lottieNote = hasLottie
      ? `\nFor Lottie files: add \`import { Lottie } from '@remotion/lottie';\` at the top and use the import alias shown above. The Lottie component is frame-driven automatically — no delayRender needed.\nLOTTIE RULES (ALL MANDATORY):\n1. FADE-IN: Always wrap every <Lottie> in a div with opacity from 0→1 over frames 0–5:\n   const lottieOpacity = interpolate(frame, [0, 5], [0, 1], { extrapolateRight: 'clamp' });\n   <div style={{ opacity: lottieOpacity }}><Lottie animationData={...} style={{ width: ..., height: ... }} /></div>\n2. ORGANIC LOOP: Lottie animations loop automatically, but the hard snap back to frame 0 looks abrupt. Soften it by fading the opacity to 0 over the last 8 frames of each cycle and back to 1 over the first 5 frames of the next:\n   const lottieDuration = 60; // adjust to match actual animation length in frames\n   const loopFrame = frame % lottieDuration;\n   const fadeOut = interpolate(loopFrame, [lottieDuration - 8, lottieDuration], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });\n   const fadeIn  = interpolate(loopFrame, [0, 5], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });\n   const lottieOpacity = loopFrame < 5 ? fadeIn : loopFrame > lottieDuration - 8 ? fadeOut : 1;\n   <div style={{ opacity: lottieOpacity }}><Lottie animationData={...} style={{ width: ..., height: ... }} /></div>`
      : '';

    assetPromptSection = `\n\n═══ AVAILABLE ASSETS ═══\nThe following files have been provided and MUST be incorporated into the animation:\n\n${assetLines.join('\n')}\n${lottieNote}\nAlways use these assets — do not invent placeholder graphics when real assets are provided.`;
  }

  // ── 1. Encode image as base64 (optional) ──────────────────────────────────
  let imageBase64, imageMediaType;
  if (imagePath) {
    progress(0.05, 'Scanning the reference with robot eyes…');
    try {
      let imgBuf = fs.readFileSync(imagePath);
      const ext = path.extname(imagePath).toLowerCase();
      imageMediaType = (ext === '.jpg' || ext === '.jpeg') ? 'image/jpeg'
        : ext === '.gif'  ? 'image/gif'
        : ext === '.webp' ? 'image/webp'
        : 'image/png';

      // Auto-resize if image exceeds Claude API limits (5 MB base64 OR any dimension > 7900px on macOS)
      const { execFileSync } = require('child_process');
      const MAX_B64 = 5 * 1024 * 1024;
      const MAX_DIM = 7900;
      const b64Len = imgBuf.toString('base64').length;
      let needsResize = b64Len > MAX_B64;
      if (process.platform === 'darwin') {
        try {
          const sipsInfo = execFileSync('sips', ['-g', 'pixelWidth', '-g', 'pixelHeight', imagePath]).toString();
          const wMatch = sipsInfo.match(/pixelWidth:\s*(\d+)/);
          const hMatch = sipsInfo.match(/pixelHeight:\s*(\d+)/);
          const imgW = wMatch ? parseInt(wMatch[1]) : 0;
          const imgH = hMatch ? parseInt(hMatch[1]) : 0;
          if (imgW > MAX_DIM || imgH > MAX_DIM) needsResize = true;
        } catch (_) {}
      }
      if (needsResize) {
        log(`Image too large (${(imgBuf.length/1024).toFixed(0)}KB) — resizing to 1920px max…`);
        const tmpResized = path.join(os.tmpdir(), 'abstractor_resized_' + Date.now() + '.jpg');
        if (process.platform === 'darwin') {
          execFileSync('sips', ['-s', 'format', 'jpeg', '-s', 'formatOptions', '85', '-Z', '1920', imagePath, '--out', tmpResized]);
        } else {
          execFileSync(getCompositorFfmpeg(remotionDir), ['-y', '-i', imagePath, '-vf', "scale='min(1920,iw)':-2", '-q:v', '3', tmpResized]);
        }
        imgBuf = fs.readFileSync(tmpResized);
        imageMediaType = 'image/jpeg';
        fs.unlinkSync(tmpResized);
        log('Resized image: ' + (imgBuf.length / 1024).toFixed(0) + ' KB');
      }

      imageBase64 = imgBuf.toString('base64');
    } catch (e) {
      log('Cannot read image: ' + e.message, 'err');
      process.exit(3);
    }
  } else {
    progress(0.05, 'Pure imagination mode activated…');
    log('No image provided — generating from text description only.');
  }

  // ── 2. Load Remotion skill rules ───────────────────────────────────────────
  // ── CLASSIFY-ONLY: emit wireframe suggestions then exit ────────────────
  if (classifyOnly) {
    progress(0.3, 'Analyzing content…');
    const wfSuggestions = await classifyForWireframes(textContent, imageBase64, imageMediaType, modeOverride, layoutOverride);
    process.stderr.write(JSON.stringify({ wireframes: wfSuggestions }) + '\n');
    process.exit(0);
  }

  process.stderr.write(JSON.stringify({ model: modelOverride || MAIN_MODEL }) + '\n');
  progress(0.08, 'Briefing the motion graphics department…');
  const skillsBase = path.join(__dirname, 'rules');
  const remotionRules = [
    readRule(skillsBase, 'animations.md'),
    readRule(skillsBase, 'timing.md'),
    readRule(skillsBase, 'text-animations.md'),
    readRule(skillsBase, 'transparent-videos.md'),
    readRule(skillsBase, 'sequencing.md'),
  ].filter(Boolean).join('\n\n---\n\n');

  // ── 3. Build prompts ───────────────────────────────────────────────────────

  // Composition style rules
  const styleModeRules = `\u2550\u2550\u2550 COMPOSITION STYLE: FULL PAGE \u2550\u2550\u2550
\u2022 Design a full-canvas visualization with 2\u20134 named regions, each representing a distinct concept from the content.
\u2022 Choose ONE clear layout archetype and execute it rigorously: hierarchical (top-down tree with connecting lines), flow (left-to-right pipeline of labeled boxes), radial (central hub with spokes to labeled nodes), or grid (equal-weight labeled panels with consistent padding).
\u2022 STRICT GRID: maintain a minimum 80px safe margin from every canvas edge. Elements must align to shared horizontal and vertical baselines. Side-by-side items must share the same top y-coordinate. Vertically stacked items must share the same left x-coordinate.
\u2022 ZERO DECORATIVE SCATTER: no repeated icon copies, no background texture, no filler dots, no elements that don\u2019t directly represent a named concept from the content. If it has no label, it should not exist.
\u2022 NO ORPHAN ELEMENTS: Every SVG <circle>, <rect>, <path>, <line>, or <ellipse> must serve a named purpose in the diagram. Before writing each element ask: “what concept does this represent?” If the answer is “nothing — it’s decorative”, do not write it. Stray circles, floating dots, tiny accent shapes with no label are forbidden.
\u2022 Elements may be compositionally independent (connectors optional) but must feel placed by a deliberate graphic designer \u2014 balanced, symmetric, purposeful.
\u2022 Each major element gets its own staggered entrance animation so it can be trimmed independently in the AE timeline.

\u2550\u2550\u2550 DIAGRAM STYLE GUIDE \u2550\u2550\u2550
This guide applies when the content describes a HIERARCHICAL SYSTEM, ARCHITECTURE, ORG STRUCTURE, or TECHNICAL DIAGRAM.
For other content types (comparisons, timelines, abstract concepts) adapt freely — this guide is not universal.

\u25a0 LAYOUT PHILOSOPHY: NESTED CONTAINERS
The preferred pattern for hierarchical content is nested containers — a large outer box that groups related child cards.
This immediately communicates containment and ownership without needing arrows or labels to explain it.
Use this when the content has a "X contains Y, Y contains Z" structure.

\u25a0 OUTER CONTAINER (group/department/cluster level):
  \u2013 Large rect with 2px primary-colored border, very light fill (rgba of primary at 5-8% opacity, or #f7f8f7)
  \u2013 Section header: top-left inside the container — bold primary-colored title (22-28px bold) + supporting description below (18-20px, #555)
  \u2013 Optional NVIDIA icon: top-left of header row (24-32px), same color as title
  \u2013 Child cards arranged inside: horizontal row with consistent gap (24-32px between cards)
  \u2013 Container padding: 24px on all sides — children must never touch the container border

\u25a0 INNER CARD (node/project/item level):
  \u2013 Smaller rect inside the outer container: white or near-white fill (#fafafa), dark 1px border (#ccc or #999)
  \u2013 Card header: NVIDIA icon (20-24px) + bold title text in a row, left-aligned
  \u2013 Optional data rows below: icon strip for users, dot strip for resource counts (GPU dots, etc.)
  \u2013 Cards in a row MUST share the same top y-coordinate and equal width — compute: cardW = (containerW - 2*containerPad - (n-1)*gap) / n

\u25a0 COLOR HIERARCHY (3 levels):
  \u2013 Level 1 top node: primary color border + primary color bold text
  \u2013 Level 2 containers: secondary color border + secondary color bold text (or primary if no secondary)
  \u2013 Level 3 leaf cards: dark (#555-#999) border + dark (#222) text
  \u2013 NEVER mix border colors within the same level

\u25a0 CONNECTOR STYLE (between levels):
  \u2013 Single vertical stem from bottom of parent to branchY
  \u2013 Horizontal branch at branchY = parentBottom + gap*0.5
  \u2013 Vertical drops from branch to each child top
  \u2013 All connectors: 1-2px stroke, dark (#555) or primary color — match the child's border color
  \u2013 Draw-on animation: stem first, then branch left-to-right, then drops simultaneously

\u25a0 SIDE-BY-SIDE COMPARISON PANELS (two strategies, two options, two approaches):
  \u2013 Two equal-width panels side by side with a 24-32px gap between them
  \u2013 Each panel: primary-colored border (2px), light fill, bold all-caps or title-case header + subtitle
  \u2013 Both panels share the same top y, same height, same width — perfectly symmetric
  \u2013 Content inside each panel shows a concrete example of that strategy

\u25a0 DATA INDICATOR ROWS (inside cards, showing counts/quantities):
  \u2013 Small icon (16px) + count text on one row (e.g. GPU icon + "3 GPUs")
  \u2013 Or a row of N small filled dots/squares (8px each, 4px gap) representing discrete units
  \u2013 These rows sit below the card title with 8px vertical gap
  \u2013 Use NVIDIA icons for resource types whenever available

\u25a0 ANIMATION SEQUENCE FOR DIAGRAMS:
  1. Top-level node/title fades in (frames 0-20)
  2. Connector stem draws down (frames 20-40)
  3. Outer container border draws on (frames 40-70) then fill fades in
  4. Container header appears (frames 65-80)
  5. Child cards appear sequentially left-to-right (frames 80, 95, 110... +15 each)
  6. Data rows/indicators fill in after their card (card appear + 10 frames)
  7. Secondary sections (comparison panels etc.) start after primary section is complete + 30-frame pause

\u2550\u2550\u2550 ARCHETYPE RECIPE: PROCESS FLOW / PIPELINE \u2550\u2550\u2550
3-5 equal-width step boxes in a horizontal row. Each: step number (48px bold, primary), title (24-28px bold), description (20px). Connecting arrows between boxes. All boxes same top y, equal width = (availW - (n-1)*32)/n. Stagger entrances left-to-right.

\u2550\u2550\u2550 ARCHETYPE RECIPE: COMPARISON / TWO OPTIONS \u2550\u2550\u2550
Two equal-width panels side-by-side, same height, same top y, 24-32px gap. Primary border (2px). Bold header + content. Each panel scales from center independently.

\u2550\u2550\u2550 ARCHETYPE RECIPE: DATA / METRICS \u2550\u2550\u2550
Large hero numbers (80-120px, primary color) with count-up animation. Supporting label below each. 2-4 metrics in a row. Proportional bars when applicable.

\u2550\u2550\u2550 ARCHETYPE RECIPE: CONCEPT CARDS / BENEFITS \u2550\u2550\u2550
3-5 equal-weight cards in a row. Each: icon (40-60px) + title (24-28px bold) + description (20px). Same size, equal gaps. Diagonal stagger (col+row)*12 frames.

\u2550\u2550\u2550 ARCHETYPE RECIPE: TIMELINE \u2550\u2550\u2550
Horizontal line with milestone dots. Year/phase label above, event below. Line draws on first, dots pop in left-to-right.

\u2550\u2550\u2550 ARCHETYPE RECIPE: RADIAL / HUB-AND-SPOKE \u2550\u2550\u2550
Central hub circle (80px radius) at canvas center. N nodes at equal angles:
  const spokeR = Math.min(width/2-200, height/2-140);
  const angle_i = -Math.PI/2 + (2*Math.PI/N)*i;
  const nx = cx + spokeR*Math.cos(angle_i); const ny = cy + spokeR*Math.sin(angle_i);
Node boxes 200-260px wide. Hub-edge to node-edge connectors. Hub scales first, spokes draw staggered, nodes fade after their spoke.

`;
  // Background rules differ between alpha (transparent) and white-bg mode
  const bgRules = bgColor
    ? `\u2022 Background: The outermost AbsoluteFill will have its background set programmatically — do NOT set background or backgroundColor on it. All inner content may use fills/colors freely.`
    : `\u2022 TRANSPARENT CANVAS — ABSOLUTE RULE: This video is a transparent overlay that composites over a slide in Adobe After Effects. The canvas MUST be fully transparent. NEVER set background or backgroundColor on AbsoluteFill, wrapper divs, or any container element — not dark colors, not light colors, not white, not ANY color. Omit these properties entirely. The ONLY allowed fills are on explicit content shapes (SVG <rect>/<circle>/<path> elements, or intentional diagram UI components such as header bars, accent bars, and row backgrounds). Header bars inside panels (e.g. a solid primary-color bar at the top of a comparison panel) ARE allowed to have background set — they are explicit UI components, not wrapper containers. If you need a backdrop for a full card, use an SVG <rect> with fill — never a div backgroundColor on a wrapper. Violating this rule makes the entire composition unusable in AE.\n\u2022 ZERO white \u2014 never use #fff, #ffffff, 'white', rgb(255,255,255) for ANY CSS property (color, fill, stroke, background, backgroundColor, border). White is invisible on the white AE background and will ruin the composite.`;

  // ── Resolve layout directive ─────────────────────────────────────────────
  let renderClassification = null;
  if (!fixRequest) {
    if (modeOverride === 'creative') {
      renderClassification = { mode: 'creative', layoutType: null };
    } else if (modeOverride === 'faithful') {
      renderClassification = { mode: 'faithful', layoutType: null };
    } else if (modeOverride === 'diagram') {
      // diagram mode — always set classification so isDiagramMode is true and the
      // diagram user message / layout directive fire. layoutOverride may be null
      // (user picked "Diagram" without a sub-type) → use free-diagram so Claude
      // auto-selects the best archetype instead of getting the "reproduce faithfully" message.
      renderClassification = layoutOverride
        ? { mode: 'diagram', layoutType: layoutOverride }
        : { mode: 'free-diagram', layoutType: null };
    }
    if (renderClassification) {
      const modeLabel   = MODE_LABELS[renderClassification.mode] || renderClassification.mode;
      const layoutLabel = renderClassification.layoutType ? (LAYOUT_LABELS[renderClassification.layoutType] || renderClassification.layoutType) : null;
      const displayLabel = layoutLabel ? modeLabel + ' · ' + layoutLabel : modeLabel;
      process.stderr.write(JSON.stringify({ layout: renderClassification.mode, layoutLabel: displayLabel }) + '\n');
      log('Mode: ' + displayLabel, 'ok');
    }
  }
  const layoutDirectiveSection = buildRenderDirective(renderClassification);

  const noTextSection = noText ? `

\u2550\u2550\u2550 NO TEXT MODE — NON-NEGOTIABLE OVERRIDE \u2550\u2550\u2550
The user has explicitly enabled NO TEXT mode. You MUST omit every text element without exception:
• NO <text> SVG elements of any kind — no titles, no subtitles, no labels, no annotations, no captions, no legends, no numbers, no letters.
• NO Remotion text nodes, no string children in JSX, no {string} interpolation rendered as visible text.
• Render ONLY pure visual elements: shapes, lines, paths, fills, strokes, icons (SVG paths), geometric forms, color blocks.
• If the reference image contains text labels, reproduce the VISUAL STRUCTURE ONLY — omit the words entirely.
• This constraint overrides ALL other instructions. Any text element is a violation.` : '';


  const creativeBriefSection = (() => {
    if (!creativeBriefRaw || renderClassification?.mode !== 'creative') return '';
    const parts = [];
    if (creativeBriefRaw.archetype && ARCHETYPE_PARAMS[creativeBriefRaw.archetype])
      parts.push(ARCHETYPE_PARAMS[creativeBriefRaw.archetype]);
    if (creativeBriefRaw.mood && MOOD_PARAMS[creativeBriefRaw.mood])
      parts.push(MOOD_PARAMS[creativeBriefRaw.mood]);
    if (creativeBriefRaw.motion && MOTION_PARAMS[creativeBriefRaw.motion])
      parts.push(MOTION_PARAMS[creativeBriefRaw.motion]);
    if (creativeBriefRaw.directorNote && creativeBriefRaw.directorNote.trim())
      parts.push("DIRECTOR'S NOTE: Inspired by \"" + creativeBriefRaw.directorNote.trim() + "\". Study what makes this visually distinctive and apply those specific design sensibilities to this composition.");
    if (!parts.length) return '';
    return '\n\n═══ CREATIVE BRIEF PARAMETERS ═══\n' +
      'The user has provided specific creative direction. Follow each constraint precisely:\n\n' +
      parts.join('\n\n');
  })();

  const systemPrompt = `IMPORTANT — READ BEFORE ANYTHING ELSE: You are running in PURE CODE OUTPUT MODE.
• All tools are DISABLED. You cannot use Write, Edit, Bash, Read, Glob, Grep, or any other tool.
• If an image is attached: it is your visual reference, already decoded and ready. You do NOT need to locate any files, open any paths, or inspect any project structure. Everything you need is in this prompt and the attached image.
• Your ONLY job is to output TypeScript JSX code. Begin your response with "// TITLE: ..." and then the code. Nothing else.
• Do NOT write "I need to...", "Let me...", "First I'll...", or any planning/reasoning text. Output code immediately.

═══ ABSOLUTE BAN ON HEADLINES (HIGHEST PRIORITY — OVERRIDES EVERYTHING BELOW) ═══
NEVER render a main title, slide title, hero title, headline, page title, subtitle, or main heading anywhere in the composition. If the reference image or text content includes one, IGNORE it completely — do not transcribe, paraphrase, shorten, or echo it in any text element. Producers add ALL top-level titles and subtitles manually in After Effects after import — your only job is the visualization beneath them.

This rule overrides every other instruction below — including every render mode (Auto / Diagram / Faithful / Creative), every archetype recipe, and every "TEXT VERBATIM" directive. There are NO exceptions.

ALLOWED (these are NOT headlines — keep them as needed): per-card titles inside cards, per-step labels, per-row headers, per-section group headers inside a panel, data labels, axis labels, metric numbers, connector annotations, in-diagram captions.
BANNED: any text element that functions as the slide-level headline or subtitle — a large heading at the top of the canvas, a "title bar" across the top, a subtitle/tagline below such a heading, framing text like "What is X" / "How X works" / "Introduction to X" / "X explained". Even if the source has one, omit it. Shift the visualization up to fill the freed vertical space — do NOT leave an empty gap, placeholder, or blank container.

You are a senior motion designer at a world-class creative agency — the caliber that makes Apple product films, Nike brand campaigns, and top-selling Envato/Motion Array templates. You also enforce NVIDIA's brand system with absolute precision.

Your output must look like it was crafted by a human who obsesses over every frame. The standard is: if this appeared in an Apple keynote or a Motionographer featured piece, it would feel right at home.

CREATIVE BRIEF:
• Every composition tells ONE clear story. Identify the single most powerful visual idea and build the whole piece around it.
• Design with confidence. Big, bold, purposeful. Not timid infographics — cinematic visual communication.
• Motion serves meaning. Every animated element reveals information or creates emotion. Nothing moves without a reason.
• Restraint is sophistication. A composition with 4 perfectly crafted elements beats one with 12 mediocre ones every time.
• Typography is the hero when content demands it. Kinetic text done well is more powerful than any diagram.
• NVIDIA brand is non-negotiable: colors, font (NVIDIASans), and technical precision are always enforced.

Given a text description (and optionally a visual reference screenshot), generate a Remotion TSX component that would make a senior creative director proud.

\u2550\u2550\u2550 STEP 1: IDENTIFY THE CONTENT ARCHETYPE \u2550\u2550\u2550
Before designing anything, read the content and classify it into one archetype.
The archetype determines the layout, element types, and animation sequence.


DETECTION RULES (apply the FIRST match):
  HIERARCHICAL   \u2192 content shows containment / ownership ("X contains Y", org charts, cluster\u2192dept\u2192project)
  PROCESS FLOW   \u2192 content shows sequential steps ("Step 1\u20133", pipeline, "how it works", workflow)
  COMPARISON     \u2192 content shows two or more parallel options/strategies/approaches ("A vs B", "two ways")
  DATA / METRICS \u2192 content is primarily numbers, percentages, performance values, resource counts
  CONCEPT CARDS  \u2192 content is a list of parallel features, benefits, or capabilities (3\u20135 equal-weight items)
  TIMELINE       \u2192 content is chronological (years, versions, phases, milestones)
  RADIAL / HUB \u2192 content has ONE central concept with N surrounding topics or features radiating from it
  QUOTE / STATEMENT \u2192 content is a single strong message, principle, or definition (1\u20132 sentences)
  ABSTRACT / ART \u2192 content is a concept that needs a visual metaphor (no obvious diagram structure)

Each archetype has its own layout recipe below. Use the full-page layout recipes for all archetypes
except ABSTRACT / ART, which uses the single-object composition style.


\u2550\u2550\u2550 REFERENCE IMAGE USAGE (CRITICAL) \u2550\u2550\u2550
\u2022 The reference image is for CONCEPT EXTRACTION ONLY \u2014 understand the hierarchy, relationships, and structure of ideas, then design your own clean visualization.
\u2022 DO NOT recreate the reference image literally. Do not copy element positions, sizes, or decorative details from the reference slide.
\u2022 Ignore all decorative elements in the reference (background textures, repeated icon copies in corners, watermarks, slide borders, placeholder shapes, floating icons unconnected to content). Visualize only the named concepts.
\u2022 If the reference shows an icon floating in a corner or as a standalone background element — IGNORE IT entirely. Only place icons when they are semantic labels for a specific diagram node or card.

${styleModeRules}

\u2550\u2550\u2550 STYLE RULES \u2550\u2550\u2550
\u2022 2D vector/line art \u2014 clean geometric shapes, SVG-style path animations, minimal fills
\u2022 Primary color: ${primaryColor} \u2014 use for main highlights, key elements, section headers, and primary animated strokes
\u2022 Secondary color: ${secondaryColor ? secondaryColor : "one of the NVIDIA brand colors (Emerald rgb(0,133,100), CPU Blue rgb(0,113,197), Fluorite rgb(250,194,0), Amethyst rgb(93,22,130), Garnet rgb(137,12,88)) \u2014 pick whichever contrasts and complements the primary color"}
\u2022 Use primary color for emphasis, secondary color for supporting elements, labels, and visual variety. Always maintain a strict 2-color palette \u2014 NEVER introduce additional colors beyond primary + secondary + neutrals (white/black/#333/#555/#999). THIS IS NON-NEGOTIABLE. EXPLICITLY FORBIDDEN colors (never use these under any circumstances): red, #ff0000, #e74c3c, #c0392b, crimson, tomato, firebrick, orange, #f39c12, #e67e22, purple, #8e44ad, magenta, pink. If you need a third accent, pick from the NVIDIA secondary palette only.\n\u2022 PARALLEL CARDS / FLOW STEPS \u2014 COLOR RULE (NON-NEGOTIABLE): When a layout contains multiple parallel cards, flow boxes, or grid panels, ALL of them MUST share the same border color and the same number/title color. Do NOT assign a different hue to each card (e.g. card 1 red, card 2 green, card 3 yellow, card 4 blue). This rainbow-coding pattern is strictly forbidden \u2014 it is off-brand and looks like a generic infographic, not professional NVIDIA content. Every card in the same row uses the PRIMARY color for its border and step number.
${bgRules}
• CONTAINER FILL: Container shapes (outer boxes, cards, panels, section backgrounds) default to fill="none" (borders-only). Use a subtle fill ONLY when it meaningfully helps — to emphasize a key element, distinguish an active/highlighted state, or create visual hierarchy between nested containers.
• OCCLUSION RULE (MANDATORY): If a card or box visually overlaps any other element (circle, line, path, icon), it MUST have a solid opaque fill — fill="#ffffff" or fill="#fafafa" — so it properly covers whatever is behind it. A border-only box (fill="none") placed on top of a circle or line will show those elements through the card, which looks broken. Whenever a card is placed on top of or intersecting another element, give it a solid background. This is non-negotiable. When used: rgba of primary color at 4–8% opacity, or a near-white like #f7f8f7. Never fill all containers uniformly — fills lose their emphasis value when overused.
\u2022 Font: family "NVIDIASans" for all text (available at runtime)
• NVIDIA ICON SIZING IN LARGE SHAPES (MANDATORY): When an NVIDIA icon is the PRIMARY visual element inside a large container (box, card, or region ≥40% of canvas height or ≥300px tall), size it to fill 40–60% of the container's available height. NEVER use 20–48px icons inside large containers — they will look tiny and lost. Minimum 80px for icons inside mid-size cards (150-300px tall). Minimum 140px for icons inside large full-height sections. When in doubt: bigger is better for icons — they are the semantic anchor of the card.
\u2022 MINIMUM FONT SIZES (MANDATORY \u2014 this is VIDEO, not print): body text / list items \u226520px; supporting labels / subtitles \u226518px; section/panel headers \u226524px; card titles \u226522px; large emphasis numbers \u226548px. NEVER use 13-14px body text in any composition.
• NVIDIA COLOR PALETTE (MANDATORY — only these colors may appear in any composition):
  Neutrals: #000 / #111 / #222 / #333 (dark text/borders), rgb(205,205,205) (light gray), rgb(140,140,140) (medium gray), rgb(94,94,94) (dark gray)
  Brand accents (use as primary/secondary only): NVIDIA Green rgb(118,185,0) · Emerald rgb(0,133,100) · Amethyst rgb(93,22,130) · CPU Blue rgb(0,113,197) · Garnet rgb(137,12,88) · Fluorite rgb(250,194,0)
  ANY color outside this list is FORBIDDEN. No custom hex values, no teal, no coral, no sky blue, no orange, no red — only the exact NVIDIA palette values above.
• TEXT COLOR (CRITICAL — sharpness & readability): NEVER use grey or mid-tones for ANY text. Grey text (#555, #666, #777, #888, #999, #aaa, #bbb, gray, grey) is FORBIDDEN — it renders blurry and washed-out in video. ALL text must use ONLY:
  – Black or near-black: #000, #111, #222, #333 — for ALL text on white or transparent backgrounds (body text, labels, connector annotations, legends, descriptions)
  – White (#fff) — ONLY when the text sits directly on a dark-filled or brand-color-filled shape (e.g. white label inside a filled dark box)
  BRAND COLORS AS TEXT ON WHITE/TRANSPARENT BACKGROUND IS FORBIDDEN. Never use Garnet, Amethyst, Fluorite, Emerald, CPU Blue, NVIDIA Green, or any other bright/saturated color for text that renders against a white or transparent canvas. Connector labels, legend text, and annotations are always dark (#000/#111/#222/#333). Brand colors are for shapes, borders, strokes, and fills only — NOT for floating text.
  Where you previously would use #555 or #666 for "supporting" text, use #333 instead. Higher contrast = sharper text in video.
• OVERLAP PREVENTION (MANDATORY): Every text label for a connector/arrow must be positioned in the MIDDLE of the connector path, far from both endpoints. The label must never overlap any component box at either end. Enforce a minimum clearance of 20px from any box edge. If the connector is too short to fit a label without overlapping, OMIT the label entirely — do not place it anyway. For horizontal connectors: center the label vertically above the midpoint. For vertical connectors: center the label horizontally beside the midpoint. Never stack connector labels — if two connectors run parallel and close, offset one label left and the other right.

• BULLET MARKERS (DEFAULT: ROUNDED DOTS, NOT SQUARES): For bulleted lists or list-style markers next to items, use rounded filled dots — SVG <circle> with primaryColor fill, 6–8px radius. NEVER use filled squares (<rect>), ▪ / ■ Unicode characters, or rectangular blocks as bullet markers. Even if the source slide uses square bullets, convert them to rounded dots. Squares look generic and PowerPoint-y; rounded dots feel modern and intentional. Numbered lists (1., 2., 3.) use numeric badges, not bullet markers, and are not affected by this rule. Per-row icon markers (e.g. NVIDIA icons for items) are also not affected — this rule applies only to neutral list-bullets.

\u2550\u2550\u2550 LAYOUT DISCIPLINE (MANDATORY \u2014 READ BEFORE PLACING ANY ELEMENT) \u2550\u2550\u2550
These rules exist because overlapping elements and cramped layouts are the #1 quality failure. Violating them produces unusable output.

\u2022 CANVAS MARGINS: NEVER place any element (box, text, icon, line) within 48px of the canvas edge. Content lives in the safe zone: left=48, top=48, right=width-48, bottom=height-48. The sole exception: full-bleed background rects.

\u2022 ELEMENT GAP (NON-NEGOTIABLE): Minimum 24px clear gap between any two sibling elements — boxes, text blocks, icons, cards. If your math produces a gap smaller than 24px, you have too many elements. Remove one. Do NOT shrink the gaps.

\u2022 TEXT BREATHING ROOM: Minimum 8px padding inside any box before its text begins. Minimum 12px vertical gap between any two text lines in different elements. Text must NEVER touch a box border.

• BADGE / STEP-NUMBER CONTAINMENT (NON-NEGOTIABLE): A numbered circle, step badge, icon badge, or any label that is visually associated with a parent container (card, box, panel) MUST animate as a unit with that container. NEVER use translateY or translateX to slide a badge in from outside the parent’s bounds — it will visibly fly in from an unrelated part of the canvas. CORRECT approach: (1) fade in with opacity only, (2) scale from 0→1 centered on its final position, or (3) animate the entire parent container (box + badge together) as one group. If a badge overlaps the parent border (e.g. a circle on the top-left corner), its translateY start point must still be within ±20px of its final resting position — not 100+ px away. This rule also applies to connector dots, junction circles, and any decorative element attached to a specific parent shape.

• NO CIRCULAR WIPE ANIMATIONS (ABSOLUTE BAN): NEVER use strokeDashoffset animation on a <circle> or <ellipse>. This produces a "clock wipe" or "drawing on" circle effect that looks broken and amateur. Circles and ellipses must animate with opacity (0→1) or transform scale (0.8→1) only. strokeDashoffset is ONLY permitted on open paths and straight lines for draw-on connector effects.

• OFF-CANVAS ENTRANCE BAN: NEVER start any element’s entrance animation from a position more than ±80px outside its final resting place. translateX/Y entrance offsets larger than ±400px cause elements to visibly fly in from random corners of the screen. The correct range for subtle entrances: translateY ±20–30px (lift), translateX ±20–30px (slide). Badges, decorators, and icons attached to a parent: opacity-only entrance, zero translate.

\u2022 COMPUTE LAYOUT FIRST: Before writing any JSX, calculate and comment the layout:
  // Available width = width - 96 (margins)
  // 3 cards: cardW = (availableW - 2*gap) / 3  where gap >= 24
  // cardX[i] = 48 + i * (cardW + gap)
  Never eyeball coordinates. Always derive them from canvas dimensions via useVideoConfig().

\u2022 EQUAL SPACING: Same-level sibling elements MUST use identical gaps. Compute: gap = (availableSpace - totalElementSize) / (n + 1). Apply this gap uniformly — never unequal spacing between peers.

• CIRCULAR / RADIAL LAYOUT (MANDATORY whenever elements orbit a central shape or circle):
  These layouts are the #1 source of overlaps. Follow all three steps before writing any JSX.
  STEP 1 — Reserve the circle interior: no element’s bounding box may intrude inside the circle. Nearest edge of any element ≥ circleRadius + 32px from center.
  STEP 2 — Adjacent element collision check: for N elements placed at angles θ₀…θₙ₋₁, the arc gap between adjacent element EDGES (not centers) must be ≥24px. Arc gap = 2πR/N − elementSize. If arc gap < 24px, you must either increase R or reduce element size. Do the math — do not eyeball it.
  STEP 3 — Center text containment: any text placed at the circle center must fit entirely within the inner clear zone. maxTextWidth < 2*(circleRadius − 32px). If the text is multi-line, sum all line heights + gaps and confirm the total < 2*(circleRadius − 32px). If it doesn’t fit, reduce font size until it does. NEVER size center text by feel.
  STEP 4 — Write a layout comment block before the JSX: list each element’s (x, y, w, h) and confirm no two rects overlap and none intrude into the circle. If any overlap exists, fix it before proceeding.

• TEXT-IN-CONTAINER SIZING (MANDATORY — eliminates most overflow bugs):
  Every text node inside a container must fit the container’s inner width and height. Compute before writing:
    maxTextWidth = containerWidth − 2 * contentPadding
    fontSize ≤ maxTextWidth / (longestWordCharCount * 0.55)
  Hard caps: container ≤200px wide → title fontSize ≤36px. Container ≤300px wide → title fontSize ≤52px.
  For a single large-impact word filling a shape: measure the shape’s inner width, apply the formula, use that fontSize. Never start with a large font and hope it fits.
  overflow: hidden on containers does NOT fix overflow — it hides content. Text must fit. If it doesn’t fit, reduce font size or shorten the text — never rely on clipping.
  Multi-line text: after sizing each line, confirm cumulative height of all lines + line-gaps fits within containerHeight − 2*padding.

• TRAILING-LABEL OVERFLOW (CRITICAL — MOST COMMON CLIP BUG): When a label is placed to the RIGHT of a bar, row, or element, the total width of bar + gap + label text MUST fit within the safe zone. NEVER assume the label will fit — always budget for it explicitly:
  BAR CHART PATTERN:
    const labelW = 280;   // reserve enough for the longest label string
    const maxBarRight = width - margin - labelW - 16;  // 16px gap before label
    const barW = (value / maxValue) * (maxBarRight - barX);
    // label x = barX + barW + 16  → this is guaranteed inside the safe zone
  If a label cannot fit to the right, place it INSIDE the bar (right-aligned, white/contrast text) or below the bar.
  RIGHT-SIDE AXIS LABELS (e.g. scale ticks, category names): position them at width - margin, text-anchor="end". Never let their x exceed width - margin.
  VERTICAL RIGHT-SIDE LABELS: x must be ≤ width - 80. If an axis or bracket sits at the right edge, its label must be left of the axis, not right.

\u2022 DENSITY CAP: Maximum 7 primary visual elements in a single-phase composition. If the content demands more, group items into labeled clusters — show 3–4 clusters rather than 8+ individual items. One visual cluster = one idea. More elements = less communication.

\u2022 WHITESPACE IS DESIGN: Empty space is not wasted space. A composition with 5 well-spaced elements communicates better than one with 10 cramped ones. When in doubt, remove an element rather than squeezing to fit.
• AMBIENT / DECORATIVE ANIMATION (MANDATORY): Small decorative elements that have a natural continuous motion in real life MUST be animated with a looping cycle — not static. Examples: smoke/steam rising from chimneys → loop upward drift + fade; particles/data dots → loop float; pulsing indicators → loop opacity pulse; spinning gears/rotors → continuous rotation. Use frame % cycleLength to drive a seamless loop. These elements enrich the composition and signal "live system" vs "dead diagram".
\u2022 Motion: draw-on line animations, fade+translateY reveals, staggered appearance \u2014 NO bounce, NO elastic, NO CSS transitions, NO shake/earthquake effect
\u2022 Easing: ALL animated values MUST use Easing.inOut(Easing.ease) for smooth ease-in and ease-out. Never use linear easing for any visible motion.
\u2022 Pauses: if the visualization contains more than one main element or section, insert a 30\u201360 frame (1\u20132 second at 30fps) gap between each element\u2019s entrance sequence. Use Sequence startFrom or offsetStart values to stagger them so each element can be trimmed independently in the AE timeline.
• MULTI-PHASE STRUCTURE (MANDATORY when composition has 2+ distinct phases, scenes, or stages):
  STRICT PHASE ISOLATION — each phase is a self-contained video clip with hard frame boundaries:
  • PHASE START (frame = phaseStart): ALL elements of this phase MUST be at opacity 0 and their initial transform state. ZERO visible motion or opacity change on the canvas at phaseStart. Any element from a previous phase MUST ALSO be completely frozen (opacity at final value, no transform change) by phaseStart — not still animating out.
  • ANIMATE IN: elements reveal using the normal entrance sequence within this phase window.
  • FREEZE POINT (frame = phaseEnd): ALL animations for this phase are COMPLETE. Every element is at its final static value. No interpolate() call for any element in this phase may have an inputRange that extends past phaseEnd — clamp with extrapolateRight: 'clamp'.
  • HOLD (frames phaseEnd to phaseEnd+30): Completely dead canvas — zero motion anywhere. This 30-frame window is the AE editor's cut point.
  • IMPLEMENTATION RULE: For every element X in phase N, its opacity interpolate() call MUST use extrapolateLeft: 'clamp' (so it stays 0 before phaseStart) and extrapolateRight: 'clamp' (so it stays at final value after its animation ends, with no further changes). NEVER let an element's animation timeline extend into the next phase's window.
  • PHASE TRANSITION TEXT: When transitioning between phases that contain text elements in the same screen region, use OPACITY-ONLY transitions — no translateY, no slide. Overlapping text must cross-fade (phase A text fades out, phase B text fades in at the same position). SlideY on text that overlaps with other-phase text causes jarring visual collisions.

\u2550\u2550\u2550 CONTENT RULES \u2550\u2550\u2550
\u2022 NO NVIDIA LOGO OR WATERMARK (ABSOLUTE BAN): Never add any NVIDIA logo, wordmark, brand image, or watermark to the composition \u2014 not in any corner, not as a watermark, not anywhere. If the reference image has a logo, IGNORE IT. The composition contains only diagram content.
• NO SLIDE FOOTER TEXT (ABSOLUTE BAN): NEVER copy or reproduce any text that appears in the footer or watermark area of a reference slide — this includes "NVIDIA CONFIDENTIAL", "DO NOT DISTRIBUTE", legal notices, slide numbers, presenter notes, or any text not part of the diagram content itself. These must be completely ignored. The composition contains ONLY diagram content drawn from the described concepts.
• NO WHITE OR NEAR-WHITE TEXT (ABSOLUTE BAN): NEVER use white (#fff, #ffffff, "white"), near-white (#f0f0f0, #eeeeee, #e0e0e0, or any color with all RGB channels above 220) as a text color. White text on a white or transparent background is completely invisible. ALL text must use dark colors (#000, #111, #222, #333) or NVIDIA brand colors on dark backgrounds only.
\u2022 NO SIDE-CROP WIPE ON TEXT (ABSOLUTE BAN): NEVER use inset() left-to-right crop on text (e.g. clipPath: inset(0 X% 0 0)). It reveals letters from the side and looks clipped. Allowed: opacity fade, mask reveal (overflow:hidden translateY), tilt, slide, typewriter.
\u2022 NO main slide title or subtitle \u2014 the visualization stands alone without a header
\u2022 Include only content-specific labels, data annotations, and captions that are part of the visualization itself
\u2022 Labels should be concise and positioned close to the elements they describe
\u2022 NO ROW META-LABELS (MANDATORY): Never add floating labels on the left or right canvas margin that describe the organizational level of a diagram row (e.g., "Cluster Level", "Business Units", "Layer 1:", "Tier:", "Row:"). These clutter the composition and look amateurish. The hierarchy must be self-evident from the diagram structure itself. If a row needs a label, integrate it as part of the node/box design, not as a freestanding text element outside the diagram.
\u2022 CASING (NON-NEGOTIABLE): ALL text — section headers, labels, annotations, titles — must use Title Case or Sentence case. NEVER apply textTransform: 'uppercase' to any element (it uppercases all text indiscriminately). ACRONYMS EXCEPTION: Technology acronyms and initialisms must ALWAYS be written in ALL CAPS as string literals — e.g. GPU, CPU, RAM, VRAM, HBM, DGX, DGXC, NVLink, PCIe, AI, ML, DL, API, SDK, NVMe, DRAM, TPU, NPU, FPGA, HDD, SSD, LLM, NLP, CV. When mixed with regular words, keep the acronym uppercase and surrounding words in Title/Sentence case (e.g. "GPU Performance", "Multi-GPU Scaling", "AI Inference on DGX").
\u2022 LABEL BREVITY: Every text label must be 6 words or fewer. If the source content has longer descriptions, distill to the essential noun phrase. Long labels in a diagram = clutter.
\u2022 TEXT HIERARCHY CAP: Maximum 3 levels of text in any composition: (1) primary label / section header, (2) body / supporting label, (3) annotation / caption. Never introduce a 4th tier. If a level isn't needed, collapse it.

\u2550\u2550\u2550 REMOTION ADVANCED TECHNIQUES \u2550\u2550\u2550
\u25b6 SEQUENCE COMPONENT \u2014 for multi-phase compositions:
  import { Sequence, Series } from 'remotion';
  <Sequence from={60} durationInFrames={120} premountFor={30}><PhaseTwo /></Sequence>
  // Inside Sequence, useCurrentFrame() resets to 0. Always premountFor={fps}.

\u25b6 PATH ANIMATION (evolvePath) \u2014 for complex curved paths:
  import { evolvePath } from '@remotion/paths';
  const progress = interpolate(frame, [s, s+40], [0, 1], easeOut);
  const { strokeDasharray, strokeDashoffset } = evolvePath(progress, pathD);

\u25b6 EASING VARIETY:
  Easing.inOut(Easing.ease)    \u2192 default smooth
  Easing.out(Easing.quad)      \u2192 quick start, glides to rest
  Easing.bezier(0.22,1,0.36,1) \u2192 iOS-style premium ease-out
  spring({ damping: 200 })     \u2192 physically grounded, no bounce

\u2022 DURATION_FRAMES: ${userLengthFrames ? 'The user has specified an EXACT duration of ' + userLengthSec + 's = ' + userLengthFrames + ' frames. You MUST set export const DURATION_FRAMES = ' + userLengthFrames + '; \u2014 do not choose a different value. Complete ALL animations by frame ' + (userLengthFrames - 90) + ' and hold static for the last 90 frames.' : 'Choose based on content complexity and VO length: min 360 (12s), max 480 (16s). Short VO \u2192 360\u2013420. Standard \u2192 420\u2013450. Dense \u2192 480 max. Always export as: export const DURATION_FRAMES = <value>;'}
\u2022 All animations driven by useCurrentFrame() + useVideoConfig() \u2014 ZERO CSS transitions/animations
\u2022 Use interpolate() with extrapolateLeft: 'clamp', extrapolateRight: 'clamp' always
\u2022 Use spring() for decisive snaps, interpolate() for smooth progressions
\u2022 Allowed imports: "remotion" (including Img, staticFile), "react" \u2014 nothing else
\u2022 Export default the component function
\u2022 3-SECOND HOLD (MANDATORY): ALL animations must be FULLY COMPLETE by frame (DURATION_FRAMES - 90). The last 90 frames (3 seconds at 30fps) must be a completely STATIC FREEZE — zero motion, zero opacity changes, zero anything moving. This guarantees 3 seconds of clean still for the editor to cut from.
\u2022 NO ALL-CAPS TEXT (CRITICAL): It is forbidden to use textTransform: 'uppercase' anywhere in the code, or to write entire phrases/sentences in ALL CAPS. EXCEPTION: Individual acronyms and initialisms (GPU, CPU, RAM, AI, DGX, DGXC, etc.) must be written in ALL CAPS. A label like "GPU Performance" is correct; "SCALE UP PERFORMANCE" (full phrase in caps) is forbidden.
• MONOTONE INPUTRANGE (CRITICAL): interpolate() inputRange MUST be strictly increasing — every value must be GREATER THAN the previous. TWO CRASH PATTERNS TO AVOID:
  (A) LOOP CRASH: Never [start+i*step, fixedEnd] in a loop — crashes when start+i*step >= fixedEnd. Use relative: [start+i*step, start+i*step+duration].
  (B) DUPLICATE END CRASH: Never repeat DURATION_FRAMES twice: [x, y, DURATION_FRAMES, DURATION_FRAMES] CRASHES with "strictly monotonically increasing" error. For a last-phase element that fades in and stays: use just [phaseStart, phaseStart+20] with clamp. If 4 values needed: [phaseStart, phaseStart+20, DURATION_FRAMES-91, DURATION_FRAMES-90]. NEVER two consecutive equal values in any inputRange.

\u2550\u2550\u2550 DESIGN LANGUAGE \u2550\u2550\u2550
\u2022 Think: Apple product film meets NVIDIA technical precision. Clean, bold, confident. Every frame could be a still.
\u2022 ONE DOMINANT VISUAL: Each composition has one element that owns the canvas — larger, bolder, or more animated than everything else. Everything else is supporting cast.
\u2022 NEGATIVE SPACE IS POWER: Surround your hero element with breathing room. Crowding = amateur. Space = premium.
\u2022 LIGHT OVER DARK: Where possible, layer bright primary-color elements over dark backgrounds for maximum visual punch.
\u2022 Thin 1\u20133px strokes for structural elements, 3\u20135px for hero lines and accent strokes
\u2022 Geometric precision: every line is axis-aligned or intentionally angled — never accidentally diagonal
\u2022 CORNER RADIUS (MANDATORY): Maximum borderRadius is 2px for ALL elements — main containers, cards, nested sub-cards, badges, everything. Never use 4px, 8px, 12px, 16px or any other noticeable rounding. 2px gives a barely-perceptible softening that keeps the diagram looking technical and sharp. borderRadius: 2 is the only allowed value other than 0. If in doubt, use 0.
\u2022 Text: bold labels in Title Case or Sentence case using primary color, regular #222 body labels \u2014 NEVER all-caps (never use textTransform: 'uppercase', letterSpacing tricks, or manually write text in ALL CAPS). NEVER white text (invisible on white backgrounds)
\u2022 Shapes/borders: dark (#111, #222, #333, #444), primary, or secondary color \u2014 never white outlines, never white borders, never white connector lines
\u2022 Staggered reveal: elements appear in sequence tied to their conceptual order
\u2022 Draw-on effect for connecting lines: strokeDashoffset animated from full length \u2192 0

\u2550\u2550\u2550 MOTION VOCABULARY \u2014 TECHNIQUE REFERENCE \u2550\u2550\u2550
Choose 2-3 techniques max for the whole composition.

EASING SETUP (define once at top):
  const ease    = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.ease) };
  const easeOut = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.ease) };

\u25b6 TEXT ANIMATIONS \u2014 choose based on context.
  BANNED: inset() left-to-right crop wipe (clips visible letters). ALLOWED: all techniques below.

  FADE [diagram labels, card titles \u2014 safe default]:
    const op = interpolate(frame, [s, s+20], [0, 1], easeOut);
    const ty = interpolate(frame, [s, s+20], [8, 0], easeOut);
    style={{ opacity: op, transform: \`translateY(\${ty}px)\` }}

  FADE + TILT UP [hero labels, section titles \u2014 adds energy to a simple fade]:
    const op  = interpolate(frame, [s, s+22], [0, 1], easeOut);
    const rot = interpolate(frame, [s, s+22], [12, 0], easeOut);   // degrees
    style={{ opacity: op, transform: \`perspective(600px) rotateX(\${rot}deg)\`, transformOrigin: 'center bottom' }}
    // Tilt DOWN (for elements entering from above): rotateX from -12 \u2192 0

  SLIDE LEFT or RIGHT [callouts, annotations, supporting panels entering from off-canvas]:
    const op = interpolate(frame, [s, s+22], [0, 1], easeOut);
    const tx = interpolate(frame, [s, s+22], [48, 0], easeOut);   // positive = from right; negative = from left
    style={{ opacity: op, transform: \`translateX(\${tx}px)\` }}

  MASK REVEAL \u2014 HTML [elegant, professional: text slides up from behind a clean baseline. Use for hero titles, lower-thirds, cinematic labels]:
    // Wrapper clips the text. Text slides up INTO the visible area from below \u2014 no letter is ever cropped mid-reveal.
    <div style={{ overflow: 'hidden', height: lineH }}>
      {(() => { const ty = interpolate(frame, [s, s+24], [lineH, 0], easeOut); return (
        <div style={{ transform: \`translateY(\${ty}px)\` }}>{text}</div>
      ); })()}
    </div>
    // For staggered multi-line: each line gets its own wrapper + offset start frame (s + lineIndex*8)
    // TILT variant: combine translateY with rotateX for a 3D lift-into-view:
    style={{ transform: \`translateY(\${ty}px) perspective(400px) rotateX(\${rot}deg)\`, transformOrigin: 'center bottom' }}

  MASK REVEAL \u2014 SVG [same effect for SVG <text> nodes]:
    // clipPath defines a horizontal band at the text\u2019s final position. Text translates UP into it.
    <defs><clipPath id={\`mask-\${id}\`}><rect x={x-8} y={textY - lineH} width={textW+16} height={lineH} /></clipPath></defs>
    {(() => { const ty = interpolate(frame, [s, s+24], [lineH, 0], easeOut); return (
      <g clipPath={\`url(#mask-\${id})\`}>
        <text x={x} y={textY} transform={\`translate(0, \${ty})\`} ...>{label}</text>
      </g>
    ); })()}
    // The clipPath rect height = lineH (one line). Text never appears partially cropped \u2014 it\u2019s either hidden (below) or fully visible (in the band).

  TYPEWRITER [quote/statement, terminal-style, bold single message]:
    const chars = Math.floor(interpolate(frame, [s, s + text.length * 2], [0, text.length], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }));
    const displayed = text.slice(0, chars);  // NEVER per-character opacity

  WORD HIGHLIGHT [emphasizing a key word after it appears \u2014 definitions, bold statements]:
    const hl = interpolate(frame, [s, s+18], [0, 1], easeOut);
    const estimatedWordW = word.length * fontSize * 0.58;
    // SVG underline bar:  <rect x={wordX} y={wordBaselineY+4} width={estimatedWordW * hl} height={3} fill={primaryColor} />
    // HTML background:    style={{ background: \`linear-gradient(transparent 60%, \${primaryColor}55 60%)\`, backgroundSize: \`\${hl*100}% 100%\`, backgroundRepeat: 'no-repeat' }}

\u25b6 SCALE FROM CENTER [icons, badges, nodes]:
  const sc = interpolate(frame, [s, s+16], [0, 1], easeOut);
  style={{ transform: \`scale(\${sc})\`, transformOrigin: 'center center' }}

\u25b6 BORDER DRAW-ON [cards/boxes \u2014 deliberately constructed feel]:
  4 SVG lines: top(L\u2192R), right(T\u2192B), bottom(R\u2192L), left(B\u2192T). Each starts 10f after previous ends.

\u25b6 COUNT-UP NUMBER [data values \u2014 always animate instead of static]:
  const val = Math.round(interpolate(frame, [s, s+30], [0, targetValue], easeOut));

\u25b6 BAR GROW [quotas, metrics \u2014 width MUST be proportional to value]:
  const barW = interpolate(frame, [s, s+25], [0, maxBarW * (value / maxValue)], easeOut);
  style={{ width: barW }}

\u25b6 SPRING PHYSICS [decisive natural entrances \u2014 icons, nodes]:
  import { spring } from 'remotion'; const { fps } = useVideoConfig();
  const sc = spring({ frame: frame - s, fps, config: { damping: 200 } });
  style={{ transform: \`scale(\${sc})\` }}

\u25b6 STAGGER CASCADE [N equal items in sequence]: delay[i] = baseStart + i * 12.

\u2550\u2550\u2550 MOTION DESIGN HIERARCHY (MANDATORY) \u2550\u2550\u2550
\u2022 HERO FIRST: Most important element animates first, largest, most deliberate.
\u2022 SEQUENCING: Reveal in narrative order. Min 12-frame stagger between elements.
\u2022 ONE THING AT A TIME: Max 2-3 elements animating simultaneously.
\u2022 TECHNIQUE RESTRAINT: 2-3 techniques max for the whole composition. No 6+ mixed styles.
\u2022 Finish all animations by DURATION_FRAMES-90. Hold last 90 frames completely static.
\u2022 NO ANIMATION NOISE: Never animate background gradients, static borders, or unchanged values.
\u2022 HTML/SVG SEPARATION: <Img> can only be used in HTML context. For images inside SVG use <image href>. Never mix HTML opacity with SVG opacity on the same element.

\u2550\u2550\u2550 SHAPE COMPLETENESS (MANDATORY) \u2550\u2550\u2550
\u2022 Every shape fully drawn. SVG paths close with Z when needed. No disconnected segments.
\u2022 ANIMATION START: Lines/draw-on elements MUST be invisible at frame 0. Initialize strokeDashoffset = totalLen.

\u2550\u2550\u2550 ARROWS & CONNECTORS (MANDATORY) \u2550\u2550\u2550
\u2022 NEVER USE SVG <marker> OR marker-end: Use <polyline> arrowheads only. <defs>/<marker>/marker-end are BANNED.
\u2022 CONNECTOR ENDPOINTS: Lines start at source BORDER and end at arrowhead TIP. Never inside boxes.

\u2022 HIERARCHICAL TREE CONNECTOR \u2014 3-SEGMENT PATTERN:
  branchY = parentBottomY + (childTopY - parentBottomY) * 0.5
  Stem: x1={parentCx} y1={parentBottomY} x2={parentCx} y2={branchY}
  Branch: x1={child1Cx} y1={branchY} x2={child2Cx} y2={branchY}
  Drop: x1={childCx} y1={branchY} x2={childCx} y2={childTopY - arrowGap}
  arrowGap=6. Arrowhead tip: (childCx, childTopY-6)

\u2022 ARROWHEAD STYLE (CRITICAL): Always use OPEN <polyline>: fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round". NEVER <polygon> or marker-end.
  Down  (tip tx,ty): points={\`\${tx-7},\${ty-12} \${tx},\${ty} \${tx+7},\${ty-12}\`}
  Up    (tip tx,ty): points={\`\${tx-7},\${ty+12} \${tx},\${ty} \${tx+7},\${ty+12}\`}
  Right (tip tx,ty): points={\`\${tx-12},\${ty-7} \${tx},\${ty} \${tx-12},\${ty+7}\`}
  Left  (tip tx,ty): points={\`\${tx+12},\${ty-7} \${tx},\${ty} \${tx+12},\${ty+7}\`}
  ARROWHEAD GAP: tip is 6px from box edge. Line endpoint = arrowhead tip. NEVER end line at V-base (12px behind tip).

\u2022 ARROWHEAD TIMING: Arrowhead has own opacity:
  const lineDrawEnd = lineStart + lineDuration;
  const lineDash = totalLen - interpolate(frame, [lineStart, lineDrawEnd], [0, totalLen], ease);
  const arrowOp = interpolate(frame, [lineDrawEnd, lineDrawEnd+8], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });

\u2022 STROKEDASHARRAY: totalLen = Math.abs(x2-x1)+Math.abs(y2-y1). lineDash = totalLen - interpolate(frame,[s,s+dur],[0,totalLen],ease);

\u2022 HORIZONTAL ARROW (left-to-right \u2014 COPY THIS):
  const tipX = rightBoxX - 6; const len = tipX - leftBoxRightEdge;
  <line x1={leftBoxRightEdge} y1={arrowY} x2={tipX} y2={arrowY} stroke={color} strokeWidth={2} strokeDasharray={len} strokeDashoffset={len - interpolate(frame,[s,s+dur],[0,len],ease)} />
  <polyline points={\`\${tipX-12},\${arrowY-7} \${tipX},\${arrowY} \${tipX-12},\${arrowY+7}\`} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" opacity={arrowOp} />

\u2022 VERTICAL ARROW (top-to-bottom \u2014 COPY THIS):
  const tipY = bottomBoxTopY - 6; const len = tipY - topBoxBottomY;
  <line x1={cx} y1={topBoxBottomY} x2={cx} y2={tipY} stroke={color} strokeWidth={2} strokeDasharray={len} strokeDashoffset={len - interpolate(frame,[s,s+dur],[0,len],ease)} />
  <polyline points={\`\${cx-7},\${tipY-12} \${cx},\${tipY} \${cx+7},\${tipY-12}\`} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" opacity={arrowOp} />

\u2022 DIAGONAL ARROW (non-axis-aligned \u2014 COPY THIS):
  dx=targetEdgeX-sourceEdgeX; dy=targetEdgeY-sourceEdgeY; dist=Math.sqrt(dx*dx+dy*dy); ux=dx/dist; uy=dy/dist;
  tipX=targetEdgeX; tipY=targetEdgeY; wingBaseX=tipX-ux*12; wingBaseY=tipY-uy*12; perpX=-uy*7; perpY=ux*7;
  <line x1={sourceEdgeX} y1={sourceEdgeY} x2={tipX} y2={tipY} strokeDasharray={dist} strokeDashoffset={dist - interpolate(frame,[s,s+dur],[0,dist],ease)} />
  <polyline points={\`\${wingBaseX+perpX},\${wingBaseY+perpY} \${tipX},\${tipY} \${wingBaseX-perpX},\${wingBaseY-perpY}\`} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" opacity={arrowOp} />

\u2022 NO UNICODE ARROW GLYPHS: Never use \u2193\u2191\u2192\u2190 as visual elements. All arrows = SVG <polyline>.
\u2022 NO STRAY CONNECTORS: Every line must connect two named elements. No endpoint in empty space.
\u2022 NO TRAVELING DOT ON CONNECTORS: Do not animate a dot traveling along a connector.
\u2022 PREFER ELBOW CONNECTORS for elements at different heights: vertical + horizontal + vertical. Diagonals only when elbow would be too short.

\u2022 CONNECTOR CLEARANCE (MANDATORY): Connectors route ONLY through empty space \u2014 never through box interiors, text, or icons. x1/y1 and x2/y2 MUST be on the BOX BORDER, never inside.
\u2022 NO CONNECTOR LABELS: Never place text on or next to a connector line. Integrate labels inside connected boxes.

\u2550\u2550\u2550 LAYOUT & ALIGNMENT (MANDATORY) \u2550\u2550\u2550
\u2022 All coordinates in multiples of 8px. Canvas safe zone: 80px margin from every edge.
\u2022 Sibling elements at same level share the same top y and equal spacing.
\u2022 COMPUTE LAYOUT FIRST: derive all positions from width/height via useVideoConfig(). Never hardcode coordinates.
\u2022 ELEMENT GAP: minimum 24px between any two sibling elements. If spacing < 24px, remove an element.
\u2022 BOX CONTENT CENTERING (MANDATORY): SVG text in box at (bx,by,bw,bh): x={bx+bw/2} textAnchor="middle", y={by+bh/2} dominantBaseline="middle". Icon+label row: totalRowW=iconSize+gap+textW; iconX=bx+(bw-totalRowW)/2; labelX=iconX+iconSize+gap.
\u2022 BOX INNER PADDING: all child content satisfies bx+16 \u2264 x \u2264 bx+bw-16, by+16 \u2264 y \u2264 by+bh-16.
\u2022 ICONS BELONG INSIDE THEIR BOX: icon coords must satisfy bx\u2264iconX\u2264bx+bw, by\u2264iconY\u2264by+bh.
\u2022 PROPORTIONAL BARS: barW = maxBarW * (value/maxValue). NEVER equal widths for unequal values.
\u2022 VERTICAL CANVAS FILL: bottommost element y+h \u2265 height*0.75. Fill 75-90% of canvas.
\u2022 NO FLOATING COLOR LEGENDS: integrate color labels inline next to elements, not as a separate legend box.
\u2022 COUNT-UP: only for large meaningful data values. Never count 0\u21921 or small step numbers.


\u2550\u2550\u2550 CANONICAL EXAMPLE (study this pattern \u2014 always follow it) \u2550\u2550\u2550
The example below demonstrates ALL mandatory patterns in correct working code.
Follow this structure for coordinate math, centering, connectors, and arrowheads:

export const DURATION_FRAMES = 360;
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, Easing } from 'remotion';

export default function AbstractorComp() {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig(); // ALWAYS destructure — never hardcode 1920/1080

  // ── Layout constants (multiples of 8px) ────────────────────────────────────
  const bw = 320, bh = 80;
  const parentX = width / 2 - bw / 2,  parentY = 160;
  const childX  = width / 2 - bw / 2,  childY  = 360;
  const color   = 'rgb(118,185,0)';

  // ── Box entry animations ────────────────────────────────────────────────────
  const ease = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.ease) };
  const parentOp = interpolate(frame, [0, 18], [0, 1], ease);
  const childOp  = interpolate(frame, [24, 42], [0, 1], ease);

  // ── Connector: parent bottom-center → child top-center ─────────────────────
  const pCx      = parentX + bw / 2;
  const pBottomY = parentY + bh;
  const cCx      = childX + bw / 2;
  const cTopY    = childY;
  // Arrow geometry: tip 6px above child box, line ends AT the tip
  const arrowGap = 6;
  const tipY     = cTopY - arrowGap;   // tip stops 6px above child box border
  const lineLen  = tipY - pBottomY;    // line spans parent-bottom → tip
  const lineStart = 20, lineDuration = 18, lineDrawEnd = lineStart + lineDuration;
  const lineDash  = lineLen - interpolate(frame, [lineStart, lineDrawEnd], [0, lineLen], ease);
  const arrowOp   = interpolate(frame, [lineDrawEnd, lineDrawEnd + 8], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });

  // ── Arrowhead: tip at (cCx, tipY). Wings branch BACK from tip. Line ends at tip. ──
  const tx = cCx, ty = tipY;

  // ── Box content centering ───────────────────────────────────────────────────
  // text-only box: x = bx + bw/2, y = by + bh/2, textAnchor="middle", dominantBaseline="middle"
  // icon+label row: totalRowW = iconSize + gap + textW; iconX = bx+(bw-totalRowW)/2; labelX = iconX+iconSize+gap

  return (
    <AbsoluteFill>
      <svg width={width} height={height}>
        {/* Parent box */}
        <rect x={parentX} y={parentY} width={bw} height={bh} rx={0} fill="none" stroke={color} strokeWidth={2} opacity={parentOp} />
        <text x={parentX + bw / 2} y={parentY + bh / 2} textAnchor="middle" dominantBaseline="middle"
              fill={color} fontSize={22} fontWeight="bold" opacity={parentOp}>GPU Pool</text>

        {/* Connector line — ends AT the tip (line endpoint = arrowhead tip = shared point) */}
        <line x1={pCx} y1={pBottomY} x2={tx} y2={ty}
              stroke={color} strokeWidth={2} strokeDasharray={lineLen} strokeDashoffset={lineDash} />

        {/* Open V arrowhead: wings branch BACK from tip. Tip point is shared with line endpoint. */}
        <polyline points={\`\${tx - 7},\${ty - 12} \${tx},\${ty} \${tx + 7},\${ty - 12}\`}
                  fill="none" stroke={color} strokeWidth={2}
                  strokeLinecap="round" strokeLinejoin="round" opacity={arrowOp} />

        {/* Child box */}
        <rect x={childX} y={childY} width={bw} height={bh} rx={0} fill="none" stroke="#4a90d9" strokeWidth={2} opacity={childOp} />
        <text x={childX + bw / 2} y={childY + bh / 2} textAnchor="middle" dominantBaseline="middle"
              fill="#ffffff" fontSize={20} opacity={childOp}>Department A</text>
      </svg>
    </AbsoluteFill>
  );
}

CRITICAL: Do NOT use <Composition>, registerRoot(), or any Remotion root-level APIs. The file must export ONLY a single default React component function. Remotion composition registration is handled externally.

OUTPUT FORMAT — MANDATORY:
The very first line of your response MUST be a title comment in this exact format:
// TITLE: WordOne WordTwo
Rules: 1–3 words, CamelCase, no spaces (use underscores if needed), describes the animation content. Examples: "GPU_Architecture", "Data_Pipeline", "Network_Topology", "Inference_Flow".
This line will be stripped before the code is used — it does NOT affect the component.

Return ONLY the TypeScript JSX code (starting with the // TITLE line). No markdown fences, no explanations, no extra text.${noTextSection}${layoutDirectiveSection}${iconLibrarySection}${lottieLibrarySection}${assetPromptSection}${creativeBriefSection}${animationPrefsSection}${historyManager.buildFewShotSection()}`;

  const isCreativeRender = renderClassification && renderClassification.mode === 'creative';
  const isDiagramMode    = renderClassification && (renderClassification.mode === 'diagram' || renderClassification.mode === 'free-diagram');
  const isFaithfulMode   = renderClassification && renderClassification.mode === 'faithful';
  const userMessage = imagePath
    ? isCreativeRender
      ? `The attached image shows the concept being visualized. This is CREATIVE MODE.\n\nDO NOT reproduce the slide layout, bullet list, or text structure from the image.\nUnderstand WHAT this content is about, then create an original expressive motion graphic that captures its essence.\nThe animation should feel like a cinematic motion-design piece \u2014 NOT a slide or diagram recreation.\nUse bold typography, kinetic shapes, abstract metaphors, color, or dynamic composition.\nAsk yourself: what ONE visual idea makes this concept unforgettable? Build around that.\n\nContent description:\n${textContent}\n\nOutput the // TITLE: line followed immediately by the complete TypeScript JSX code. No preamble, no tool calls, no explanations.`
      : isDiagramMode
      ? `The reference image is provided as a content reference. Read the item labels, group names, and counts from the image.\n\nYOUR TASK IS TO BUILD A DIAGRAM — NOT to reproduce the slide. The image tells you WHAT to show; the MANDATORY LAYOUT DIRECTIVE below tells you HOW to show it.\n\n${layoutDirectiveSection.trim()}\n\nALL item labels from the image must appear in the diagram, verbatim, inside the visual structure described above.\nItem and group counts must match the image exactly.\n${noText ? 'NO TEXT MODE: render structure and shapes only, no text labels.\n' : ''}\nNO MAIN SLIDE TITLE (ABSOLUTE BAN): Never render the slide\'s main heading. If the image has a large title at the top, ignore it entirely. The diagram stands alone.\n\nANIMATION CHOREOGRAPHY — POLISHED MOTION DESIGN (MANDATORY):\nThe animation must feel like intentional, professional motion design — not a slide transition. Use this exact 4-phase sequence:\n\nPHASE 1 — Containers arrive (frames 0–28):\n  Side-by-side panels: LEFT slides in from translateX(-50px) + opacity 0→1. RIGHT from translateX(+50px) + opacity 0→1.\n  NO SCALE on main panels — large containers must NOT scale. Translate + opacity only.\n  spring({ frame, fps, config: { damping: 200 }, durationInFrames: 28 }) for left.\n  spring({ frame: frame-10, fps, config: { damping: 200 }, durationInFrames: 28 }) for right (10f stagger).\n  Single panel/list: spring translateY(30→0) + opacity only — NO scale.\n\nPHASE 2 — Section headers reveal (frames 10–30, overlapping with Phase 1 for energy):\n  Each panel\'s group header (e.g. "Single Node Tests"): translateY(18→0) + opacity.\n  Use interpolate with Easing.out(Easing.ease), 18 frames. Start 10f into its parent\'s entrance.\n  Sub-header / tagline below it: same pattern, 4-frame delay after the title.\n\nPHASE 3 — Item rows cascade in (frames 30+, after panels have landed):\n  Each row card: spring({ damping: 200, durationInFrames: 22 }) translateY(20→0) + opacity.\n  Stagger: rowDelay = 30 + rowIndex * 10 frames (left column), rowDelay = 40 + rowIndex * 10 (right column).\n  Accent bar (left border highlight): animate height 0→full OR opacity 0→1 with 4-frame delay after its row.\n  Row label text: translateY(10→0) + opacity, Easing.out(Easing.ease), 14 frames, inline with row entrance.\n  Row description text: same, 3-frame delay after label.\n\nPHASE 4 — Icons pop in (6 frames after their parent row):\n  Each icon: spring({ damping: 20, stiffness: 200, durationInFrames: 16 }) scale(0→1) + opacity.\n  This gives a quick snappy pop that adds life without distracting.\n  Connector element (if any, e.g. diamond between panels): scale(0→1) + opacity, spring({ damping: 200 }), frame 26.\n\nSECONDARY MOTION after all elements have entered:\n  Add one subtle ambient loop to signal "live": e.g. the connector pulses opacity (0.6→1, loop every 60f),\n  or accent bars gently pulse brightness, or a thin progress line draws itself. Keep it subtle.\n\nMINIMUM BAR: Every bordered container, every section title, every row, every icon MUST have its own entrance animation using the patterns above. Nothing may simply appear at frame 0 or use opacity-only fade.\n\nMANDATORY ICON PLACEMENT IN ITEM ROWS:\n  Each row: display:\'flex\', flexDirection:\'row\', alignItems:\'center\', gap:16.\n  Icon (Img, 36px, flexShrink:0) LEFT. Text block (bold label + smaller description) RIGHT.\n  Icons vertically centered — never below text, never in a corner.\n\nContent description: ${textContent}\n\nOutput the // TITLE: line followed immediately by the complete TypeScript JSX code. No preamble, no tool calls, no explanations.`
      : isFaithfulMode
      ? `The attached image shows the slide to animate. This is FAITHFUL MODE — your job is to animate the slide as-is, not redesign it.${noText ? '\n\nNO TEXT MODE IS ACTIVE: Reproduce the visual layout and shapes only — render zero text nodes.' : ''}\n\nSTEP 1 — CLASSIFY THE SLIDE before writing any code:\n  A) VISUAL SLIDE: has boxes, panels, diagrams, icons, shapes, arrows, or color-coded sections → preserve the existing visual structure exactly.\n  B) TEXT SLIDE: primarily bullet points, numbered lists, section headers with plain text underneath → elevate to visual framing: one bordered container per section, section title as header, items as structured rows. No floating unstyled text.\n\nFAITHFUL MODE RULES (apply to both types):\n1. LAYOUT: vertical source stays vertical. Side-by-side source stays side-by-side. Never rearrange or reinterpret the layout.\n2. ELEMENTS: every group, section, box, and visual relationship from the source must appear. Item counts match exactly.\n3. TEXT VERBATIM (EXCEPT THE HEADLINE): include every label AND every description word-for-word — EXCEPT the slide’s main title and subtitle, which are NEVER rendered. Never shorten or drop a description. Label + description → both appear.\n4. ONE COLOR: use only primaryColor for all borders, headers, accents, and label text. The reference may show multiple colors — ignore them.\n5. CANVAS: content centered horizontally. First group starts ~20% from the top. Never push to left edge.\n6. NO INTRO TEXT: do not render any floating body sentence above the main groups.\n7. NO BACKGROUND FILLS: containers are borders-only. No tints.\n8. MOTION DESIGN: full professional animation — spring entrances, stagger, mask reveals, opacity+translate. Every element has its own entrance. Nothing appears at frame 0.\n9. NO INVENTED ELEMENTS: no shapes, icons, or decorations not present in the source.\n10. NO MAIN SLIDE TITLE OR SUBTITLE: never render the slide's top-level heading or subtitle — producers add titles in After Effects.\n\nContent description: ${textContent}\n\nOutput the // TITLE: line followed immediately by the complete TypeScript JSX code. No preamble, no tool calls, no explanations.`
      : `The attached image is your CONTENT SOURCE. REDESIGN it as a professional motion graphic — choose the best layout for this content.\n\nSTEP 1 — COUNT: before writing any code, count every named item, step, and group in the image. State the count. Render that exact count. Missing items = failure.\nSTEP 2 — CHOOSE: pick the single best layout archetype: comparison | list | architecture | flow | metrics | timeline | steps | hierarchy.\nSTEP 3 — BUILD: construct a clean, polished diagram using that archetype.\n\nCONTENT RULES (no exceptions):\n• NO MAIN SLIDE TITLE (ABSOLUTE BAN): never render the slide's heading, title, or subtitle. The diagram stands alone.\n• NO INVENTED DECORATIONS: every element must be directly visible in the source image. No extra shapes, dots, or embellishments not in the source.\n• ALL TEXT VERBATIM: copy labels word-for-word. Do not shorten or paraphrase.\n• EXACT ITEM COUNT: count first, then build. If source shows 6 steps, render 6 steps. Never drop items.\n• LAYOUT: redesign the structure, but intentionally — not randomly.\n• Full 4-phase animation choreography (containers → headers → rows/items → icons).${noText ? '\n• NO TEXT MODE: render structure and shapes only, no text labels.\\n' : ''}\nContent description: ${textContent}\n\nOutput the // TITLE: line followed immediately by the complete TypeScript JSX code. No preamble, no tool calls, no explanations.`
    : textContent ? `Content description:\n\n${textContent}\n\nGenerate a clean, professional Remotion TSX animation that visualizes this concept. Do NOT include a main title or subtitle \u2014 only the visualization with its internal labels.` : `Generate a clean, professional NVIDIA-branded Remotion TSX animation. Choose a compelling data visualization, architecture diagram, or motion graphic appropriate for a tech keynote. Do NOT include a main title or subtitle \u2014 only the visualization with its internal labels.`;

  // ── 4. Call Claude ─────────────────────────────────────────────────────────
  // Fun rotating messages while Claude thinks (can take 2-5 min)
  const waitMessages = [
    'Whispering the prompt to Claude Opus…',
    'The tractor is harvesting at 30fps…',
    'We’re building something here…',
    'Comp is under construction…',
    'Claude is storyboarding in the dark…',
    'Drawing lines between ideas…',
    'Keyframes are being invented…',
    'Easing curves are being calibrated…',
    'Motion design happens at the speed of thought…',
    'SVG paths are plotting their trajectories…',
    'Opacity values are being carefully considered…',
    'The creative director is reviewing…',
  ];
  let waitMsgIdx = 0;
  progress(0.12, waitMessages[0]);
  const waitInterval = setInterval(() => {
    waitMsgIdx = (waitMsgIdx + 1) % waitMessages.length;
    progress(0.12, waitMessages[waitMsgIdx]);
  }, 16000);

  let generatedCode;
  try {
  generatedCode = await callClaudeWithRetry(systemPrompt, imageBase64, imageMediaType, userMessage);
  } catch (e) {
    clearInterval(waitInterval);
    log('Claude API error: ' + e.message, 'err');
    log('This is usually a transient issue. Wait a moment and try again.', 'err');
    process.exit(6);
  }

  // ── 5. Clean and validate generated code ──────────────────────────────────
  progress(0.40, 'Claude delivered — inspecting the goods…');

  // Parse // TITLE: from raw output BEFORE extractCode (which may skip comment lines)
  // Regex is case-insensitive in case Claude outputs "// Title:" or "// title:"
  const titleLineMatch = generatedCode.match(/\/\/\s*TITLE:\s*(.+)/i);
  let derivedTitle = '';
  if (titleLineMatch) {
    derivedTitle = titleLineMatch[1].trim()
      .replace(/\s+/g, '_')
      .replace(/[^A-Za-z0-9_-]/g, '')
      .slice(0, 40);
    log('Title from Claude: ' + derivedTitle, 'ok');
  }
  // Fallback: derive from the user's text prompt (first 3–4 meaningful words)
  if (!derivedTitle && textContent) {
    const words = textContent
      .replace(/[^a-zA-Z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 2)
      .slice(0, 4);
    if (words.length > 0) {
      derivedTitle = words.map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('_').slice(0, 40);
      log('Title derived from prompt: ' + derivedTitle, 'ok');
    }
  }
  if (derivedTitle) process.stderr.write(JSON.stringify({ title: derivedTitle }) + '\n');

  generatedCode = extractCode(generatedCode);
  // Strip // TITLE: line if it survived into the extracted code
  generatedCode = generatedCode.replace(/^\/\/ TITLE:.*\n?/m, '');

  // ── Code sanity check: reject prose output ─────────────────────────────────
  // If Claude returned prose instead of code (e.g. "I need to locate the project..."),
  // the extractCode() fallback will have returned the raw text. Detect and abort early
  // rather than writing invalid prose to AbstractorComp.tsx (which causes esbuild crash).
  const hasImport  = /\bimport\b/.test(generatedCode);
  const hasExport  = /export\s+(default\s+function|default\s+class|const\s+\w)/.test(generatedCode);
  const proseStart = /^(I\s+(need|will|want|should|can|would|am)|Let\s+me|First[,\s]|To\s+(create|generate|build|design)|Looking\s+at|The\s+(reference|image|slide|content)|Based\s+on)/i.test(generatedCode.trim());
  if (!hasImport || !hasExport || proseStart) {
    log('Claude returned prose instead of code. First 300 chars: ' + generatedCode.slice(0, 300), 'err');
    log('Hint: Claude may be in "tool-use" reasoning mode. This is a known issue when images are provided.', 'err');
    process.exit(4);
  }

  // Strip any Claude skill/tool invocation lines that leak into generated code
  // (e.g. "import { Skill } from '#tools'; await Skill.remotion_best_practices();")
  generatedCode = generatedCode
    .split('\n')
    .filter(line => {
      const t = line.trim();
      return !(
        t.startsWith("import { Skill }") ||
        t.startsWith("await Skill.") ||
        t.includes("from '#tools'") ||
        t.includes('from "#tools"')
      );
    })
    .join('\n')
    .replace(/^(\s*\n)+/, ''); // trim leading blank lines

  // Set DURATION_FRAMES: exact if user specified --length, else clamp Claude's choice to [450,1800]
  const durationMatch = generatedCode.match(/export\s+const\s+DURATION_FRAMES\s*=\s*(\d+)/);
  let durationFrames = userLengthFrames || 360;
  if (userLengthFrames) {
    // Exact: override whatever Claude wrote
    if (durationMatch) {
      generatedCode = generatedCode.replace(
        /export\s+const\s+DURATION_FRAMES\s*=\s*\d+/,
        'export const DURATION_FRAMES = ' + userLengthFrames
      );
    } else {
      generatedCode = 'export const DURATION_FRAMES = ' + userLengthFrames + ';\n\n' + generatedCode;
    }
    log('Duration locked: ' + userLengthSec + 's = ' + userLengthFrames + ' frames', 'ok');
  } else {
    if (durationMatch) {
      const df = Math.min(480, Math.max(90, parseInt(durationMatch[1], 10)));
      durationFrames = df;
      generatedCode = generatedCode.replace(
        /export\s+const\s+DURATION_FRAMES\s*=\s*\d+/,
        'export const DURATION_FRAMES = ' + df
      );
    } else {
      generatedCode = 'export const DURATION_FRAMES = 360;\n\n' + generatedCode;
      log('Warning: DURATION_FRAMES not found — prepended 360');
    }
  }

  // ── Auto-patch duplicate DURATION_FRAMES in interpolate inputRange ─────────
  // Catches the crash: interpolate(frame, [x, y, DF, DF], ...) -> [x, y]
  generatedCode = generatedCode.replace(
    /interpolate\((frame|[^,]+),\s*\[([^\]]*?),\s*DURATION_FRAMES,\s*DURATION_FRAMES\s*\]\s*,\s*\[([^\]]+)\]/g,
    (match, frameVar, rangeStart, outputVals) => {
      // Trim the last two output values (the hold pair) to match the shortened inputRange
      const outParts = outputVals.split(',').map(v => v.trim());
      const shortOut = outParts.slice(0, Math.min(outParts.length, 2));
      // Also trim inputRange to just the first two values
      const inParts = rangeStart.split(',').map(v => v.trim()).filter(Boolean);
      const shortIn = inParts.slice(0, 2);
      log('Auto-patched duplicate DURATION_FRAMES in inputRange: ' + match.slice(0, 80) + '…', 'ok');
      return 'interpolate(' + frameVar + ', [' + shortIn.join(', ') + '], [' + shortOut.join(', ') + ']';
    }
  );

    // ── Background injection or stripping ────────────────────────────────────
  if (bgColor) {
    // Solid bg chosen: inject the color onto the first AbsoluteFill, strip others
    let injected = false;
    generatedCode = generatedCode.replace(/<AbsoluteFill(\s+style=\{\{|\s*>|\s*\n)/,
      (m, suffix) => {
        if (injected) return m;
        injected = true;
        if (suffix.includes('style={{')) return `<AbsoluteFill style={{ background: '${bgColor}', `;
        return `<AbsoluteFill style={{ background: '${bgColor}' }}>`;
      }
    );
    log(`Background injected: ${bgColor}`, 'ok');
  }

  // ── Strip non-transparent backgrounds (transparent-alpha video only) ──────
  if (!bgColor) {
    // Alpha (transparent) mode — strip ALL non-transparent background/backgroundColor values.
    // This is a transparent AE overlay; any background color makes it unusable.
    let strippedBg = 0;
    // Variable names that are intentional UI fills — never strip these
    const SAFE_BG_VARS = new Set(['primaryColor', 'bg', 'bgColor', 'headerBg', 'rowBg', 'cardBg', 'fillColor', 'accentColor']);
    function isSafeBackground(raw) {
      const v = raw.replace(/['"]/g, '').trim().toLowerCase();
      return v === 'transparent' || v === 'none' || v === 'unset' || v === 'initial' || v === 'inherit';
    }
    // Quoted background values: background: 'color' or background: "color"
    generatedCode = generatedCode.replace(
      /\b(background(?:Color)?)\s*:\s*('[^']*'|"[^"]*")/gi,
      (match, prop, val) => {
        if (isSafeBackground(val)) return match;
        strippedBg++;
        return `${prop}: 'transparent'`;
      }
    );
    // Unquoted single-token values: background: someVar or background: #hex
    // Preserve known intentional fill variables (header bars, row backgrounds, etc.)
    generatedCode = generatedCode.replace(
      /\b(background(?:Color)?)\s*:\s*([A-Za-z_$][A-Za-z0-9_$]*|#[0-9a-fA-F]{3,8})\b/gi,
      (match, prop, val) => {
        if (isSafeBackground(val) || SAFE_BG_VARS.has(val)) return match;
        strippedBg++;
        return `${prop}: 'transparent'`;
      }
    );
    // Strip all literal rgb()/rgba() background values — no exceptions.
    // Row/item tints in scaffolds use a variable name (e.g. background:bg) which is
    // protected by SAFE_BG_VARS, so those are never literal rgba strings here.
    generatedCode = generatedCode.replace(
      /\b(background(?:Color)?)\s*:\s*(rgba?\([^)]*\))/gi,
      (match, prop) => { strippedBg++; return `${prop}: 'transparent'`; }
    );
    if (strippedBg > 0) log(`Stripped ${strippedBg} non-transparent background(s)`, 'ok');

    // Strip SVG fill="white" / fill="#fff"
    generatedCode = generatedCode
      .replace(/\bfill=["'](?:#[fFeEcCdD]{3,6}|white|snow|ivory)["']/gi, 'fill="none"')
      .replace(/\b(fill\s*:\s*)('[^']*'|"[^"]*"|#[fFeEcCdD]{3,6}|white)/gi, (m, p, v) =>
        /^['"]?(#[fFeEcCdD]{3,6}|white|snow|ivory)['"]?$/i.test(v.trim()) ? `${p}'none'` : m
      );
  }

  // ── 5b. Strip forbidden patterns ──────────────────────────────────────────

  // (a) Remove textTransform: 'uppercase' — always forbidden in generated animations
  const capsCount = (generatedCode.match(/textTransform\s*:\s*['"`]uppercase['"`]/gi) || []).length;
  if (capsCount > 0) {
    generatedCode = generatedCode.replace(
      /textTransform\s*:\s*(['"`])uppercase\1(\s*as\s+const)?/gi,
      "textTransform: 'none'"
    );
    log(`Stripped ${capsCount} textTransform:uppercase instance(s)`, 'ok');
  }

  // (b) Convert ALL-CAPS multi-char string literals to Title Case.
  //     Targets display strings ≥ 5 chars (e.g. "SIGNAL", "SCALE-UP: MULTI-GPU")
  //     while leaving short abbreviations (GPU, CPU, API) untouched.
  function toTitleCase(s) {
    return s.toLowerCase().replace(/(^|[\s\-:\/])([a-z])/g, (_, sep, c) => sep + c.toUpperCase());
  }
  let titleCaseCount = 0;
  generatedCode = generatedCode.replace(
    /(["'])([A-Z][A-Z :\-\/&,\.]{4,})\1/g,
    (_match, q, s) => {
      titleCaseCount++;
      return q + toTitleCase(s) + q;
    }
  );
  if (titleCaseCount > 0) log(`Converted ${titleCaseCount} ALL-CAPS string(s) to Title Case`, 'ok');

  // (c) Strip SVG marker-end / marker-start — they render at frame 0 and cannot be
  //     controlled by JS, causing arrowheads to appear before their lines.
  const markerCount = (generatedCode.match(/marker-(?:end|start)\s*=\s*\{?["'][^"']*["']\}?/g) || []).length;
  if (markerCount > 0) {
    generatedCode = generatedCode
      .replace(/\s*marker-(?:end|start)\s*=\s*\{?["'][^"']*["']\}?/g, '')
      .replace(/<defs>[\s\S]*?<\/defs>/g, (block) => block.includes('<marker') ? '' : block);
    log(`Stripped ${markerCount} marker-end/marker-start attribute(s) — use explicit polyline arrowheads instead`, 'ok');
  }


  // (d) Strip slide-footer strings (CONFIDENTIAL, DO NOT DISTRIBUTE) — surgical removal
  //     so they never reach the renderer even if the auto-fix didn't fire.
  {
    const before = generatedCode.length;
    // Remove any JS/JSX string literal that contains these phrases
    generatedCode = generatedCode
      .replace(/(['"`])[^\'\`"]*(?:CONFIDENTIAL|DO NOT DISTRIBUTE)[^\'\`"]*\1/gi, "''")
      // Remove 'NVIDIA.' standalone (wordmark reproduced from slide footer)
      .replace(/(['"`])NVIDIA\.(['"`])/g, "''")
      // Remove staticFile refs to any nvidia logo/wordmark SVG
      .replace(/staticFile\(['"`][^'"`]*nvidia[_\-]?(?:logo|wordmark|brand)[^'"`]*['"`]\)/gi, "staticFile('assets/icons/m48-nvidia-shield.svg')");
    if (generatedCode.length !== before) log('Stripped slide-footer / logo strings', 'ok');
  }

  // ── 5a-ii. Strip invalid NVIDIA icon references (hallucinated filenames) ──────
  if (validIconNames.size > 0) {
    const codeLines = generatedCode.split('\n');
    let badIconCount = 0;
    const invalidFound = [];
    const cleanedLines = codeLines.map(codeLine => {
      const iconMatch = codeLine.match(/staticFile\(['"']assets\/icons\/([^'"']+)['"']\)/);
      if (iconMatch && !validIconNames.has(iconMatch[1])) {
        invalidFound.push(iconMatch[1]);
        badIconCount++;
        return `      {/* icon removed: '${iconMatch[1]}' not in NVIDIA icon library */}`;
      }
      return codeLine;
    });
    if (badIconCount > 0) {
      generatedCode = cleanedLines.join('\n');
      log(`Stripped ${badIconCount} invalid icon reference(s): ${[...new Set(invalidFound)].join(', ')}`, 'warn');
    }
  }


  // ── 5b. Post-generation validation + auto-fix (1 retry) ────────────────────
  // Fast text-scan for known failure patterns before we spend time rendering.
  // If violations found, send the code back to Claude with a targeted fix prompt.
  function detectViolations(code) {
    const issues = [];
    // Filled polygon arrowheads (should be open polyline)
    if (/<polygon[\s>]/.test(code)) {
      issues.push('Uses <polygon> for arrowheads — must be <polyline fill="none"> instead (open V-shape, not filled triangle)');
    }
    // Closed filled path used as arrowhead (path ending with Z without fill="none")
    const closedFilledPaths = (code.match(/<path[^>]*d=["'][^"']*Z[^"']*["'][^>]*>/g) || [])
      .filter(p => !/fill\s*=\s*["']none["']/.test(p) && !/fill\s*=\s*\{.*none.*\}/.test(p));
    if (closedFilledPaths.length > 0) {
      issues.push('Uses closed <path d="...Z"> without fill="none" — likely a filled arrowhead. Use <polyline fill="none"> for arrowheads instead');
    }
    // Unicode arrow characters used as visual elements in text
    if (/<text[^>]*>[^<]*[\u2190-\u21FF\u27A0-\u27BF][^<]*<\/text>/.test(code)) {
      issues.push('Uses Unicode arrow characters (→ ← ↑ ↓ etc.) in <text> — forbidden. Use <polyline> SVG arrowheads instead');
    }
    // Hardcoded canvas dimensions
    if (/[^a-zA-Z"'](1920|1080)[^a-zA-Z0-9"']/.test(code)) {
      issues.push('Hardcodes 1920 or 1080 as pixel values — must use width/height from useVideoConfig() instead');
    }
    // Uppercase text transform
    if (/textTransform\s*:\s*['"]uppercase['"]/.test(code)) {
      issues.push('Uses textTransform: "uppercase" — forbidden. Write text in Title Case directly');
    }
    // marker-end left in code (belt-and-suspenders, we strip it anyway but flag it)
    if (/marker-(?:end|start)\s*=/.test(code)) {
      issues.push('Uses SVG marker-end/marker-start — forbidden. Use explicit <polyline> arrowheads');
    }
    // Decorative diamond / lozenge / suit shapes (stray orphan elements)
    if (/[◇◆♦⬦⬧⬨]/.test(code) || /<text[^>]*>[^<]*[◇◆♦⬦⬧⬨][^<]*<\/text>/.test(code)) {
      issues.push('Contains decorative diamond/lozenge Unicode character — orphan element with no semantic purpose. Remove it.');
    }
    // Connector node / bridge element between comparison panels — forbidden
    if (/connector|bridge.*node|node.*bridge|hasConnector/i.test(code) ||
        /nodeX\s*=\s*.*PanelRight|leftPanelRight\s*\+/i.test(code)) {
      issues.push('Contains a connector/bridge node between panels — this is forbidden in comparison layouts. Remove the connector element entirely. The gap between the two panels must be empty.');
    }
    // delayRender / continueRender — causes 28s timeout crash, all animation must be synchronous
    if (/delayRender\s*\(/.test(code) || /continueRender\s*\(/.test(code)) {
      issues.push('Uses delayRender() or continueRender() — FORBIDDEN. These cause render timeout crashes. Remove all delayRender()/continueRender() calls. All animation must be driven purely by useCurrentFrame(). Replace any async image/font loading with synchronous staticFile() references or remove it entirely.');
    }
    // Img component inside SVG element (crashes with current.decode error)
    {
      let svgDepth = 0;
      let imgInSvg = false;
      for (const ln of code.split('\n')) {
        svgDepth += (ln.match(/<svg[\s>]/g) || []).length;
        svgDepth -= (ln.match(/<\/svg>/g) || []).length;
        if (svgDepth > 0 && /<Img[\s/]/.test(ln)) { imgInSvg = true; break; }
      }
      if (imgInSvg) issues.push('<Img> component placed inside <svg> or <g> element — HTML elements cannot be rendered inside SVG. Move all <Img> components outside the <svg> tag and use position:absolute on a div instead. Leaving <Img> inside SVG causes current.decode crash.');
    }
    // Very small font sizes (< 18) — below video minimum
    {
      const fontMatches = [...code.matchAll(/fontSize[=:\s\{'"]*(\d+)/g)].map(m => parseInt(m[1], 10)).filter(n => n > 0 && n < 18);
      if (fontMatches.length > 0) {
        issues.push(`Found ${fontMatches.length} font size(s) below 18px (values: ${[...new Set(fontMatches)].join(', ')}) — minimum is 18px for labels, 20px for body text, 22px for card titles, 24px for headers. Increase all small fontSize values.`);
      }
    }
    // Hardcoded small font size via style prop: fontSize: 12 (catches CSS-in-JS)
    {
      const cssSmall = [...code.matchAll(/fontSize\s*:\s*(\d+)/g)].map(m => parseInt(m[1],10)).filter(n=>n>0&&n<18);
      if (cssSmall.length > 0) {
        issues.push(`CSS fontSize below 18px found (${[...new Set(cssSmall)].join(', ')}) — must be ≥18px for all text in video compositions.`);
      }
    }
    // Filled polygon arrowhead (already checked above, but also catch lowercase)
    if (/<polygon[\s>]/i.test(code) && !issues.some(i => i.includes('polygon'))) {
      issues.push('Uses <polygon> — must be <polyline fill="none"> for arrowheads (open V-shape, not filled triangle)');
    }
    // Duplicate consecutive values in interpolate() inputRange — causes "strictly monotonically increasing" crash
    {
      const dupeRanges = [...code.matchAll(/interpolate\s*\([^,]+,\s*\[([^\]]+)\]/g)];
      for (const m of dupeRanges) {
        const vals = m[1].split(',').map(v => v.trim());
        for (let i = 1; i < vals.length; i++) {
          if (vals[i] === vals[i-1] || (vals[i].includes('DURATION_FRAMES') && vals[i-1].includes('DURATION_FRAMES'))) {
            issues.push(
              'interpolate() has duplicate consecutive values in inputRange: [' + vals.join(', ') + '] — ' +
              'this crashes with "strictly monotonically increasing" error. ' +
              'For a last-phase element that stays visible, use just [phaseStart, phaseStart+20] with clamp. ' +
              'NEVER repeat DURATION_FRAMES twice: use [p4Start, p4Start+20, DURATION_FRAMES-91, DURATION_FRAMES-90] or simply [p4Start, p4Start+20].'
            );
            break;
          }
        }
      }
    }

    // White or near-white text color — invisible on white/transparent canvas
    if (/color\s*:\s*['"](?:white|#fff|#ffffff|#f0f0f0|#eeeeee|#e0e0e0)['"]/i.test(code)) {
      issues.push('Uses white or near-white text color (white/#fff/#ffffff) — completely invisible on white/transparent background. Replace with #000, #111, #222, or #333 for body text, or use a dark background behind the text.');
    }
    // Confidential/footer text copied from reference slide
    if (/CONFIDENTIAL|DO NOT DISTRIBUTE/i.test(code)) {
      issues.push('Contains slide footer/watermark text ("CONFIDENTIAL" or "DO NOT DISTRIBUTE") — this must never appear in the composition. Remove these text elements entirely.');
    }
    // NVIDIA logo file references — banned in all compositions
    if (/nvidia[_\-]?logo|nvidia\.(?:svg|png)/i.test(code)) {
      issues.push('References an NVIDIA logo file — logos are absolutely banned in Abstractor compositions. Remove any NVIDIA logo, wordmark, or brand image.');
    }
    // Bar chart without label-budget guard — labels will overflow right edge
    if (/barW|barWidth|rectWidth|fillWidth/.test(code) && !/labelW|labelWidth|maxBarRight|labelBudget/.test(code)) {
      issues.push('Bar chart detected without label-width budget: labels placed to the right of bars will overflow the canvas. Reserve space for the longest label before computing bar width. Pattern: const labelW = 280; const maxBarRight = width - margin - labelW - 16; barW = (value/max) * (maxBarRight - barStartX); labelX = barStartX + barW + 16.');
    }
    // Wrong Lottie import path — component is in src/generated/, Lottie files are in src/lottie/
    if (/from ['"]\.\/lottie\//.test(code)) {
      issues.push("Lottie import uses wrong path './lottie/...' — component lives in src/generated/ so the correct path is '../lottie/...'. Replace all './lottie/' with '../lottie/' in import statements.");
    }
    // Circular wipe: strokeDashoffset on <circle> or <ellipse> — looks broken
    {
      const lines = code.split('\n');
      for (let i = 0; i < lines.length; i++) {
        if (/<(?:circle|ellipse)[\s>]/.test(lines[i])) {
          const win = lines.slice(i, i + 8).join(' ');
          if (/strokeDashoffset/.test(win)) {
            issues.push('strokeDashoffset used on a <circle> or <ellipse> — this creates a broken "circular wipe" animation. NEVER animate stroke-dashoffset on closed shapes. Use opacity fade-in or scale(0.8→1) instead.');
            break;
          }
        }
      }
    }
    // Off-canvas entrance: translateX/Y starting offset > 400px — flies in from nowhere
    {
      const offCanvas = [...code.matchAll(/translate[XY]\s*:\s*interpolate\s*\([^,]+,\s*\[[^\]]+\],\s*\[([^\]]+)\]/g)];
      for (const m of offCanvas) {
        const vals = m[1].split(',').map(v => parseFloat(v.trim())).filter(n => !isNaN(n));
        const bad = vals.find(v => Math.abs(v) > 400);
        if (bad !== undefined) {
          issues.push(`Element has a translateX/Y entrance offset of ${bad}px — this flies in from far outside the canvas. Maximum allowed entrance offset is ±80px. Use opacity fade-in instead, or keep translate within ±30px for subtle lift.`);
          break;
        }
      }
    }
    // Main / hero / slide title or subtitle variable — ABSOLUTE BAN (producers add titles in AE)
    {
      const titleVarPattern = /(?:const|let|var)\s+(?:main|slide|hero|page|big|primary|composition|comp)(?:Title|Heading|Headline|Subtitle|Subhead)\s*=/i;
      const titleConstPattern = /(?:const|let|var)\s+(?:TITLE|HEADING|HEADLINE|SUBTITLE|MAIN_TITLE|SLIDE_TITLE|HERO_TITLE|MAIN_HEADING|MAIN_SUBTITLE|PAGE_TITLE)\s*=/;
      const titleJsxComment = /\{\s*\/\*\s*(?:main|slide|hero|page)?\s*(?:title|heading|headline|subtitle)\s*\*\/\s*\}/i;
      if (titleVarPattern.test(code) || titleConstPattern.test(code) || titleJsxComment.test(code)) {
        issues.push('Defines a main/slide/hero title or subtitle variable — Abstractor must NEVER render top-level headlines or subtitles. Remove the title/subtitle element entirely (variable, JSX, and animation). Shift the visualization up to fill the freed space. Producers add ALL titles and subtitles manually in After Effects after import.');
      }
    }
    return issues;
  }

  const violations = detectViolations(generatedCode);
  if (violations.length > 0) {
    log(`Validation found ${violations.length} issue(s) — requesting auto-fix from Claude…`, 'warn');
    violations.forEach(v => log('  • ' + v, 'warn'));
    progress(0.43, `Auto-fixing ${violations.length} issue(s)…`);

    const fixSystemPrompt = `You are fixing broken Remotion TSX code. Apply ONLY the listed fixes — do not change anything else. IMPORTANT: You MUST return the COMPLETE corrected TypeScript file — every single line, nothing omitted. Do not output a diff, do not output just the changed lines, do not explain. Output the entire file from first import to last closing brace. No markdown fences. The file must start with import/export statements and include the full export default function.`;
    const fixUserMessage = `Fix the following issues in this Remotion component:\n\n${violations.map((v, i) => `${i + 1}. ${v}`).join('\n')}\n\nCode to fix:\n\n${generatedCode}`;

    try {
      let fixedCode = await callClaudeWithRetry(fixSystemPrompt, null, null, fixUserMessage);
      fixedCode = extractCode(fixedCode);
      // Force DURATION_FRAMES again in case fix call changed it
      const fixDfMatch = fixedCode.match(/export\s+const\s+DURATION_FRAMES\s*=\s*(\d+)/);
      if (fixDfMatch) {
        const fixDf = Math.min(480, Math.max(90, parseInt(fixDfMatch[1], 10)));
        fixedCode = fixedCode.replace(/export\s+const\s+DURATION_FRAMES\s*=\s*\d+/, 'export const DURATION_FRAMES = ' + fixDf);
      }
      const hasDefaultExport = /export\s+default\s+function/.test(fixedCode);
      const isCompleteFile   = fixedCode.length >= generatedCode.length * 0.6;
      if (!hasDefaultExport || !isCompleteFile) {
        log(`Auto-fix returned incomplete code (${fixedCode.length} chars, hasDefault=${hasDefaultExport}) — discarding fix, keeping original`, 'warn');
      } else {
        const remainingViolations = detectViolations(fixedCode);
        if (remainingViolations.length < violations.length) {
          generatedCode = fixedCode;
          log(`Auto-fix applied — ${violations.length - remainingViolations.length}/${violations.length} issue(s) resolved`, 'ok');
        } else {
          log('Auto-fix did not improve violations — proceeding with original (render may still succeed)', 'warn');
        }
      }
    } catch (fixErr) {
      log('Auto-fix call failed: ' + fixErr.message + ' — proceeding with original', 'warn');
    }
  } else {
    log('Validation passed — no issues detected', 'ok');
  }

  // ── 6. Write component to Remotion project ─────────────────────────────────
  progress(0.45, 'Wiring up the Remotion component…');

  // Ensure a default export exists — Root.tsx imports `default as AbstractorComp`
  // Must find a PascalCase component name (e.g. HouseWithGreenDoor), NOT constants like DURATION_FRAMES
  if (!/export\s+default\s+/.test(generatedCode)) {
    // Match PascalCase names only: starts uppercase, has at least one lowercase letter
    const namedMatch = generatedCode.match(/export\s+(?:const|function|class)\s+([A-Z][a-z][A-Za-z0-9]*)/);
    if (namedMatch) {
      generatedCode += `\nexport default ${namedMatch[1]};\n`;
      log('Injected missing default export: ' + namedMatch[1], 'warn');
    }
  }

  const generatedDir = path.join(remotionDir, 'src', 'generated');
  fs.mkdirSync(generatedDir, { recursive: true });
  const compPath = path.join(generatedDir, 'AbstractorComp.tsx');
  fs.writeFileSync(compPath, generatedCode, 'utf8');
  log('Component written → ' + compPath, 'ok');

  // Save TSX snapshot alongside .mov so render history can fix past renders
  if (outputPath) {
    const snapshotPath = outputPath.replace(/\.mov$/i, '.tsx');
    try {
      fs.writeFileSync(snapshotPath, generatedCode, 'utf8');
    } catch (e) {
      log('Warning: could not write TSX snapshot: ' + e.message, 'warn');
    }
  }

  // ── 7. Render with Remotion ─────────────────────────────────────────────────
  const chunkLabel = durationFrames > 750
    ? `${Math.ceil(durationFrames / 350)} chunks × 350 frames (OOM-safe)`
    : 'single pass';
  progress(0.50, `Firing up the Remotion tractor (${durationFrames} frames, ${chunkLabel})…`);
  log(`Starting Remotion render — ${durationFrames} frames, ${chunkLabel}`);

  // Use @remotion/cli/remotion-cli.js directly to avoid broken .bin/ symlinks after cp -r
  const remotionCliScript = path.join(remotionDir, 'node_modules', '@remotion', 'cli', 'remotion-cli.js');
  const nodeBin = process.execPath; // absolute path to current node binary

  const RENDER_FIXABLE = [
    'inputRange must contain only numbers',
    'strictly monotonically increasing',
    'ReferenceError',
    'TypeError',
    'is not defined',
    'Cannot read propert',
    'outputRange must contain only numbers',
    'Expected identifier',
    'Transform failed',
    'Module build failed',
    'SyntaxError',
    'Unexpected token',
    'is not a function',
    'Cannot destructure',
    'delayRender',
    'not cleared',
  ];

  let renderErr = null;
  await renderComposition({
    outputPath, bgColor, durationFrames,
    remotionDir, remotionCliScript, nodeBin, quality4k,
    log, progress,
    progressStart: 0.55, progressEnd: 0.93,
  }).catch((e) => { renderErr = e; });

  if (renderErr) {
    const errText = (renderErr.remotionErrorLine || renderErr.message || '');
    const fullOutput = renderErr.remotionOutput || '';
    const isFixable = RENDER_FIXABLE.some(p => errText.includes(p)) ||
                      RENDER_FIXABLE.some(p => fullOutput.includes(p));

    if (isFixable) {
      log(`Render crashed: "${errText}" — attempting auto-fix…`, 'warn');
      progress(0.55, 'Render crashed — asking Claude to fix the runtime error…');

      const compPath = path.join(generatedDir, 'AbstractorComp.tsx');
      const brokenCode = fs.readFileSync(compPath, 'utf8');
      const isDelayRenderCrash = errText.includes('delayRender') || fullOutput.includes('delayRender') || fullOutput.includes('not cleared');
      const renderFixPrompt = isDelayRenderCrash
        ? `You are a Remotion TSX code editor. The component crashed because a delayRender() was never cleared — typically caused by <Img> (from 'remotion') trying to load an image that could not be fetched, or by an explicit delayRender() call that was never resolved.\n\nFix ALL of the following:\n1. Replace every <Img> import and usage from 'remotion' with a CSS background-image div — this is the ONLY approach that never triggers delayRender. Pattern: <div style={{ width:W, height:H, backgroundImage:\`url(\${staticFile('path')})\`, backgroundSize:'contain', backgroundRepeat:'no-repeat', backgroundPosition:'center' }} />. Remove the 'Img' import from 'remotion' entirely.\n2. Remove any explicit delayRender() / continueRender() calls.\n3. Remove any fetch(), useEffect(), or async data-loading logic.\n\nDo NOT use <Composition>, registerRoot(), or any Remotion root-level APIs — export ONLY the default component function.\n\nReturn the COMPLETE corrected TypeScript JSX file. No explanations, no markdown fences, no partial snippets — the full file only.`
        : `You are a Remotion TSX code editor. The component below crashed at render time with this error:\n\n${errText}\n\nFix ONLY the code that causes this runtime error. Do NOT use <Composition>, registerRoot(), or any Remotion root-level APIs — export ONLY the default component function.\n\nReturn the COMPLETE corrected TypeScript JSX file. No explanations, no markdown fences, no partial snippets — the full file only.`;

      let renderFixedCode;
      try {
        renderFixedCode = await callClaudeWithRetry(renderFixPrompt, null, null,
          `Here is the component:\n\n${brokenCode}`);
        renderFixedCode = extractCode(renderFixedCode);
        const fixHasDefault = /export\s+default\s+function/.test(renderFixedCode);
        const fixIsComplete = renderFixedCode.length >= brokenCode.length * 0.6;
        if (!fixHasDefault || !fixIsComplete) {
          log(`Render-crash fix returned incomplete code (${renderFixedCode.length} chars) — skipping`, 'warn');
          process.exit(5);
        }
        fs.writeFileSync(compPath, renderFixedCode, 'utf8');
        log('Render-crash auto-fix applied — retrying render…', 'ok');
      } catch (fixErr) {
        log('Render-crash auto-fix failed: ' + fixErr.message, 'err');
        process.exit(5);
      }

      await renderComposition({
        outputPath, bgColor, durationFrames,
        remotionDir, remotionCliScript, nodeBin, quality4k,
        log, progress,
        progressStart: 0.55, progressEnd: 0.93,
      }).catch((e2) => {
        log('Fatal: Remotion render exited with code 1', 'err');
        process.exit(5);
      });
    } else {
      log('Fatal: Remotion render exited with code 1', 'err');
      process.exit(5);
    }
  }

  // ── 8. Done ────────────────────────────────────────────────────────────────
  progress(0.99, 'Fresh .mov, hot off the render farm!');
  log('Output: ' + outputPath, 'ok');
  process.stdout.write(outputPath + '\n');
  process.exit(0);
}

// ── renderComposition ─────────────────────────────────────────────────────────
// Renders the AbstractorComp to outputPath. For clips > 25 s (750 frames) it
// automatically splits into 350-frame chunks, renders each one separately,
// then concatenates them losslessly with FFmpeg. This prevents Chrome tab OOM
// on long renders without sacrificing concurrency.
//
// opts.progressStart / progressEnd define the 0–1 region this render occupies
// in the overall pipeline progress bar.
async function renderComposition({ outputPath, bgColor, durationFrames, quality4k, remotionDir,
                                    remotionCliScript, nodeBin, log, progress,
                                    progressStart, progressEnd }) {
  const CHUNK_THRESHOLD = 750; // 25 s at 30 fps — above this, split into chunks
  const CHUNK_SIZE      = 350; // frames per chunk (≈ 11.6 s)

  const proresArgs = bgColor
    ? ['--pixel-format=yuv422p10le', '--codec=prores', '--prores-profile=standard']
    : ['--pixel-format=yuva444p10le', '--codec=prores', '--prores-profile=4444'];

  // Spawn one Remotion render for a specific frame range.
  const renderChunk = (chunkPath, startFrame, endFrame, onFrameProgress) =>
    new Promise((resolve, reject) => {
      const compositionId = 'AbstractorComp';
      const concurrency = Math.max(4, Math.min(os.cpus().length, 16));
      // jpeg is faster for solid-BG renders; must use png when alpha is needed (ProRes 4444)
      const imageFormat = bgColor ? '--image-format=jpeg' : '--image-format=png';
      const scaleArgs = quality4k ? ['--scale=2'] : [];
      const args = [
        '--max-old-space-size=8192',
        remotionCliScript,
        'render', 'src/index.ts', compositionId, chunkPath,
        imageFormat, ...scaleArgs,
        `--frames=${startFrame}-${endFrame}`,
        `--concurrency=${concurrency}`,
        ...proresArgs,
        '--log=error',
      ];
      const proc = spawn(nodeBin, args, {
        cwd: remotionDir,
        env: Object.assign({}, process.env, { FORCE_COLOR: '0' }),
      });
      let capturedOutput = '';
      proc.stdout.on('data', (d) => {
        const text = d.toString();
        capturedOutput += text;
        log(text.trim());
        const m = text.match(/(\d+)\/(\d+)/);
        if (m) onFrameProgress(parseInt(m[1], 10) / parseInt(m[2], 10));
      });
      proc.stderr.on('data', (d) => {
        const t = d.toString().trim();
        capturedOutput += t + '\n';
        if (t) log(t, t.toLowerCase().includes('error') ? 'err' : '');
      });
      proc.on('close', (code) => {
        if (code === 0) resolve();
        else {
          // Extract the first meaningful error line for downstream recovery
          const errLine = capturedOutput.split('\n')
            .map(l => l.replace(/\x1b\[[0-9;]*m/g, '').trim())
            .find(l => l.toLowerCase().includes('error') || l.toLowerCase().includes('referenceerror') || l.toLowerCase().includes('typeerror') || l.toLowerCase().includes('delayrender') || l.toLowerCase().includes('not cleared'));
          const err = new Error('Remotion render exited with code ' + code);
          err.remotionOutput = capturedOutput;
          err.remotionErrorLine = errLine || '';
          reject(err);
        }
      });
      proc.on('error', reject);
    });

  if (durationFrames <= CHUNK_THRESHOLD) {
    // Short clip — single pass, no splitting needed
    log(`Running: node ${remotionCliScript} render ... --concurrency=${Math.max(4, Math.min(os.cpus().length, 12))} --frames=0-${durationFrames - 1}`);
    return renderChunk(outputPath, 0, durationFrames - 1, (frac) => {
      progress(progressStart + frac * (progressEnd - progressStart),
               `Compositing frame ${Math.round(frac * durationFrames)} of ${durationFrames} at 30fps…`);
    });
  }

  // Long clip — render in chunks then concat
  const numChunks = Math.ceil(durationFrames / CHUNK_SIZE);
  const ts        = Date.now();
  const tmpDir    = os.tmpdir();
  const chunkPaths = [];

  for (let i = 0; i < numChunks; i++) {
    const startFrame = i * CHUNK_SIZE;
    const endFrame   = Math.min((i + 1) * CHUNK_SIZE - 1, durationFrames - 1);
    const chunkPath  = path.join(tmpDir, `abstractor_chunk_${i}_${ts}.mov`);
    chunkPaths.push(chunkPath);

    const chunkBase = progressStart + (i / numChunks) * (progressEnd - progressStart - 0.05);
    const chunkSpan = (progressEnd - progressStart - 0.05) / numChunks;

    log(`Chunk ${i + 1}/${numChunks}: rendering frames ${startFrame}–${endFrame}…`);
    progress(chunkBase, `Chunk ${i + 1}/${numChunks}: frames ${startFrame}–${endFrame}…`);

    await renderChunk(chunkPath, startFrame, endFrame, (frac) => {
      progress(chunkBase + frac * chunkSpan,
               `Chunk ${i + 1}/${numChunks}: frame ${Math.round(frac * (endFrame - startFrame + 1))} of ${endFrame - startFrame + 1}…`);
    });
    log(`Chunk ${i + 1}/${numChunks} done.`, 'ok');
  }

  // FFmpeg lossless concat
  const listPath = path.join(tmpDir, `abstractor_concat_${ts}.txt`);
  fs.writeFileSync(listPath, chunkPaths.map(p => `file '${p.replace(/'/g, "\\'")}'`).join('\n'), 'utf8');
  progress(progressStart + (progressEnd - progressStart) * 0.96,
           `Concatenating ${numChunks} chunks (lossless)…`);
  log(`Concatenating ${numChunks} chunks with FFmpeg…`);

  await new Promise((resolve, reject) => {
    const ffmpegBin = getCompositorFfmpeg(remotionDir);
    const ffmpegDir = path.dirname(ffmpegBin);
    const envExtra  = process.platform === 'darwin' ? { DYLD_LIBRARY_PATH: ffmpegDir } : {};
    const ff = spawn(ffmpegBin, ['-y', '-f', 'concat', '-safe', '0', '-i', listPath, '-c', 'copy', outputPath], {
      env: Object.assign({}, process.env, envExtra),
    });
    ff.stdout.on('data', (d) => log(d.toString().trim()));
    ff.stderr.on('data', (d) => log(d.toString().trim()));
    ff.on('close', (code) => {
      if (code === 0) resolve();
      else reject(new Error('FFmpeg concat failed (exit ' + code + ')'));
    });
    ff.on('error', (e) => reject(new Error('FFmpeg error: ' + e.message + ' (bin: ' + ffmpegBin + ')')));
  });

  // Cleanup temp files
  for (const p of chunkPaths) try { fs.unlinkSync(p); } catch (_) {}
  try { fs.unlinkSync(listPath); } catch (_) {}
  log(`Chunked render complete — ${numChunks} chunks concatenated.`, 'ok');
}

main().catch((e) => {
  process.stderr.write(JSON.stringify({ log: 'Fatal: ' + e.message, type: 'err' }) + '\n');
  process.exit(99);
});
