import React from 'react';
import { AbsoluteFill } from 'remotion';
import { default as Inner } from './AbstractorComp';

// White-background wrapper — renders the generated component on a solid white canvas.
// Used by the Abstractor panel when "White BG" mode is selected.
export default function AbstractorCompBg() {
  return (
    <AbsoluteFill style={{ background: 'white' }}>
      <Inner />
    </AbsoluteFill>
  );
}
