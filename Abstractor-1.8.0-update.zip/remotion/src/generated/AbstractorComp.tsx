export const DURATION_FRAMES = 450;
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, Easing, Img, staticFile } from 'remotion';

export default function InteractiveToTraining() {
  const frame = useCurrentFrame();
  const { width, height, fps } = useVideoConfig();

  const ease = { extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const, easing: Easing.inOut(Easing.ease) };
  const easeOut = { extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const, easing: Easing.out(Easing.ease) };

  const primary = 'rgb(118,185,0)';
  const secondary = 'rgb(93,22,130)';
  const dark = '#222';
  const mid = '#555';

  // ── LAYOUT ──
  const margin = 80;
  const topY = 80;

  const phaseBoxW = 400;
  const phaseBoxH = 88;
  const phaseGap = 280;
  const totalPhaseW = phaseBoxW * 2 + phaseGap;
  const phaseStartX = (width - totalPhaseW) / 2;

  const interactiveX = phaseStartX;
  const interactiveY = topY;
  const trainingX = phaseStartX + phaseBoxW + phaseGap;
  const trainingY = topY;

  const arrowY = interactiveY + phaseBoxH / 2;
  const arrowX1 = interactiveX + phaseBoxW;
  const arrowGap = 6;
  const tipX = trainingX - arrowGap;
  const arrowLineLen = tipX - arrowX1;

  const interSubY = interactiveY + phaseBoxH + 16;
  const trainSubY = trainingY + phaseBoxH + 16;

  const lowerY = 296;
  const panelGap = 48;
  const panelW = (width - margin * 2 - panelGap) / 2;
  const panelLeftX = margin;
  const panelRightX = margin + panelW + panelGap;

  const challenges = [
    { icon: 'm48-container.svg', title: 'Building Containers', desc: 'Packaging workloads into containers for training environments' },
    { icon: 'm48-attention-exclamation.svg', title: 'Over-Quota Eviction', desc: 'Risk of job eviction when exceeding resource quotas' },
    { icon: 'm48-data-storage.svg', title: 'Shared Storage', desc: 'Ensuring robust and shared storage across training jobs' },
  ];

  const solutions = [
    { icon: 'm48-settings-sync.svg', title: 'Auto-Restart Entry Points', desc: 'Configure containers to restart workloads automatically' },
    { icon: 'm48-secure-data.svg', title: 'Model Checkpoints', desc: 'Save weights periodically to resume after interruptions' },
    { icon: 'm48-data-loading-library.svg', title: 'Data Source Assets', desc: 'Simplify storage access with managed data sources' },
  ];

  const challengeCardH = 104;
  const challengeCardGap = 20;
  const challengeHeaderH = 56;
  const challengePanelH = challengeHeaderH + challenges.length * (challengeCardH + challengeCardGap) + 8;

  const solutionCardH = 104;
  const solutionCardGap = 20;
  const solutionHeaderH = 56;
  const solutionPanelH = solutionHeaderH + solutions.length * (solutionCardH + solutionCardGap) + 8;

  const panelH = Math.max(challengePanelH, solutionPanelH);

  const trainingCx = trainingX + phaseBoxW / 2;
  const trainingBottomY = trainingY + phaseBoxH;
  const connBranchY = trainSubY + 40;

  const challengePanelCx = panelLeftX + panelW / 2;
  const solutionPanelCx = panelRightX + panelW / 2;

  // ── ANIMATION ──
  // Phase 1: Interactive box
  const intOp    = interpolate(frame, [0, 20], [0, 1], easeOut);
  const intScale = interpolate(frame, [0, 20], [0.9, 1], easeOut);
  const intCx    = interactiveX + phaseBoxW / 2;
  const intCy    = interactiveY + phaseBoxH / 2;

  // Arrow
  const arrowDash    = arrowLineLen - interpolate(frame, [25, 55], [0, arrowLineLen], ease);
  const arrowHeadOp  = interpolate(frame, [55, 63], [0, 1], easeOut);

  // Subtitles — clip from right using HTML divs
  const intSubClip  = interpolate(frame, [18, 38], [100, 0], easeOut);
  const trainSubClip = interpolate(frame, [68, 88], [100, 0], easeOut);

  // Phase 3: Training box
  const trainOp    = interpolate(frame, [50, 70], [0, 1], easeOut);
  const trainScale = interpolate(frame, [50, 70], [0.9, 1], easeOut);
  const trainCx    = trainingX + phaseBoxW / 2;
  const trainCy    = trainingY + phaseBoxH / 2;

  // Transition label — opacity only (no CSS transform on SVG text)
  const transLabelOp = interpolate(frame, [40, 55], [0, 1], easeOut);

  // Connector stem
  const stemLen  = connBranchY - (trainSubY + 28);
  const stemDash = stemLen - interpolate(frame, [90, 110], [0, stemLen], ease);

  // Branch
  const branchLeftLen   = trainingCx - challengePanelCx;
  const branchRightLen  = solutionPanelCx - trainingCx;
  const branchLeftDash  = branchLeftLen  - interpolate(frame, [110, 130], [0, branchLeftLen],  ease);
  const branchRightDash = branchRightLen - interpolate(frame, [110, 130], [0, branchRightLen], ease);

  // Drops
  const dropLen           = lowerY - connBranchY - arrowGap;
  const dropLeftDash      = dropLen - interpolate(frame, [130, 148], [0, dropLen], ease);
  const dropRightDash     = dropLen - interpolate(frame, [130, 148], [0, dropLen], ease);
  const dropArrowLeftOp   = interpolate(frame, [148, 156], [0, 1], easeOut);
  const dropArrowRightOp  = interpolate(frame, [148, 156], [0, 1], easeOut);

  // Panel headers
  const chHeaderClip  = interpolate(frame, [155, 175], [100, 0], easeOut);
  const solHeaderClip = interpolate(frame, [160, 180], [100, 0], easeOut);
  const chPanelOp     = interpolate(frame, [150, 165], [0, 1], easeOut);
  const solPanelOp    = interpolate(frame, [155, 170], [0, 1], easeOut);

  // Cards
  const getCardAnim = (startFrame: number) => {
    const borderOp   = interpolate(frame, [startFrame,      startFrame + 18], [0, 1], easeOut);
    const contentOp  = interpolate(frame, [startFrame + 10, startFrame + 24], [0, 1], easeOut);
    const ty         = interpolate(frame, [startFrame + 10, startFrame + 24], [10, 0], easeOut);
    const iconOp     = interpolate(frame, [startFrame + 16, startFrame + 28], [0, 1], easeOut);
    const iconScale  = interpolate(frame, [startFrame + 16, startFrame + 28], [0, 1], easeOut);
    return { borderOp, contentOp, ty, iconOp, iconScale };
  };

  return (
    <AbsoluteFill>
      <svg width={width} height={height} style={{ position: 'absolute', top: 0, left: 0 }}>

        {/* ── Interactive Box — SVG transform attribute for reliable scale from center ── */}
        <g opacity={intOp}
           transform={`translate(${intCx}, ${intCy}) scale(${intScale}) translate(${-intCx}, ${-intCy})`}>
          <rect x={interactiveX} y={interactiveY} width={phaseBoxW} height={phaseBoxH} rx={2}
                fill="none" stroke={primary} strokeWidth={2.5} />
          <text x={intCx} y={intCy} textAnchor="middle" dominantBaseline="middle"
                fill={primary} fontSize={26} fontWeight="bold" fontFamily="NVIDIASans">Interactive Workloads</text>
        </g>

        {/* ── Arrow between phases ── */}
        <line x1={arrowX1} y1={arrowY} x2={tipX} y2={arrowY}
              stroke={primary} strokeWidth={2.5}
              strokeDasharray={arrowLineLen} strokeDashoffset={arrowDash} />
        <polyline points={`${tipX - 12},${arrowY - 7} ${tipX},${arrowY} ${tipX - 12},${arrowY + 7}`}
                  fill="none" stroke={primary} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"
                  opacity={arrowHeadOp} />

        {/* Transition label — opacity only, no CSS transform on SVG text */}
        <text x={(arrowX1 + tipX) / 2} y={arrowY - 18} textAnchor="middle" dominantBaseline="middle"
              fill={secondary} fontSize={18} fontWeight="bold" fontFamily="NVIDIASans"
              opacity={transLabelOp}>Key Transition</text>

        {/* ── Training Box — SVG transform attribute ── */}
        <g opacity={trainOp}
           transform={`translate(${trainCx}, ${trainCy}) scale(${trainScale}) translate(${-trainCx}, ${-trainCy})`}>
          <rect x={trainingX} y={trainingY} width={phaseBoxW} height={phaseBoxH} rx={2}
                fill="none" stroke={secondary} strokeWidth={2.5} />
          <text x={trainCx} y={trainCy} textAnchor="middle" dominantBaseline="middle"
                fill={secondary} fontSize={26} fontWeight="bold" fontFamily="NVIDIASans">Training Workloads</text>
        </g>

        {/* ── Connectors ── */}
        <line x1={trainingCx} y1={trainSubY + 28} x2={trainingCx} y2={connBranchY}
              stroke={dark} strokeWidth={1.5}
              strokeDasharray={stemLen} strokeDashoffset={stemDash} />
        <line x1={trainingCx} y1={connBranchY} x2={challengePanelCx} y2={connBranchY}
              stroke={dark} strokeWidth={1.5}
              strokeDasharray={branchLeftLen} strokeDashoffset={branchLeftDash} />
        <line x1={trainingCx} y1={connBranchY} x2={solutionPanelCx} y2={connBranchY}
              stroke={dark} strokeWidth={1.5}
              strokeDasharray={branchRightLen} strokeDashoffset={branchRightDash} />
        <line x1={challengePanelCx} y1={connBranchY} x2={challengePanelCx} y2={lowerY - arrowGap}
              stroke={dark} strokeWidth={1.5}
              strokeDasharray={dropLen} strokeDashoffset={dropLeftDash} />
        <polyline points={`${challengePanelCx - 7},${lowerY - arrowGap - 12} ${challengePanelCx},${lowerY - arrowGap} ${challengePanelCx + 7},${lowerY - arrowGap - 12}`}
                  fill="none" stroke={dark} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
                  opacity={dropArrowLeftOp} />
        <line x1={solutionPanelCx} y1={connBranchY} x2={solutionPanelCx} y2={lowerY - arrowGap}
              stroke={dark} strokeWidth={1.5}
              strokeDasharray={dropLen} strokeDashoffset={dropRightDash} />
        <polyline points={`${solutionPanelCx - 7},${lowerY - arrowGap - 12} ${solutionPanelCx},${lowerY - arrowGap} ${solutionPanelCx + 7},${lowerY - arrowGap - 12}`}
                  fill="none" stroke={dark} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
                  opacity={dropArrowRightOp} />

        {/* ── Panel outlines ── */}
        <rect x={panelLeftX} y={lowerY} width={panelW} height={panelH} rx={2}
              fill="none" stroke={secondary} strokeWidth={2} opacity={chPanelOp} />
        <rect x={panelRightX} y={lowerY} width={panelW} height={panelH} rx={2}
              fill="none" stroke={primary} strokeWidth={2} opacity={solPanelOp} />

        {/* ── Challenge cards ── */}
        {challenges.map((ch, i) => {
          const anim = getCardAnim(185 + i * 30);
          const cardX = panelLeftX + 24;
          const cardY = lowerY + challengeHeaderH + i * (challengeCardH + challengeCardGap);
          const cardW = panelW - 48;
          return (
            <g key={`ch-${i}`}>
              <rect x={cardX} y={cardY} width={cardW} height={challengeCardH} rx={2}
                    fill="none" stroke="#999" strokeWidth={1} opacity={anim.borderOp} />
              <text x={cardX + 64} y={cardY + 34} textAnchor="start" dominantBaseline="middle"
                    fill={dark} fontSize={22} fontWeight="bold" fontFamily="NVIDIASans"
                    opacity={anim.contentOp}>{ch.title}</text>
              <text x={cardX + 64} y={cardY + 64} textAnchor="start" dominantBaseline="middle"
                    fill={mid} fontSize={18} fontFamily="NVIDIASans"
                    opacity={anim.contentOp}>{ch.desc}</text>
            </g>
          );
        })}

        {/* ── Solution cards ── */}
        {solutions.map((sol, i) => {
          const anim = getCardAnim(195 + i * 30);
          const cardX = panelRightX + 24;
          const cardY = lowerY + solutionHeaderH + i * (solutionCardH + solutionCardGap);
          const cardW = panelW - 48;
          return (
            <g key={`sol-${i}`}>
              <rect x={cardX} y={cardY} width={cardW} height={solutionCardH} rx={2}
                    fill="none" stroke="#999" strokeWidth={1} opacity={anim.borderOp} />
              <text x={cardX + 64} y={cardY + 34} textAnchor="start" dominantBaseline="middle"
                    fill={dark} fontSize={22} fontWeight="bold" fontFamily="NVIDIASans"
                    opacity={anim.contentOp}>{sol.title}</text>
              <text x={cardX + 64} y={cardY + 64} textAnchor="start" dominantBaseline="middle"
                    fill={mid} fontSize={18} fontFamily="NVIDIASans"
                    opacity={anim.contentOp}>{sol.desc}</text>
            </g>
          );
        })}

        {/* ── Divider between panels ── */}
        <line x1={panelLeftX + panelW + panelGap / 2} y1={lowerY + panelH * 0.15}
              x2={panelLeftX + panelW + panelGap / 2} y2={lowerY + panelH * 0.85}
              stroke="#ccc" strokeWidth={1} strokeDasharray="4 4"
              opacity={interpolate(frame, [260, 280], [0, 1], easeOut)} />

        {/* ── Bottom accent line ── */}
        <line x1={margin} y1={height - 56}
              x2={margin + interpolate(frame, [300, 340], [0, width - margin * 2], easeOut)} y2={height - 56}
              stroke={primary} strokeWidth={2} />
      </svg>

      {/* ── Interactive subtitle — HTML div for reliable clipPath wipe ── */}
      <div style={{
        position: 'absolute',
        left: interactiveX,
        top: interSubY,
        width: phaseBoxW,
        clipPath: `inset(0 ${intSubClip}% 0 0)`,
        display: 'flex',
        justifyContent: 'center',
      }}>
        <span style={{ fontFamily: 'NVIDIASans', fontSize: 18, color: mid }}>Easy GPU access, quota restricted</span>
      </div>

      {/* ── Training subtitle — HTML div for reliable clipPath wipe ── */}
      <div style={{
        position: 'absolute',
        left: trainingX,
        top: trainSubY,
        width: phaseBoxW,
        clipPath: `inset(0 ${trainSubClip}% 0 0)`,
        display: 'flex',
        justifyContent: 'center',
      }}>
        <span style={{ fontFamily: 'NVIDIASans', fontSize: 18, color: mid }}>Higher throughput, new challenges</span>
      </div>

      {/* ── Panel headers — HTML divs for clipPath wipe ── */}
      <div style={{
        position: 'absolute',
        left: panelLeftX + 24,
        top: lowerY + 14,
        clipPath: `inset(0 ${chHeaderClip}% 0 0)`,
      }}>
        <span style={{ fontFamily: 'NVIDIASans', fontSize: 24, fontWeight: 'bold', color: secondary }}>Challenges</span>
      </div>
      <div style={{
        position: 'absolute',
        left: panelRightX + 24,
        top: lowerY + 14,
        clipPath: `inset(0 ${solHeaderClip}% 0 0)`,
      }}>
        <span style={{ fontFamily: 'NVIDIASans', fontSize: 24, fontWeight: 'bold', color: primary }}>Solutions</span>
      </div>

      {/* ── Phase box icons ── */}
      <Img src={staticFile('assets/icons/m48-gpu-chip.svg')} style={{
        position: 'absolute',
        left: interactiveX + 16,
        top: interactiveY + (phaseBoxH - 40) / 2,
        width: 40, height: 40,
        opacity: interpolate(frame, [12, 24], [0, 1], easeOut),
        transform: `scale(${interpolate(frame, [12, 24], [0, 1], easeOut)})`,
        transformOrigin: 'center center',
      }} />
      <Img src={staticFile('assets/icons/m48-optimized-training.svg')} style={{
        position: 'absolute',
        left: trainingX + 16,
        top: trainingY + (phaseBoxH - 40) / 2,
        width: 40, height: 40,
        opacity: interpolate(frame, [62, 74], [0, 1], easeOut),
        transform: `scale(${interpolate(frame, [62, 74], [0, 1], easeOut)})`,
        transformOrigin: 'center center',
      }} />

      {/* ── Challenge icons ── */}
      {challenges.map((ch, i) => {
        const anim = getCardAnim(185 + i * 30);
        const cardX = panelLeftX + 24;
        const cardY = lowerY + challengeHeaderH + i * (challengeCardH + challengeCardGap);
        return (
          <Img key={`ch-icon-${i}`} src={staticFile(`assets/icons/${ch.icon}`)} style={{
            position: 'absolute',
            left: cardX + 12,
            top: cardY + (challengeCardH - 40) / 2,
            width: 40, height: 40,
            opacity: anim.iconOp,
            transform: `scale(${anim.iconScale})`,
            transformOrigin: 'center center',
          }} />
        );
      })}

      {/* ── Solution icons ── */}
      {solutions.map((sol, i) => {
        const anim = getCardAnim(195 + i * 30);
        const cardX = panelRightX + 24;
        const cardY = lowerY + solutionHeaderH + i * (solutionCardH + solutionCardGap);
        return (
          <Img key={`sol-icon-${i}`} src={staticFile(`assets/icons/${sol.icon}`)} style={{
            position: 'absolute',
            left: cardX + 12,
            top: cardY + (solutionCardH - 40) / 2,
            width: 40, height: 40,
            opacity: anim.iconOp,
            transform: `scale(${anim.iconScale})`,
            transformOrigin: 'center center',
          }} />
        );
      })}
    </AbsoluteFill>
  );
}
