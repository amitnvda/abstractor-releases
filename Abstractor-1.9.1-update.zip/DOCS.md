# Abstractor — User Guide

Abstractor is an Adobe After Effects panel that turns a text description (and an optional reference image) into a fully animated 4K ProRes motion graphic — in one click. It uses Claude AI to generate the animation code, renders it with Remotion, and imports the result directly into your open AE project.

---

## Requirements

Before using Abstractor, make sure the following are installed:

| Requirement | Notes |
|---|---|
| **Claude CLI** | Must be installed and authenticated |
| **Node.js** | v18 or later |
| **After Effects** | CC 2019 or later. Project must be **saved** |
| **poppler** | For PPTX / PDF import on Mac: `brew install poppler` |
| **LibreOffice** | For PPTX import only: libreoffice.org |

> First launch installs the render engine automatically. A progress screen will appear — wait for "Ready" before using the panel.

---

## Opening the Panel

1. Open After Effects with a saved project
2. **Window → Extensions → Abstractor**

---

## The Three Input Modes

### 1. Text Only
The simplest way to start. Leave the media zone empty and type a concept in the **Concept / Content** field.

**Example:**
> GPU architecture with CUDA cores, memory hierarchy, and data flow between CPU and GPU

Click **ABSTRACT**. Claude designs the entire visualization from scratch.

---

### 2. Image + Text (Snapshot Mode)
Drop a reference image (screenshot, diagram, photo) into the media zone, then add a description. Claude uses the image to understand the structure and content — but designs a clean, professional animation in its own visual language. It won't copy the slide layout literally.

**Supported formats:** PNG, JPG, GIF, WebP, SVG

**Good for:**
- Turning a busy slide into a clean animated diagram
- Recreating a whiteboard sketch as motion graphics
- Visualizing a concept shown in a photo

---

### 3. Deck Mode (PPTX / PDF)
Drop a PowerPoint or PDF file. All slides appear as thumbnails. Click any slide to generate an animation for it — the slide thumbnail becomes the visual reference automatically. Slides with a completed render get a green checkmark.

**Requirements:** poppler + LibreOffice (for PPTX). See the Requirements section above.

---

## The Controls

### Colors

| Control | What it does |
|---|---|
| **Primary** | Main color — highlights, key elements, borders, animated strokes |
| **Accent** | Supporting color. Set to **Auto** to let Claude pick the best complement |
| **Background** | Canvas background. Default is **transparent** (recommended for AE compositing) |

Available colors are all NVIDIA brand colors: Green, Emerald, Amethyst, CPU Blue, Garnet, Fluorite, Black.

> **Transparent background** means the animation composites cleanly over your slide in AE — the most common use case. Use a solid background only when you want a standalone clip.

---

### Length
Set a clip duration in seconds (1–60). Leave blank to let Claude decide based on the content complexity.

---

### Name
Optional custom name for the output file. Leave blank and the file is named automatically from the content.

---

### Assets *(optional)*
Expand the Assets section to attach files that will appear inside the animation.

| Format | Use |
|---|---|
| PNG | Product screenshots, logos, photos |
| SVG | Icons, diagrams, vector art |
| AI | Illustrator files |

Assets are copied into the render project and Claude is instructed to incorporate them. Be specific in your text prompt about what each asset represents and where it should appear.

---

### No Text
Check this to produce a purely visual animation — no labels, no text elements. Useful for abstract backgrounds or icon-only animations.

---

## Running a Render

1. Fill in your inputs
2. Click **ABSTRACT**
3. A progress bar and rotating status messages appear — renders typically take **2–8 minutes**
4. When complete, the `.mov` is automatically imported into your AE project under `Footage/Abstractor Renders/`

The **Open Folder** button opens the renders folder in Finder / Explorer at any time.

---

## After a Render

### Fix / Tweak
Once a render completes, a **Fix / Tweak** field appears. Describe a specific change and click **Fix** — Claude modifies only what you asked and re-renders. You don't need to start over for small adjustments.

**Examples:**
> Make the arrows thicker and blue
> Move the title higher and increase the font size
> Add a pulsing dot traveling along the connector line

Each fix produces a new file — your original is preserved.

---

### Recreate
The **↺ Recreate** button re-runs the exact same prompt to produce a different variation. Useful when the first result isn't quite right but the concept is good.

---

### Reset
The **⇤ Reset** button clears all inputs and returns the panel to a clean state.

---

## History
Expand the **History** section to see your last 200 renders. Each entry shows the prompt, output name, and timestamp.

- **👍 / 👎** — Rate a render. Thumbs-up results are used as style references for future renders; thumbs-down results are avoided. Over time this personalizes the output to your taste.
- **Use again** — Loads the prompt back into the text field so you can re-run or modify it.

---

## Output Files
All renders are saved as `.mov` files (ProRes 4444, 4K, 30fps, 15 seconds default).

| Output detail | Value |
|---|---|
| Format | QuickTime ProRes 4444 |
| Resolution | 3840 × 2160 (4K) |
| Frame rate | 30 fps |
| Default duration | 15 seconds (450 frames) |
| Alpha channel | Yes (transparent background by default) |
| Location | `<AE project>/Footage/Abstractor Renders/` |

File names follow this pattern: `ContentTitle_Abstractor_00001.mov`

---

## Best Practices

### Writing good prompts

**Be specific about structure.** Claude picks a layout archetype based on how you describe the content. Tell it the shape of your information:

| Instead of... | Try... |
|---|---|
| "Explain our platform" | "3-step pipeline: User → API Gateway → GPU Cluster, with data flow arrows" |
| "Show the architecture" | "Hierarchical diagram: DGX SuperPOD at top, 4 DGX H100 nodes below it, connected by NVLink" |
| "Make something about AI" | "Side-by-side comparison: Traditional ML training (left) vs. AI inference at scale (right), each with 3 bullet points" |

**Name your elements.** The more named concepts you include, the richer the visualization.

**Specify the archetype if you know it.** You can say "pipeline diagram", "hub and spoke", "comparison panel", "timeline", "metrics dashboard" — Claude will follow the instruction.

---

### Working with reference images

- Use the image to show **structure**, not style. Claude reads the content hierarchy from the image but redesigns the visual from scratch.
- A clean screenshot works better than a photo of a whiteboard.
- Add a text description even with an image — the description helps Claude understand what's most important.
- If the slide has notes, paste them into the text field for richer context.

---

### Getting consistent results

- Pick a **Primary** color and keep it consistent across your deck. This gives the video series a unified look.
- Set **Accent** to Auto unless you need exact control — Claude picks a good complement from the NVIDIA palette.
- Use **Background: Transparent** for slides — it composites over any AE background.
- If a render isn't right, use **Fix / Tweak** for small corrections rather than re-running from scratch.

---

### Using Fix effectively

- One specific fix at a time works better than multiple changes in one request.
- Reference elements by their visual role: "the horizontal connector between the two boxes", "the GPU node on the right", "the header text".
- For big structural changes, use **Recreate** with an updated prompt instead.

---

### Render time

- Simple text-only prompts: ~2–4 minutes
- Image + description: ~3–6 minutes
- Dense content or long duration (30+ sec): up to 8 minutes
- Remotion caches the render bundle after the first run — subsequent renders on the same session are faster.

---

## FAQ

**Q: The render takes 8+ minutes. Is that normal?**
The first render in a session is always the slowest because Remotion builds the bundle from scratch. Subsequent renders in the same session are faster (2–4 min). If every render is slow, make sure Node.js is up to date.

---

**Q: I got Exit 5. What does that mean?**
Exit 5 means the render failed. Open the **Render Log** at the bottom of the panel — the error will be there. Common causes:
- Claude generated code with a runtime error (Remotion will attempt an auto-fix once)
- The generated code had a syntax error (usually means Claude returned text instead of code — try again)
- An asset couldn't be found or read

---

**Q: The Fix feature didn't change anything / looks identical to the original.**
Make sure the fix description is specific and clear. Vague requests ("make it better") don't give Claude enough direction. Also verify you're looking at the new file — the fix creates a new `.mov` with an incremented serial number.

---

**Q: PPTX import isn't working.**
PPTX conversion requires both **LibreOffice** and **poppler** to be installed. On Mac, install poppler with `brew install poppler` and LibreOffice from libreoffice.org. On Windows, install LibreOffice to the default path (`C:\Program Files\LibreOffice`).

---

**Q: The animation has text / elements cut off at the edges.**
This is a prompt issue — describe the content more concisely so Claude doesn't try to fit too many elements onto the canvas. Also try adding: *"use clean simple layout with generous spacing"* to your prompt.

---

**Q: Can I use my own colors outside the NVIDIA palette?**
The panel currently offers the NVIDIA brand palette only. Custom hex colors aren't supported in the UI, but the NVIDIA palette covers most use cases (green, blue, purple, teal, yellow, dark red, black).

---

**Q: The render imported into AE but I don't see it.**
Check the Project panel — it will be in a folder called `Abstractor Renders`. If it's there but invisible on the canvas, verify the composition size matches (3840×2160) and the layer's scale is set to fit.

---

**Q: Can I use Abstractor without a reference image?**
Yes — text-only mode is fully supported and often produces great results. Just leave the media zone empty and describe your concept in the text field.

---

**Q: What's the difference between Recreate and Fix?**
**Recreate** re-runs the same prompt from scratch and produces a completely different design. **Fix** takes the existing animation code and makes a targeted change to it. Use Recreate when you want a different direction; use Fix when the design is mostly right and you need a small adjustment.

---

**Q: How do I share or back up my renders?**
Click **Open Folder** to open the renders directory. All `.mov` files are there. You can copy them anywhere — they're self-contained QuickTime files.
