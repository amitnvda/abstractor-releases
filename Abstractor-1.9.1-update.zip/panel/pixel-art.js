/**
 * pixel-art.js — Abstractor thinking animation
 *
 * A side-view pixel-art tractor (NVIDIA green) rolling right,
 * with a film strip being "plowed" on the right side.
 * Canvas is 20×20 logical pixels rendered at 3× scale.
 */

(function () {
  'use strict';

  var SCALE  = 3;
  var COLS   = 20;
  var ROWS   = 20;
  var SIZE   = COLS * SCALE;  // 60px canvas

  // ── Color palette ─────────────────────────────────────────────────────────
  var C = {
    '.': null,           // transparent (also key for draw loop)
    K:  '#0a0a0a',       // black — outlines, wheel rim, film border
    G:  '#76b900',       // NVIDIA green — tractor body
    D:  '#4a7200',       // dark green — cab roof, shadows
    W:  '#e8e8e8',       // white — window, wheel spoke, film content
    Y:  '#fac200',       // yellow — film sprocket holes
    L:  '#bbbbbb',       // light grey — exhaust pipe & smoke
    S:  '#888888',       // medium grey — smoke (faded)
  };

  // ── Sprite frames (20×20, 4 frames) ───────────────────────────────────────
  // Tractor faces right. Big rear wheel (cols 0-6), small front wheel
  // (cols 8-12), cab+hood (cols 3-12), film strip on right (cols 14-17).
  // Wheel spoke rotates across frames (W pixels inside the wheel).
  //
  //  0         1         2
  //  01234567890123456789
  //  ──────── rear whl ──  ──front──  ──film──

  var FRAMES = [
    // ── Frame 0: spoke vertical (12 o'clock / 6 o'clock) ──────────────────
    [
      '..L.L...............', // 0  smoke
      '...L................', // 1
      '...L................', // 2  exhaust tip
      '...L................', // 3
      '...LGGGGGGG.........', // 4  exhaust L + cab top (G = green roof)
      '...LGWWWWWG.........', // 5  cab window
      '...LGWWWWWG...KWWK..', // 6  cab window + film strip top
      '.GGGGGGGGGGG..KYYK..', // 7  hood merges with cab + film sprocket
      '.GGGGGGGGGGGG.KWWK..', // 8  body + film frame
      '.GGGGGGGGGGGG.KWWK..', // 9
      '.GGGGGGGGGGGG.KWWK..', // 10
      '.GGGGGGGGGGGG.KYYK..', // 11 film sprocket
      '.KKKKKKKKKKKK.KWWK..', // 12 chassis + film
      '.KGGGGK.KGGGK.KKKK..', // 13 axle stubs + film border
      'KGGWGGK.KGGGK.......', // 14 rear wheel (W = spoke up at col 3)
      'KGGKGGK.KGGK........', // 15 rear hub (K at col 3)
      'KGGWGGK.KGGGK.......', // 16 rear wheel (spoke down at col 3)
      '.KGGGGK.KGGGK.......', // 17 wheel bottom
      '..KKKKK..KKKKK......', // 18 wheel base
      '....................', // 19
    ],

    // ── Frame 1: spoke diagonal (2 o'clock / 8 o'clock) ───────────────────
    [
      '.L.L.L..............', // 0  smoke drifting left
      '..L.................', // 1
      '...L................', // 2
      '...L................', // 3
      '...LGGGGGGG.........', // 4
      '...LGWWWWWG.........', // 5
      '...LGWWWWWG...KWWK..', // 6
      '.GGGGGGGGGGG..KYYK..', // 7
      '.GGGGGGGGGGGG.KWWK..', // 8
      '.GGGGGGGGGGGG.KGGK..', // 9  film flicker — green tint
      '.GGGGGGGGGGGG.KWWK..', // 10
      '.GGGGGGGGGGGG.KYYK..', // 11
      '.KKKKKKKKKKKK.KWWK..', // 12
      '.KGGGGK.KGGGK.KKKK..', // 13
      'KGGGGWK.KGGGK.......', // 14 spoke upper-right (W at col 5)
      'KGGKGGK.KGGK........', // 15 hub
      'KGWGGGK.KGGGK.......', // 16 spoke lower-left (W at col 2)
      '.KGGGGK.KGGGK.......', // 17
      '..KKKKK..KKKKK......', // 18
      '....................', // 19
    ],

    // ── Frame 2: spoke horizontal (3 o'clock / 9 o'clock) ─────────────────
    [
      'L.L.................', // 0  fresh big puff
      '.L..................', // 1
      '...L................', // 2
      '...L................', // 3
      '...LGGGGGGG.........', // 4
      '...LGWWWWWG.........', // 5
      '...LGWWWWWG...KWWK..', // 6
      '.GGGGGGGGGGG..KYYK..', // 7
      '.GGGGGGGGGGGG.KWWK..', // 8
      '.GGGGGGGGGGGG.KGGK..', // 9
      '.GGGGGGGGGGGG.KGGK..', // 10 film flicker continues
      '.GGGGGGGGGGGG.KYYK..', // 11
      '.KKKKKKKKKKKK.KWWK..', // 12
      '.KGGGGK.KGGGK.KKKK..', // 13
      'KGGGGGK.KGGGK.......', // 14 no spoke in upper row
      'KWGKWGK.KGGK........', // 15 horizontal spoke: W at cols 1 & 4
      'KGGGGGK.KGGGK.......', // 16 no spoke in lower row
      '.KGGGGK.KGGGK.......', // 17
      '..KKKKK..KKKKK......', // 18
      '....................', // 19
    ],

    // ── Frame 3: spoke diagonal (10 o'clock / 4 o'clock) ──────────────────
    [
      '...L................', // 0  smoke clearing
      '..L.................', // 1
      '...L................', // 2
      '...L................', // 3
      '...LGGGGGGG.........', // 4
      '...LGWWWWWG.........', // 5
      '...LGWWWWWG...KWWK..', // 6
      '.GGGGGGGGGGG..KYYK..', // 7
      '.GGGGGGGGGGGG.KWWK..', // 8
      '.GGGGGGGGGGGG.KWWK..', // 9
      '.GGGGGGGGGGGG.KWWK..', // 10
      '.GGGGGGGGGGGG.KYYK..', // 11
      '.KKKKKKKKKKKK.KWWK..', // 12
      '.KGGGGK.KGGGK.KKKK..', // 13
      'KGWGGGK.KGGGK.......', // 14 spoke upper-left (W at col 2)
      'KGGKGGK.KGGK........', // 15 hub
      'KGGGGWK.KGGGK.......', // 16 spoke lower-right (W at col 5)
      '.KGGGGK.KGGGK.......', // 17
      '..KKKKK..KKKKK......', // 18
      '....................', // 19
    ],
  ];

  // ── Messages ──────────────────────────────────────────────────────────────
  var MESSAGES = [
    'Plowing the timeline…',
    'Harvesting pixels…',
    'Tilling the frames…',
    'Cultivating motion…',
    'Growing your animation…',
    'Seeding the keyframes…',
    'Rendering the fields…',
    'CUDA go brrr…',
  ];

  // ── Canvas setup ──────────────────────────────────────────────────────────
  var canvas, ctx, msgEl, frameIdx, tick, msgIdx, intervalId;

  function init(canvasEl, messageEl) {
    canvas = canvasEl;
    ctx    = canvasEl.getContext('2d');
    msgEl  = messageEl;

    canvas.width  = SIZE;
    canvas.height = SIZE;
    canvas.style.width  = SIZE + 'px';
    canvas.style.height = SIZE + 'px';
    canvas.style.imageRendering = 'pixelated';

    frameIdx = 0;
    tick     = 0;
    msgIdx   = 0;
  }

  function start() {
    if (intervalId) return;
    intervalId = setInterval(step, 160);
  }

  function stop() {
    clearInterval(intervalId);
    intervalId = null;
    ctx.clearRect(0, 0, SIZE, SIZE);
  }

  function step() {
    tick++;
    frameIdx = (frameIdx + 1) % FRAMES.length;
    draw();

    // (message text is now driven by real progress events, not cycled here)
  }

  function draw() {
    ctx.clearRect(0, 0, SIZE, SIZE);
    var frame = FRAMES[frameIdx];

    for (var row = 0; row < ROWS; row++) {
      var line = frame[row] || '';
      for (var col = 0; col < COLS; col++) {
        var ch = line[col] || '.';
        var color = C[ch.toUpperCase()] || C[ch];
        if (!color) continue;  // transparent
        ctx.fillStyle = color;
        ctx.fillRect(col * SCALE, row * SCALE, SCALE, SCALE);
      }
    }
  }

  // ── Public API ────────────────────────────────────────────────────────────
  window.PixelArt = { init: init, start: start, stop: stop };
}());
