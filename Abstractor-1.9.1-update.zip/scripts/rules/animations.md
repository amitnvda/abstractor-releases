---
name: animations
description: Fundamental animation skills for Remotion
metadata:
  tags: animations, transitions, frames, useCurrentFrame
---

All animations MUST be driven by the `useCurrentFrame()` hook.  
Write animations in seconds and multiply them by the `fps` value from `useVideoConfig()`.

CSS transitions or animations are FORBIDDEN - they will not render correctly.  
Tailwind animation class names are FORBIDDEN - they will not render correctly.

---

## NO MAIN SLIDE TITLE (ABSOLUTE BAN)

**Never render the slide's main heading or title as text in the composition.**

The visualization stands alone. The title is shown in the slide itself — reproducing it inside the animation creates redundancy and makes the overlay look amateurish.

- If the reference image has a large heading at the top (e.g. "Validation Test Tiers"), **ignore it entirely**.
- Do NOT add a title bar, title overlay, or any top-level heading to the composition.
- Only render content that is part of the diagram itself: labels, node names, row titles, metric values.

This rule applies to ALL modes: diagram, free-diagram, creative, and faithful-reproduction.

---

## MANDATORY: Every entrance must combine opacity AND movement

**Opacity-only fades are FORBIDDEN.** Every element that animates in must combine opacity with at least one transform: `translateY`, `translateX`, or `scale`. A bare fade looks amateurish and flat.

**WRONG — never do this:**
```tsx
const opacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: 'clamp' });
<div style={{ opacity }}>Content</div>
```

**CORRECT — always pair opacity with a transform:**
```tsx
const progress = interpolate(frame, [0, 20], [0, 1], {
  extrapolateRight: 'clamp',
  easing: Easing.out(Easing.ease),
});
const opacity = progress;
const translateY = interpolate(progress, [0, 1], [24, 0]);

<div style={{ opacity, transform: `translateY(${translateY}px)` }}>Content</div>
```

The standard entrance offset is **16–32px** for `translateY` (elements rise up into place).  
Use **−16px to 0px** for elements descending into place.  
Use `scale` from **0.85 → 1** for elements that pop or expand into view.

---

## Standard entrance pattern

```tsx
import { useCurrentFrame, useVideoConfig, interpolate, Easing } from "remotion";

export const FadeSlideIn = ({ delay = 0 }: { delay?: number }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const progress = interpolate(frame, [delay, delay + 20], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.ease),
  });

  return (
    <div style={{
      opacity: progress,
      transform: `translateY(${interpolate(progress, [0, 1], [24, 0])}px)`,
    }}>
      Content
    </div>
  );
};
```

---

---

## Card / container entrances (MANDATORY)

Small cards, item rows, and icon containers MUST enter with **both opacity AND scale**. Never fade a small card in with opacity alone — it looks like a PowerPoint fade, not professional motion.

**Exception — large full-page panels**: Wide or tall bordered containers that span a large portion of the canvas (e.g. two side-by-side comparison panels) must use **translate + opacity only — NO scale**. Scaling a large panel looks like it's zooming in from nowhere and is visually ugly. Use `translateX` (slide in from side) or `translateY` (rise up) combined with opacity instead.

**REQUIRED pattern for any card, box, or container:**
```tsx
import { spring, useCurrentFrame, useVideoConfig, interpolate } from 'remotion';

const frame = useCurrentFrame();
const { fps } = useVideoConfig();

const cardProgress = spring({
  frame: frame - delay,
  fps,
  config: { damping: 200 },
  durationInFrames: 24,
});

const cardOpacity = cardProgress;
const cardScale   = interpolate(cardProgress, [0, 1], [0.93, 1]);

<div style={{
  opacity: cardOpacity,
  transform: `scale(${cardScale})`,
  // optional: also add a subtle rise
  // translateY: interpolate(cardProgress, [0, 1], [16, 0])
}}>
  {/* card content */}
</div>
```

- Scale from **0.93 → 1** for a clean pop-in feel. Never start lower than 0.85 (looks like it's exploding in).
- Use `spring({ damping: 200 })` for smooth settle — no bounce.
- Card entrance completes in **20–28 frames**; content inside the card staggers in **8–12 frames after** the card finishes entering.
- For multiple cards appearing in sequence, stagger each card **10–14 frames** after the previous.

---

## Exit animations

Exits should mirror entrances: fade out + move away (translateY downward, or scale to 0.9).  
Never cut abruptly — always animate out over at least 10 frames.
