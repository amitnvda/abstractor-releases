---
name: text-animations
description: Typography and text animation patterns for Remotion.
metadata:
  tags: typography, text, typewriter, fade, slide, stagger
---

## MANDATORY: Text must never fade in with opacity alone

Every text element MUST enter with **both opacity AND translateY**. An opacity-only fade on text is a hard violation — it looks like a PowerPoint transition, not professional motion design.

**FORBIDDEN:**
```tsx
// Never do this for text
const opacity = interpolate(frame, [0, 15], [0, 1], { extrapolateRight: 'clamp' });
<text style={{ opacity }}>Label</text>
```

**REQUIRED — always combine opacity + translateY:**
```tsx
const t = interpolate(frame, [startFrame, startFrame + 18], [0, 1], {
  extrapolateLeft: 'clamp',
  extrapolateRight: 'clamp',
  easing: Easing.out(Easing.ease),
});
const opacity = t;
const y = interpolate(t, [0, 1], [20, 0]);

<text
  style={{ opacity }}
  transform={`translate(${x}, ${baseY + y})`}
>
  Label
</text>
```

Standard entrance offset: **18–24px** upward (`translateY` from +20 → 0).

---

## Staggered list entrances

When animating a list of items, stagger each item by **8–12 frames**. Never animate all items simultaneously.

```tsx
{items.map((item, i) => {
  const delay = i * 10; // 10 frame stagger
  const t = interpolate(frame, [delay, delay + 18], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.ease),
  });
  return (
    <div key={i} style={{
      opacity: t,
      transform: `translateY(${interpolate(t, [0, 1], [20, 0])}px)`,
    }}>
      {item}
    </div>
  );
})}
```

---

## Typewriter Effect

Use string slicing driven by `useCurrentFrame()` to reveal text character by character.  
**Never use per-character opacity for typewriter effects.**

```tsx
const frame = useCurrentFrame();
const { fps } = useVideoConfig();
const charsPerSecond = 20;
const charsToShow = Math.floor((frame / fps) * charsPerSecond);
const visibleText = fullText.slice(0, charsToShow);
```

---

## Heading vs body timing

- **Headings / titles**: 16–20 frame entrance, translateY 20–28px
- **Body text / labels**: 14–18 frame entrance, translateY 16–20px  
- **Captions / small labels**: 12–16 frame entrance, translateY 12–16px
