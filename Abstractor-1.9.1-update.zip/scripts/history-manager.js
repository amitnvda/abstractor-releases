'use strict';
// ─────────────────────────────────────────────────────────────────────────────
// Abstractor — Render History Manager
// Stores render history per user in ~/.abstractor/history.json
// Used by: bridge (read — few-shot injection) + panel (read/write — UI + rating)
// ─────────────────────────────────────────────────────────────────────────────
const path  = require('path');
const fs    = require('fs');
const os    = require('os');

const HISTORY_DIR  = path.join(os.homedir(), '.abstractor');
const HISTORY_FILE = path.join(HISTORY_DIR, 'history.json');
const THUMB_DIR    = path.join(HISTORY_DIR, 'thumbnails');
const MAX_ENTRIES  = 200;

function ensureDirs() {
  if (!fs.existsSync(HISTORY_DIR)) fs.mkdirSync(HISTORY_DIR, { recursive: true });
  if (!fs.existsSync(THUMB_DIR))   fs.mkdirSync(THUMB_DIR,   { recursive: true });
}

// ── Read / Write ──────────────────────────────────────────────────────────────
function load() {
  try {
    if (fs.existsSync(HISTORY_FILE))
      return JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8'));
  } catch (e) { /* corrupted — start fresh */ }
  return { version: 1, entries: [] };
}

function save(data) {
  ensureDirs();
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(data, null, 2), 'utf8');
}

// ── Add entry ─────────────────────────────────────────────────────────────────
// entry = { prompt, fixes[], outputPath, outputName, primaryColor,
//            accentColor, bgColor, durationSec }
function addEntry(entry) {
  const data = load();
  const id   = String(Date.now());
  const full = Object.assign({
    id,
    timestamp:    new Date().toISOString(),
    rating:       null,          // null | 'like' | 'dislike'
    thumbnailPath: null,
    fixes:        [],
  }, entry, { id });
  data.entries.unshift(full);
  if (data.entries.length > MAX_ENTRIES)
    data.entries = data.entries.slice(0, MAX_ENTRIES);
  save(data);
  return id;
}

// ── Add fix to existing entry ─────────────────────────────────────────────────
// fix = { request, outputName, outputPath }
function addFix(parentId, fix) {
  const data  = load();
  const entry = data.entries.find(e => e.id === parentId);
  if (!entry) return;
  if (!Array.isArray(entry.fixes)) entry.fixes = [];
  entry.fixes.push(Object.assign({ timestamp: new Date().toISOString() }, fix));
  save(data);
}

// ── Rating ────────────────────────────────────────────────────────────────────
// Toggles: clicking same rating again clears it
function setRating(id, rating) {
  const data  = load();
  const entry = data.entries.find(e => e.id === id);
  if (!entry) return;
  entry.rating = (entry.rating === rating) ? null : rating;
  save(data);
  return entry.rating;
}

// ── Thumbnail ─────────────────────────────────────────────────────────────────
// Tries ffmpeg; silently skips if unavailable.
// remotionDir (optional): path to the remotion/ folder — enables bundled ffmpeg fallback.
// Returns the saved thumbnail path or null via cb.
function extractThumbnail(id, movPath, remotionOrCb, cbOrUndef) {
  // Handle both extractThumbnail(id, movPath, cb) and extractThumbnail(id, movPath, remotionDir, cb)
  let remotionDir, cb;
  if (typeof remotionOrCb === 'function') { cb = remotionOrCb; remotionDir = null; }
  else { remotionDir = remotionOrCb; cb = cbOrUndef; }

  ensureDirs();
  const thumbPath = path.join(THUMB_DIR, id + '.jpg');

  // Compute bundled Remotion ffmpeg path (guaranteed after npm install)
  let bundledFfmpeg = null;
  if (remotionDir) {
    const plat = process.platform, arch = process.arch;
    let pkg;
    if (plat === 'darwin')      pkg = arch === 'arm64' ? 'compositor-darwin-arm64' : 'compositor-darwin-x64';
    else if (plat === 'win32')  pkg = 'compositor-win32-x64-msvc';
    else                        pkg = 'compositor-linux-x64-gnu';
    bundledFfmpeg = path.join(remotionDir, 'node_modules', '@remotion', pkg, plat === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
  }

  const base = process.platform === 'win32'
    ? ['ffmpeg', 'C:\\ffmpeg\\bin\\ffmpeg.exe']
    : ['ffmpeg', '/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg'];
  const candidates = bundledFfmpeg ? [...base, bundledFfmpeg] : base;

  const { execFile } = require('child_process');

  function tryNext(list) {
    if (!list.length) return cb(null);
    const bin = list[0];
    const args = ['-i', movPath, '-vframes', '1', '-vf', 'scale=240:-1', '-q:v', '5', thumbPath, '-y', '-loglevel', 'error'];
    execFile(bin, args, function (err) {
      if (!err && fs.existsSync(thumbPath)) return cb(thumbPath);
      tryNext(list.slice(1));
    });
  }
  tryNext(candidates);
}

// Update thumbnailPath in history entry after extraction
function setThumbnailPath(id, thumbPath) {
  const data  = load();
  const entry = data.entries.find(e => e.id === id);
  if (entry) { entry.thumbnailPath = thumbPath; save(data); }
}

// ── Few-shot injection ────────────────────────────────────────────────────────
// Returns a short string to append to the Claude system prompt.
// Only included when the user has rated renders — empty string otherwise.
function buildFewShotSection() {
  const data     = load();
  const liked    = data.entries.filter(e => e.rating === 'like').slice(0, 3);
  const disliked = data.entries.filter(e => e.rating === 'dislike').slice(0, 2);
  if (!liked.length && !disliked.length) return '';

  const lines = ['\n\n── YOUR RENDER HISTORY (personalized guidance) ──'];
  if (liked.length) {
    lines.push('These prompts produced results you rated highly — use as style reference:');
    liked.forEach(e => lines.push('✓ "' + e.prompt.replace(/\n/g, ' ').slice(0, 180) + '"'));
  }
  if (disliked.length) {
    lines.push('These prompts produced results you disliked — avoid similar approaches:');
    disliked.forEach(e => lines.push('✗ "' + e.prompt.replace(/\n/g, ' ').slice(0, 180) + '"'));
  }
  return lines.join('\n');
}

module.exports = {
  load,
  addEntry,
  addFix,
  setRating,
  extractThumbnail,
  setThumbnailPath,
  buildFewShotSection,
};
