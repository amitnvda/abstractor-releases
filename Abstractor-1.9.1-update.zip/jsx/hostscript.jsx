// Abstractor hostscript.jsx
// ExtendScript entry point for After Effects
// Note: Latin-1 encoding; ASCII only

#include "utils.jsx"

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Return the AE project folder path, or empty string if unsaved.
 */
function getProjectFolder() {
  var projFile = app.project.file;
  if (!projFile || !projFile.exists) return '';
  return projFile.parent.fsName;
}

/**
 * Locate (or create) Footage/Renders next to the .aep file.
 * Returns a Folder object, or null if the project is unsaved.
 */
function getRendersFolder() {
  var projFile = app.project.file;
  if (!projFile || !projFile.exists) return null;

  var projDir    = projFile.parent;
  var footageDir = new Folder(projDir.fsName + '/Footage');
  if (!footageDir.exists) footageDir.create();

  var rendersDir = new Folder(footageDir.fsName + '/Renders');
  if (!rendersDir.exists) rendersDir.create();

  return rendersDir;
}

// ── Public functions ──────────────────────────────────────────────────────────

/**
 * Import a rendered .mov into the AE project.
 * The file is already at its final destination — just import it.
 * compName (optional): override the footage/layer name in AE.
 * Returns "ok:<folderPath>" on success, "error: ..." on failure.
 */
function importToAE(filePath, compName) {
  try {
    var srcFile = new File(filePath);
    if (!srcFile.exists) {
      return 'error: file not found: ' + filePath;
    }

    app.beginUndoGroup('Abstractor: Import');

    var importOptions = new ImportOptions(srcFile);
    importOptions.importAs = ImportAsType.FOOTAGE;
    var footage = app.project.importFile(importOptions);

    footage.parentFolder = abGetOrCreateFolder('Abstractor');
    // Use compName if provided, otherwise derive from filename
    footage.name = (compName && compName.length > 0)
      ? compName
      : srcFile.name.replace(/\.[^.]+$/, '');

    // Add to active comp: place at playhead, fit-to-comp
    var active = app.project.activeItem;
    if (!(active && active instanceof CompItem)) {
      // No comp open — search project for the first available CompItem
      var found = null;
      for (var i = 1; i <= app.project.numItems; i++) {
        if (app.project.item(i) instanceof CompItem) { found = app.project.item(i); break; }
      }
      active = found;
    }

    if (active && active instanceof CompItem) {
      var layer = active.layers.add(footage);
      layer.name = footage.name;

      // Fit-to-comp: scale so footage fills comp (4K->1080p = 50%)
      var scaleX = (active.width  / footage.width)  * 100;
      var scaleY = (active.height / footage.height) * 100;
      var fitScale = Math.min(scaleX, scaleY);
      try { layer.transform.scale.setValue([fitScale, fitScale]); } catch (scaleErr) {}

      // Place layer start at current playhead position
      layer.startTime = active.time;
    }

    app.endUndoGroup();
    // Return the comp name so the panel can confirm which comp received the layer
    var compName2 = (active && active instanceof CompItem) ? active.name : '';
    return (compName2 ? 'ok:' : 'ok-no-comp:') + srcFile.parent.fsName + (compName2 ? '|' + compName2 : '');

  } catch (e) {
    try { app.endUndoGroup(); } catch (ignore) {}
    return 'error: ' + e.message + ' (line ' + e.line + ')';
  }
}

/**
 * Open Footage/Abstractor Renders in Finder / Explorer.
 */
function openRendersFolder() {
  try {
    var rendersDir = getRendersFolder();
    if (!rendersDir) return 'error: project not saved';
    if (!rendersDir.exists) rendersDir.create();
    rendersDir.execute();
    return 'ok';
  } catch (e) {
    return 'error: ' + e.message;
  }
}

/**
 * Return the absolute path of Footage/Abstractor Renders, or empty string.
 */
function getRendersFolderPath() {
  var dir = getRendersFolder();
  return dir ? dir.fsName : '';
}
