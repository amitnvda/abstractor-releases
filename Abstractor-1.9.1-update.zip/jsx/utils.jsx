// Abstractor utils.jsx — minimal AE helpers
// Note: ExtendScript is Latin-1; keep ASCII only

var AB_VERSION = '1.0.0';

/**
 * Get or create a folder by name in the AE project root
 */
function abGetOrCreateFolder(name) {
  for (var i = 1; i <= app.project.numItems; i++) {
    var item = app.project.item(i);
    if (item instanceof FolderItem && item.name === name) {
      return item;
    }
  }
  return app.project.items.addFolder(name);
}
