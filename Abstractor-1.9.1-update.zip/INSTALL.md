# Abstractor — Installation Guide

## Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| Adobe After Effects | 2022+ | |
| Node.js | 18+ | [nodejs.org](https://nodejs.org) |
| Claude CLI | latest | [claude.ai/claude-code](https://claude.ai/claude-code) |

---

## macOS

### Step 1 — Enable CEP Debug Mode
Open **Terminal** and paste all 4 lines, then press Enter:
```bash
defaults write com.adobe.CSXS.9  PlayerDebugMode 1
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
```

### Step 2 — Install ZXP Installer
Download and install **ZXP Installer** from [zxpinstaller.com](https://www.zxpinstaller.com/)

### Step 3 — Install the Plugin
Drag `Abstractor-{version}.zxp` into ZXP Installer and click **Install**.

### Step 4 — Run Setup Script
In Terminal:
```bash
bash setup.sh
```
This installs Node dependencies required by the plugin.

### Step 5 — Restart After Effects
Open AE → **Window → Extensions → Abstractor**

---

## Windows

### Step 1 — Enable CEP Debug Mode
Press `Win + R`, type `cmd`, press `Ctrl + Shift + Enter` (run as Administrator), then paste:
```
reg add "HKCU\Software\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d "1" /f
```

### Step 2 — Install ZXP Installer
Download and install **ZXP Installer** from [zxpinstaller.com](https://www.zxpinstaller.com/)

### Step 3 — Install the Plugin
Drag `Abstractor-{version}.zxp` into ZXP Installer and click **Install**.

### Step 4 — Run Setup Script
Double-click `setup.bat` (or right-click → Run as Administrator).

### Step 5 — Restart After Effects
Open AE → **Window → Extensions → Abstractor**

---

## Updating

1. In the panel, open settings → **Install Update**
2. Drop the `Abstractor-{version}-update.zip` → **Install** → **Reload Extension**

No AE restart needed for updates.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Panel not visible in AE | Check CEP debug mode (Step 1) and restart AE |
| Node.js errors | Run `setup.sh` / `setup.bat` again after installing Node.js |
| Claude CLI not found | Install Claude Code: `npm install -g @anthropic-ai/claude-code` |
