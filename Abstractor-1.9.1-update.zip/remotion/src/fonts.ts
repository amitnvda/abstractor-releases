import { loadFont } from "@remotion/fonts";
import { staticFile } from "remotion";

let loaded = false;

export async function loadNvidiaSans(): Promise<void> {
  if (loaded) return;
  loaded = true;

  await Promise.all([
    loadFont({
      family: "NVIDIASans",
      url: staticFile("fonts/NVIDIASans-Regular.ttf"),
      weight: "400",
      style: "normal",
    }),
    loadFont({
      family: "NVIDIASans",
      url: staticFile("fonts/NVIDIASans-Medium.ttf"),
      weight: "500",
      style: "normal",
    }),
    loadFont({
      family: "NVIDIASans",
      url: staticFile("fonts/NVIDIASans-Bold.ttf"),
      weight: "700",
      style: "normal",
    }),
    loadFont({
      family: "NVIDIASans",
      url: staticFile("fonts/NVIDIASans-Light.ttf"),
      weight: "300",
      style: "normal",
    }),
  ]);
}

/** Call this at the top level of Root.tsx to block rendering until font is ready. */
export const fontsReady = loadNvidiaSans();
