import React from "react";
import { Composition } from "remotion";
import {
  DURATION_FRAMES,
  default as AbstractorComp,
} from "./generated/AbstractorComp";
// Block rendering until NVIDIA Sans is ready
import "./fonts";

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="AbstractorComp"
      component={AbstractorComp}
      durationInFrames={DURATION_FRAMES}
      fps={30}
      width={1920}
      height={1080}
    />
  </>
);
