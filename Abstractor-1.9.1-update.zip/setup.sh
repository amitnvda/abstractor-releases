#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Abstractor — Post-install Setup (macOS)
# Run once after installing the .zxp via ZXPInstaller.
#
# HOW TO RUN — open Terminal and type:
#   bash ~/Downloads/Abstractor/setup.sh
#
# (Using "bash script.sh" avoids macOS permission errors.
#  Do NOT double-click or use "./setup.sh" — those require execute permission.)
# ─────────────────────────────────────────────────────────────────────────────
set -e

INSTALL_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/Abstractor"
REMOTION_DIR="$INSTALL_DIR/remotion"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║       Abstractor Setup — macOS           ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── 1. Check Node.js ──────────────────────────────────────────────────────────
echo "▸ Checking Node.js…"
if command -v node &>/dev/null; then
  NODE_VER=$(node --version)
  echo "  ✓ Node.js $NODE_VER found"
else
  echo "  ✗ Node.js not found."
  echo "    Install via Homebrew:  brew install node"
  echo "    Or download from:      https://nodejs.org"
  exit 1
fi

# ── 2. Claude CLI — install if missing, then prompt login ────────────────────
echo "▸ Checking Claude CLI…"
CLAUDE_BIN=""
for p in "$HOME/.local/bin/claude" "/usr/local/bin/claude" "$(which claude 2>/dev/null)"; do
  if [ -x "$p" ]; then CLAUDE_BIN="$p"; break; fi
done

if [ -n "$CLAUDE_BIN" ]; then
  CLAUDE_VER=$("$CLAUDE_BIN" --version 2>/dev/null | head -1 || echo "unknown")
  echo "  ✓ Claude CLI found — $CLAUDE_VER"
else
  echo "  ✗ Claude CLI not found — installing via npm…"
  npm install -g @anthropic-ai/claude-code 2>&1 | tail -3
  # Re-check after install
  for p in "$HOME/.local/bin/claude" "/usr/local/bin/claude" "$(which claude 2>/dev/null)"; do
    if [ -x "$p" ]; then CLAUDE_BIN="$p"; break; fi
  done
  if [ -n "$CLAUDE_BIN" ]; then
    echo "  ✓ Claude CLI installed"
  else
    echo "  ✗ Claude CLI install failed."
    echo "    Try manually: npm install -g @anthropic-ai/claude-code"
    echo "    Or download:  https://claude.ai/download"
    exit 1
  fi
fi

# ── 3. Claude login check ─────────────────────────────────────────────────────
echo "▸ Checking Claude login…"
if "$CLAUDE_BIN" auth status &>/dev/null 2>&1; then
  echo "  ✓ Already logged in"
else
  echo "  ⚠  Not logged in — launching Claude login…"
  echo "    (A browser window will open. Sign in with your Anthropic account.)"
  echo "    After login, press Enter to continue."
  "$CLAUDE_BIN" login || true
  echo ""
fi

# ── 4. Check extension is installed ──────────────────────────────────────────
echo "▸ Checking extension installation…"
if [ ! -d "$INSTALL_DIR" ]; then
  echo "  ✗ Extension not found at:"
  echo "    $INSTALL_DIR"
  echo "    Please install the .zxp file with ZXPInstaller first."
  exit 1
fi
echo "  ✓ Extension found"

# ── 5. npm install in remotion/ ───────────────────────────────────────────────
echo "▸ Installing Remotion dependencies (this takes ~1 min)…"
if [ ! -d "$REMOTION_DIR" ]; then
  echo "  ✗ Remotion directory not found inside extension."
  exit 1
fi
cd "$REMOTION_DIR"
npm install --prefer-offline --no-audit --no-fund 2>&1 | tail -5
echo "  ✓ Remotion dependencies installed"

# ── 6. Enable CEP PlayerDebugMode ────────────────────────────────────────────
echo "▸ Enabling Adobe CEP debug mode (allows unsigned extensions)…"
for ver in 9 10 11 12 13; do
  defaults write "com.adobe.CSXS.$ver" PlayerDebugMode 1 2>/dev/null && \
    echo "  ✓ CSXS $ver" || true
done

# ── 7. Install PyMuPDF (for PPTX/PDF deck mode) ──────────────────────────────
echo "▸ Installing PyMuPDF (needed for PPTX/PDF import)…"
if command -v pip3 &>/dev/null; then
  pip3 install --quiet pymupdf 2>&1 | tail -2
  echo "  ✓ PyMuPDF installed"
else
  echo "  ⚠  pip3 not found — PPTX/PDF import will be unavailable"
  echo "    Install Python from: https://python.org"
fi

# ── 8. Optional: check poppler (for PPTX/PDF deck mode) ──────────────────────
echo "▸ Checking poppler (optional — for PPTX/PDF mode)…"
if command -v pdftoppm &>/dev/null; then
  echo "  ✓ poppler found"
else
  echo "  ⚠  poppler not found — PPTX/PDF mode will be unavailable"
  echo "    Install with:  brew install poppler"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  ✓  Setup complete!                      ║"
echo "║                                          ║"
echo "║  Next steps:                             ║"
echo "║  1. Open After Effects                   ║"
echo "║  2. Window → Extensions → Abstractor     ║"
echo "╚══════════════════════════════════════════╝"
echo ""
