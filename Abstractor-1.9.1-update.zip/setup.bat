@echo off
REM ─────────────────────────────────────────────────────────────────────────────
REM Abstractor — Post-install Setup (Windows)
REM Run once after installing the .zxp file via ZXPInstaller.
REM ─────────────────────────────────────────────────────────────────────────────

setlocal EnableDelayedExpansion

set "INSTALL_DIR=%APPDATA%\Adobe\CEP\extensions\Abstractor"
set "REMOTION_DIR=%INSTALL_DIR%\remotion"

echo.
echo ============================================
echo    Abstractor Setup -- Windows
echo ============================================
echo.

REM ── 1. Enable CEP PlayerDebugMode (MUST be first — allows unsigned extensions) ─
echo ^> Enabling Adobe CEP debug mode...
set "DEBUG_OK=0"
for %%v in (9 10 11 12 13) do (
    reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
    if not errorlevel 1 (
        echo   OK CSXS %%v
        set "DEBUG_OK=1"
    )
)
if "%DEBUG_OK%"=="0" (
    echo   WARNING: Could not write registry keys. Try running as Administrator.
) else (
    echo   OK Debug mode enabled
)

REM ── 2. Check Node.js ────────────────────────────────────────────────────────
echo ^> Checking Node.js...
where node >nul 2>&1
if errorlevel 1 (
    echo   X Node.js not found.
    echo     Download from: https://nodejs.org
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do echo   OK Node.js %%v found

REM ── 3. Claude CLI — install if missing, then prompt login ───────────────────
echo ^> Checking Claude CLI...
where claude >nul 2>&1
if errorlevel 1 (
    echo   X Claude CLI not found -- installing via npm...
    call npm install -g @anthropic-ai/claude-code
    if errorlevel 1 (
        echo   X npm install failed.
        echo     Try manually: npm install -g @anthropic-ai/claude-code
        echo     Or download:  https://claude.ai/download
        pause
        exit /b 1
    )
    echo   OK Claude CLI installed
) else (
    for /f "tokens=*" %%v in ('claude --version 2^>nul') do echo   OK Claude CLI %%v
)

REM ── 4. Claude login check ───────────────────────────────────────────────────
echo ^> Checking Claude login...
claude auth status >nul 2>&1
if errorlevel 1 (
    echo   ! Not logged in -- launching Claude login...
    echo     A browser window will open. Sign in with your Anthropic account.
    echo     After login, press any key to continue.
    claude login
    pause
) else (
    echo   OK Already logged in
)

REM ── 5. Check extension installed ────────────────────────────────────────────
echo ^> Checking extension installation...
if not exist "%INSTALL_DIR%" (
    echo   X Extension not found at:
    echo     %INSTALL_DIR%
    echo.
    echo   Please install Abstractor.zxp via ZXPInstaller first, then re-run this script.
    pause
    exit /b 1
)
echo   OK Extension found

REM ── 6. npm install in remotion/ ─────────────────────────────────────────────
echo ^> Installing Remotion dependencies (this takes ~1 min)...
if not exist "%REMOTION_DIR%" (
    echo   X Remotion directory not found inside extension.
    pause
    exit /b 1
)
cd /d "%REMOTION_DIR%"
call npm install --prefer-offline --no-audit --no-fund
if errorlevel 1 (
    echo   X npm install failed.
    pause
    exit /b 1
)
echo   OK Remotion dependencies installed

REM ── 7. Install PyMuPDF (for PPTX/PDF deck mode) ────────────────────────────
echo ^> Installing PyMuPDF (needed for PPTX/PDF import)...
where pip3 >nul 2>&1
if not errorlevel 1 (
    pip3 install --quiet pymupdf
    echo   OK PyMuPDF installed
) else (
    where pip >nul 2>&1
    if not errorlevel 1 (
        pip install --quiet pymupdf
        echo   OK PyMuPDF installed
    ) else (
        echo   WARNING: pip not found -- PPTX/PDF import unavailable
        echo     Install Python from: https://python.org
    )
)

REM ── Done ────────────────────────────────────────────────────────────────────
echo.
echo ============================================
echo   Setup complete!
echo.
echo   Next steps:
echo   1. Restart After Effects (or open it)
echo   2. Window ^> Extensions ^> Abstractor
echo ============================================
echo.
pause
